.. include:: ../../specs/lifespan.rst
