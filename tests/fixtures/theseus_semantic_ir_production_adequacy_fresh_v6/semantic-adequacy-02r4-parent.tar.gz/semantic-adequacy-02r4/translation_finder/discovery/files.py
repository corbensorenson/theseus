# Copyright © Michal Čihař <michal@weblate.org>
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""Individual discovery rules for translation formats."""

from __future__ import annotations

import csv
import json
import re
import tomllib
import warnings
from io import StringIO
from typing import TYPE_CHECKING, ClassVar, cast
from xml.parsers import expat

from ruamel.yaml import YAML
from ruamel.yaml.error import YAMLError, YAMLFutureWarning

from translation_finder.api import register_discovery

from .base import (
    BaseDiscovery,
    EncodingDiscovery,
    EnglishVariantsDiscovery,
    MonoTemplateDiscovery,
)

if TYPE_CHECKING:
    from collections.abc import Generator
    from pathlib import PurePath

    from translation_finder.finder import Finder

    from .result import DiscoveryResult, ResultDict

LARAVEL_RE = re.compile(r"=>.*\|")
LARAVEL_BYTES_RE = re.compile(rb"=>.*\|")
GWT_PLURAL_RE = re.compile(r"^[^#!\s][^:=\n]*\[[a-zA-Z_]+\]\s*[:=]", re.MULTILINE)
FORMAT_SNIFF_MAX_BYTES = 1024 * 1024
CSV_SAMPLE_ROWS = 100
SIMPLE_CSV_COLUMNS = 2
YAML_INSPECTION_MAX_DEPTH = 128
CSV_FIELDNAMES = {
    "context",
    "developer_comments",
    "fuzzy",
    "id",
    "id_hash",
    "location",
    "source",
    "source_plural_form",
    "target",
    "target_plural_form",
    "translator_comments",
}


class _QtRootFoundError(Exception):
    """Stop Qt XML parsing after the root element."""


def _get_qt_ts_version(content: str) -> str | None:
    """Return the version from a Qt TS root element."""
    version: str | None = None
    parser = expat.ParserCreate()

    def handle_start(name: str, attributes: dict[str, str]) -> None:
        nonlocal version
        if name == "TS":
            version = attributes.get("version")
        raise _QtRootFoundError

    parser.StartElementHandler = handle_start
    try:
        parser.Parse(content, False)  # ruff: ignore[boolean-positional-value-in-call]
    except _QtRootFoundError:
        return version
    except expat.ExpatError:
        return None
    return None


def _detect_utf32_encoding(content: bytes) -> str | None:
    """Detect standard UTF-32 byte orders from a BOM or XML opening marker."""
    if content.startswith((b"\x00\x00\xfe\xff", b"\xff\xfe\x00\x00")):
        return "utf-32"
    if content.startswith(b"\x00\x00\x00<"):
        return "utf-32-be"
    if content.startswith(b"<\x00\x00\x00"):
        return "utf-32-le"
    return None


def _decode_content(content: bytes) -> str:
    """Decode sampled file content."""
    for encoding in ("utf-8-sig", "utf-16"):
        try:
            return content.decode(encoding)
        except UnicodeError:
            continue
    return content.decode("iso-8859-1")


def _decode_sample_content(content: bytes) -> str:
    """Decode sampled file content, ignoring incomplete trailing bytes."""
    if encoding := _detect_utf32_encoding(content):
        return content[: len(content) - len(content) % 4].decode(
            encoding, errors="replace"
        )

    try:
        return content.decode("utf-8-sig")
    except UnicodeDecodeError as error:
        if error.end == len(content) and error.reason == "unexpected end of data":
            return content[: error.start].decode("utf-8-sig")

    if content.startswith((b"\xff\xfe", b"\xfe\xff")):
        try:
            return content.decode("utf-16")
        except UnicodeDecodeError as error:
            if error.end == len(content) and error.reason == "truncated data":
                return content[: error.start].decode("utf-16")

    return content.decode("iso-8859-1")


def _read_binary_sample(
    finder: Finder,
    path: PurePath,
    size: int | None = None,
) -> bytes | None:
    """Read a bounded binary sample from a real finder path."""
    if size is None:
        size = FORMAT_SNIFF_MAX_BYTES
    if not hasattr(path, "open"):
        return None
    try:
        with finder.open(path, "rb") as handle:
            return handle.read(size)
    except OSError:
        return None


def _read_binary_sniff_sample(
    finder: Finder,
    path: PurePath,
    size: int | None = None,
) -> tuple[bytes, bool] | None:
    """Read a bounded binary sample and report whether it is the complete file."""
    if size is None:
        size = FORMAT_SNIFF_MAX_BYTES
    if not hasattr(path, "open"):
        return None
    try:
        with finder.open(path, "rb") as handle:
            content = handle.read(size + 1)
    except OSError:
        return None
    return content[:size], len(content) <= size


def _read_binary_sniff_content(
    finder: Finder,
    path: PurePath,
    size: int | None = None,
) -> bytes | None:
    """Read complete content only when it fits within the sniffing limit."""
    sample = _read_binary_sniff_sample(finder, path, size)
    if sample is None:
        return None
    content, complete = sample
    if not complete:
        return None
    return content


def _is_sniff_content_over_limit(
    finder: Finder,
    path: PurePath,
    size: int | None = None,
) -> bool:
    """Check whether sniffing skipped content because it exceeded the limit."""
    sample = _read_binary_sniff_sample(finder, path, size)
    return sample is not None and not sample[1]


def _read_text_sample(
    finder: Finder,
    path: PurePath,
    size: int | None = None,
) -> str | None:
    """Read a text sample from a real finder path."""
    content = _read_binary_sample(finder, path, size)
    if content is None:
        return None
    return _decode_sample_content(content)


def _read_text_sniff_content(
    finder: Finder,
    path: PurePath,
    size: int | None = None,
) -> str | None:
    """Read complete text content only when it fits within the sniffing limit."""
    content = _read_binary_sniff_content(finder, path, size)
    if content is None:
        return None
    return _decode_content(content)


def _iter_result_paths(finder: Finder, result: ResultDict) -> Generator[PurePath]:
    """Yield unique paths referenced by a discovery result."""
    seen: set[str] = set()
    for mask in (result.get("template"), result["filemask"]):
        if mask is None:
            continue
        for path in finder.mask_matches(mask):
            key = path.as_posix()
            if key in seen:
                continue
            seen.add(key)
            yield path


def _read_csv_rows(finder: Finder, path: PurePath) -> list[list[str]] | None:
    """Parse a small CSV sample."""
    text = _read_text_sample(finder, path)
    if not text or not any(delimiter in text for delimiter in ",;\t"):
        return None

    try:
        dialect = csv.Sniffer().sniff(text, delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel

    rows: list[list[str]] = []
    try:
        for row in csv.reader(StringIO(text), dialect):
            if not any(row):
                continue
            rows.append(row)
            if len(rows) >= CSV_SAMPLE_ROWS:
                break
    except csv.Error:
        return None
    return rows


def _csv_header(rows: list[list[str]]) -> list[str]:
    """Return normalized CSV header if it looks like a Weblate CSV header."""
    if not rows:
        return []
    header = [field.strip().lower() for field in rows[0]]
    if header and all(field in CSV_FIELDNAMES for field in header):
        return header
    return []


def _is_csv_multi(rows: list[list[str]]) -> bool:
    """Check whether CSV rows look like a multivalue CSV file."""
    header = _csv_header(rows)
    if not header:
        return False

    if "context" not in header:
        return False
    if "source" in header:
        key_indexes: tuple[int, ...]
        key_indexes = (header.index("context"), header.index("source"))
    elif "target" in header:
        key_indexes = (header.index("context"),)
    else:
        return False

    seen: set[tuple[str, ...]] = set()
    for row in rows[1:]:
        if len(row) <= max(key_indexes):
            continue
        key = tuple(row[index] for index in key_indexes)
        if key in seen:
            return True
        seen.add(key)
    return False


def _is_csv_simple(rows: list[list[str]]) -> bool:
    """Check whether CSV rows look like a simple two-column CSV file."""
    if not rows or any(len(row) != SIMPLE_CSV_COLUMNS for row in rows):
        return False
    header = _csv_header(rows)
    return not header or set(header) <= {"context", "id", "source", "target"}


def _detect_csv_format(finder: Finder, result: ResultDict) -> str | None:
    """Detect CSV format variants based on file content."""
    detected_simple = False
    for path in _iter_result_paths(finder, result):
        rows = _read_csv_rows(finder, path)
        if rows is None:
            continue
        if _is_csv_multi(rows):
            return "csv-multi"
        detected_simple |= _is_csv_simple(rows)
    if detected_simple:
        return "csv-simple"
    return None


@register_discovery
class GettextDiscovery(BaseDiscovery):
    """Gettext PO files discovery."""

    file_format = "po"
    mask = "*.po"
    new_base_mask = "*.pot"

    def discover(
        self, *, eager: bool = False, hint: str | None = None
    ) -> Generator[DiscoveryResult]:
        """Yield translation configurations matching this discovery."""
        for result in super().discover(eager=eager, hint=hint):
            if "template" not in result:
                yield result
                continue
            bi = result.copy()
            del bi["template"]
            yield bi
            mono = result.copy()
            mono["file_format"] = "po-mono"
            yield mono

    def fill_in_new_base(self, result: ResultDict) -> None:
        """Extend the result for new_base and intermediate parameters."""
        super().fill_in_new_base(result)
        if "new_base" not in result:
            pot_names = [
                result["filemask"].replace("po/*/", "pot/") + "t",
                result["filemask"].replace("*", "templates") + "t",
                result["filemask"].replace(".*", ""),
                result["filemask"].replace("_*", ""),
                result["filemask"].replace("-*", ""),
            ]
            for pot_name in pot_names:
                if self.finder.has_file(pot_name):
                    result["new_base"] = pot_name
                    break


@register_discovery
class QtDiscovery(BaseDiscovery):
    """Qt Linguist files discovery."""

    file_format = "ts"
    mask = "*.ts"
    new_base_mask = "*.ts"

    def adjust_format(self, result: ResultDict) -> None:
        """Detect legacy Qt Linguist files based on the TS root version."""
        path = next(iter(self.finder.mask_matches(result["filemask"])), None)
        if path is None:
            return

        content = _read_text_sample(self.finder, path)
        if content is None:
            return

        version = _get_qt_ts_version(content)
        if version is not None and version.startswith("1."):
            result["file_format"] = "ts1"


@register_discovery
class XliffDiscovery(BaseDiscovery):
    """XLIFF files discovery."""

    file_format = "xliff"
    mask = ("*.xliff", "*.xlf", "*.sdlxliff", "*.mxliff", "*.poxliff")

    def adjust_format(self, result: ResultDict) -> None:
        """Override detected format, based on the file content."""
        base = result["template"] if "template" in result else result["filemask"]

        path = next(iter(self.finder.mask_matches(base)))

        if not hasattr(path, "open"):
            return

        sample = _read_binary_sniff_sample(self.finder, path)
        if sample is None:
            return
        content, _complete = sample
        # Check for XLIFF 2.0 first
        if b'version="2.0"' in content or b'version="2.1"' in content:
            if b"<pc" in content or b"<sc" in content or b"<ec" in content:
                result["file_format"] = "xliff2-placeables"
            else:
                result["file_format"] = "xliff2"
        elif b'restype="x-gettext' in content:
            result["file_format"] = "poxliff"
        elif (
            b"NSStringPluralRuleType" in content
            or b'original="Localizable.strings"' in content
            or b":dict" in content
        ):
            result["file_format"] = "apple-xliff"
        elif b"<x " not in content and b"<g " not in content:
            result["file_format"] = "plainxliff"


@register_discovery
class JoomlaDiscovery(BaseDiscovery):
    """Joomla files discovery."""

    file_format = "joomla"
    mask = "*.ini"


@register_discovery
class CSVDiscovery(MonoTemplateDiscovery):
    """CSV files discovery."""

    file_format = "csv"
    mask = "*.csv"

    def adjust_format(self, result: ResultDict) -> None:
        """Override detected format, based on the file content."""
        detected = _detect_csv_format(self.finder, result)
        if detected is not None:
            result["file_format"] = detected

    def discover(
        self, *, eager: bool = False, hint: str | None = None
    ) -> Generator[DiscoveryResult]:
        """Yield translation configurations matching this discovery."""
        for result in super().discover(eager=eager, hint=hint):
            if "template" not in result:
                yield result
                continue
            bilingual = result.copy()
            del bilingual["template"]
            yield bilingual
            yield result


@register_discovery
class WebExtensionDiscovery(BaseDiscovery):
    """web extension files discovery."""

    file_format = "webextension"
    mask = "messages.json"


@register_discovery
class AndroidDiscovery(BaseDiscovery):
    """Android string files discovery."""

    file_format = "aresource"

    def get_masks(
        self, *, eager: bool = False, hint: str | None = None
    ) -> Generator[ResultDict]:
        """
        Return all file masks found in the directory.

        It is expected to contain duplicates.
        """
        for path in self.finder.filter_files(
            r"(strings.*|.*strings)\.xml",
            ".*/values",
            candidate_suffixes=(".xml",),
        ):
            # Skip Compose Multiplatform resources
            if "composeResources" in path.as_posix():
                continue

            mask = list(path.parts)
            mask[-2] = "values-*"

            yield {"filemask": "/".join(mask), "template": path.as_posix()}

    def adjust_format(self, result: ResultDict) -> None:
        """Override detected format, based on the file content."""
        if "template" not in result:
            return

        path = next(iter(self.finder.mask_matches(result["template"])))

        if not hasattr(path, "open"):
            return

        content = _read_binary_sample(self.finder, path)
        if content is not None and b"<plural " in content:
            result["file_format"] = "moko-resource"


@register_discovery
class MOKODiscovery(BaseDiscovery):
    """Mobile Kotlin resources discovery."""

    file_format = "moko-resource"

    def get_masks(
        self, *, eager: bool = False, hint: str | None = None
    ) -> Generator[ResultDict]:
        """
        Return all file masks found in the directory.

        It is expected to contain duplicates.
        """
        for path in self.finder.filter_files(
            r"(strings|plurals)\.xml",
            ".*/resources/mr/base",
            candidate_names=("strings.xml", "plurals.xml"),
        ):
            mask = list(path.parts)
            mask[-2] = "*"

            yield {"filemask": "/".join(mask), "template": path.as_posix()}


@register_discovery
class OSXDiscovery(EncodingDiscovery):
    """OSX string properties files discovery."""

    file_format: ClassVar[str] = "strings"
    file_format_params: ClassVar[dict[str, str | int | bool]] = {
        "strings_encoding": "utf-8",
    }
    encoding_parameter: ClassVar[str] = "strings_encoding"
    encoding_map: ClassVar[dict[str, str]] = {
        "utf_8": "utf-8",
        "utf_16": "utf-16",
    }

    def possible_templates(self, language: str, mask: str) -> Generator[str]:
        """Yield possible template filenames."""
        yield mask.replace("*", "Base")
        yield from super().possible_templates(language, mask)

    def get_masks(
        self, *, eager: bool = False, hint: str | None = None
    ) -> Generator[ResultDict]:
        """
        Return all file masks found in the directory.

        It is expected to contain duplicates.
        """
        for path in self.finder.filter_files(
            r".*\.strings",
            r".*/(base|en(-[a-z]{2})?)\.lproj",
            candidate_suffixes=(".strings",),
        ):
            mask = list(path.parts)
            mask[-2] = "*.lproj"

            yield {"filemask": "/".join(mask), "template": path.as_posix()}

        for path in self.finder.filter_files(
            r"base\.strings",
            candidate_names=("base.strings",),
        ):
            mask = list(path.parts)
            mask[-1] = "*.strings"

            yield {"filemask": "/".join(mask), "template": path.as_posix()}


@register_discovery
class StringsdictDiscovery(BaseDiscovery):
    """Stringsdict files discovery."""

    file_format = "stringsdict"

    def get_masks(
        self, *, eager: bool = False, hint: str | None = None
    ) -> Generator[ResultDict]:
        """
        Return all file masks found in the directory.

        It is expected to contain duplicates.
        """
        for path in self.finder.filter_files(
            r".*\.stringsdict",
            r".*/(base|en)\.lproj",
            candidate_suffixes=(".stringsdict",),
        ):
            mask = list(path.parts)
            mask[-2] = "*.lproj"

            yield {"filemask": "/".join(mask), "template": path.as_posix()}


@register_discovery
class JavaDiscovery(EncodingDiscovery):
    """Java string properties files discovery."""

    file_format = "properties"
    encoding_parameter: ClassVar[str] = "properties_encoding"
    encoding_parameters_by_format: ClassVar[dict[str, str]] = {
        "properties": "properties_encoding",
        "gwt": "gwt_encoding",
    }
    encoding_map: ClassVar[dict[str, str]] = {
        "utf_8": "utf-8",
        "utf_16": "utf-16",
    }
    mask = ("*_*.properties", "*.properties")

    def possible_templates(self, language: str, mask: str) -> Generator[str]:
        """Yield possible template filenames."""
        yield mask.replace("_*", "")
        yield from super().possible_templates(language, mask)

    def adjust_format(self, result: ResultDict) -> None:
        """Override detected format, based on the file content."""
        self.adjust_encoding(result)
        for path in _iter_result_paths(self.finder, result):
            content = _read_text_sample(self.finder, path)
            if content is None:
                continue
            if (
                "xwiki" in path.as_posix().lower()
                or "XWiki Core localization" in content
                or "# XWiki" in content
            ):
                result["file_format"] = "xwiki-java-properties"
                self.normalize_encoding_parameters(result)
                return
            if GWT_PLURAL_RE.search(content):
                result["file_format"] = "gwt"
                self.normalize_encoding_parameters(result)
                return


@register_discovery
class RESXDiscovery(BaseDiscovery):
    """RESX files discovery."""

    file_format = "resx"
    mask = "resources.res[xw]"

    def possible_templates(self, language: str, mask: str) -> Generator[str]:
        """Yield possible template filenames."""
        yield mask.replace(".*", "")
        yield from super().possible_templates(language, mask)

    def get_masks(
        self, *, eager: bool = False, hint: str | None = None
    ) -> Generator[ResultDict]:
        """
        Return all file masks found in the directory.

        It is expected to contain duplicates.
        """
        for path in self.finder.filter_files(
            r".*\..*\.res[xw]",
            candidate_suffixes=(".resx", ".resw"),
        ):
            mask = list(path.parts)
            base, code, ext = mask[-1].rsplit(".", 2)
            if not self.is_language_code(code):
                continue
            mask[-1] = f"{base}.*.{ext}"
            yield {"filemask": "/".join(mask)}
        yield from super().get_masks(eager=eager, hint=hint)


@register_discovery
class ResourceDictionaryDiscovery(BaseDiscovery):
    """ResourceDictionary files discovery."""

    file_format = "resourcedictionary"
    mask = "*.xaml"
    new_base_mask = "*.xaml"


@register_discovery
class AppStoreDiscovery(EnglishVariantsDiscovery):
    """App store metadata."""

    file_format = "appstore"
    mask = ""

    def filter_files(self) -> Generator[PurePath]:
        """Filter possible file matches."""
        for path in self.finder.filter_files(
            "short_description.txt|full_description.txt|title.txt|description.txt|name.txt",
            candidate_names=(
                "short_description.txt",
                "full_description.txt",
                "title.txt",
                "description.txt",
                "name.txt",
            ),
        ):
            yield path.parent
        for path in self.finder.filter_files(
            r".*\.txt",
            ".*/changelogs",
            candidate_suffixes=(".txt",),
        ):
            yield path.parent.parent

    def has_storage(self, name: str) -> bool:
        """Check whether finder has a storage."""
        return self.finder.has_dir(name)


@register_discovery
class JSONDiscovery(BaseDiscovery):
    """JSON files discovery."""

    file_format = "json-nested"
    mask = "*.json"

    def read_json_data(self, path: PurePath) -> object | None:
        """Read and parse a complete JSON file."""
        content = _read_binary_sniff_content(self.finder, path)
        if content is None:
            return None
        try:
            return json.loads(_decode_content(content))
        except (OSError, RecursionError, ValueError):
            return None

    def has_template_less_content(self, result: ResultDict) -> bool:
        """Check whether a template-less JSON result looks translatable."""
        for path in _iter_result_paths(self.finder, result):
            if not hasattr(path, "open"):
                return True

            if _is_sniff_content_over_limit(self.finder, path):
                return True

            data = self.read_json_data(path)
            if isinstance(data, dict) and self.detect_dict(data) is not None:
                return True
        return False

    def discover(
        self, *, eager: bool = False, hint: str | None = None
    ) -> Generator[DiscoveryResult]:
        """Yield JSON configurations matching this discovery."""
        for result in super().discover(eager=eager, hint=hint):
            if (
                not eager
                and "template" not in result
                and not self.has_template_less_content(result.match)
            ):
                continue
            yield result

    @staticmethod
    def is_go_i18n_v2_dict(data: dict) -> bool:
        """Check if dict matches go-i18n-v2 format pattern."""
        return "hash" in data and (
            "message" in data or "one" in data or "other" in data
        )

    def _detect_top_level_format(self, data: dict) -> str | None:
        """Detect formats that are only determined from the top-level object."""
        if "lang" in data and "messages" in data:
            return "gotext"
        # go-i18n-v2 detection at top level
        if self.is_go_i18n_v2_dict(data):
            return "go-i18n-json-v2"
        # Nextcloud JSON format detection
        if (
            "translations" in data
            and isinstance(data["translations"], list)
            and len(data["translations"]) > 0
        ):
            first = data["translations"][0]
            if isinstance(first, dict) and "key" in first:
                return "nextcloud-json"
        # RESJSON format detection
        if "_strings" in data or "_locales" in data:
            return "resjson"
        return None

    def _detect_first_level_format(self, value: dict) -> str | None:
        if "message" in value and "description" in value:
            return "webextension"
        if "defaultMessage" in value and "description" in value:
            return "formatjs"
        # go-i18n-v2 detection in nested objects
        if self.is_go_i18n_v2_dict(value):
            return "go-i18n-json-v2"
        return None

    @staticmethod
    def _iter_nested_dicts(data: dict, level: int) -> Generator[tuple[dict, int]]:
        seen: set[int] = set()
        stack = [(data, level)]

        while stack:
            current, current_level = stack.pop()
            current_id = id(current)
            if current_id in seen:
                continue
            seen.add(current_id)
            yield current, current_level

            stack.extend(
                (value, current_level + 1)
                for value in current.values()
                if isinstance(value, dict)
            )

    @staticmethod
    def _detect_i18next_format(key: str, value: str) -> str | None:
        if key.endswith(("_one", "_many", "_other")):
            return "i18nextv4"
        if key.endswith("_plural") or "{{" in value:
            return "i18next"
        return None

    def _detect_nested_format(self, data: dict, level: int) -> str | None:
        i18next = False
        i18nextv4 = False
        all_strings = True

        for current, current_level in self._iter_nested_dicts(data, level):
            # Single loop to detect nested formats and i18next patterns
            for key, value in current.items():
                # Check for nested formats at level 0
                if (
                    current_level == 0
                    and isinstance(value, dict)
                    and (detected := self._detect_first_level_format(value))
                ):
                    return detected

                # Check for i18next patterns
                if not isinstance(key, str):
                    if current is data:
                        all_strings = False
                    break
                if not isinstance(value, str):
                    if current is data:
                        all_strings = False
                    continue

                detected = self._detect_i18next_format(key, value)
                i18nextv4 |= detected == "i18nextv4"
                i18next |= detected == "i18next"

        if i18nextv4:
            return "i18nextv4"
        if i18next:
            return "i18next"
        if all_strings:
            return "json"
        return None

    def detect_dict(self, data: dict) -> str | None:
        """Detect JSON variant based on JSON content."""
        top_level_format = self._detect_top_level_format(data)
        if top_level_format is not None:
            return top_level_format

        return self._detect_nested_format(data, 0)

    def adjust_format(self, result: ResultDict) -> None:
        """Override detected format, based on the file content."""
        if "template" not in result:
            return

        path = next(iter(self.finder.mask_matches(result["template"])))

        if not hasattr(path, "open"):
            return

        content = _read_binary_sniff_content(self.finder, path)
        if content is None:
            return
        try:
            data = json.loads(content.decode())
        except (RecursionError, UnicodeError, ValueError) as error:
            warnings.warn(f"Could not parse JSON: {error}", stacklevel=0)
            return
        if (
            isinstance(data, list)
            and len(data) > 0
            and isinstance(data[0], dict)
            and "id" in data[0]
        ):
            result["file_format"] = "go-i18n-json"
            return
        if not isinstance(data, dict):
            return

        detected = self.detect_dict(data)

        if detected is not None:
            result["file_format"] = detected


@register_discovery
class FluentDiscovery(BaseDiscovery):
    """Fluent files discovery."""

    file_format = "fluent"
    mask = "*.ftl"

    def get_language_aliases(self, language: str) -> list[str]:
        """Language code aliases."""
        result = super().get_language_aliases(language)
        if language == "en":
            result.append("en-US")
        return result


@register_discovery
class YAMLDiscovery(BaseDiscovery):
    """YAML files discovery."""

    file_format = "yaml"
    mask = ("*.yml", "*.yaml")

    def adjust_format(self, result: ResultDict) -> None:
        """Override detected format, based on the file content."""
        if "template" not in result:
            return

        path = next(iter(self.finder.mask_matches(result["template"])))

        if not hasattr(path, "open"):
            return

        content = _read_text_sniff_content(self.finder, path)
        if content is None:
            return
        yaml = YAML()
        yaml.max_depth = YAML_INSPECTION_MAX_DEPTH
        try:
            data = yaml.load(content)
        except (YAMLError, YAMLFutureWarning):
            return
        except (OSError, UnicodeError, TypeError, ValueError) as error:
            # Weird errors can happen when parsing YAML, handle them gracefully, but
            # emit a warning
            warnings.warn(f"Could not parse YAML: {error}", stacklevel=0)
            return
        if isinstance(data, dict) and len(data) == 1:
            key = cast("str", next(iter(data.keys())))
            if "filemask" in result:
                if result["filemask"].replace("*", key) == result["template"]:
                    result["file_format"] = "ruby-yaml"
            elif key in result["template"]:
                result["file_format"] = "ruby-yaml"


@register_discovery
class SRTDiscovery(MonoTemplateDiscovery):
    """SRT subtitle files discovery."""

    file_format = "srt"
    mask = "*.srt"


@register_discovery
class SUBDiscovery(MonoTemplateDiscovery):
    """SUB subtitle files discovery."""

    file_format = "sub"
    mask = "*.sub"


@register_discovery
class ASSDiscovery(MonoTemplateDiscovery):
    """ASS subtitle files discovery."""

    file_format = "ass"
    mask = "*.ass"


@register_discovery
class SSADiscovery(MonoTemplateDiscovery):
    """SSA subtitle files discovery."""

    file_format = "ssa"
    mask = "*.ssa"


@register_discovery
class PHPDiscovery(MonoTemplateDiscovery):
    """PHP files discovery."""

    file_format = "php"
    mask = "*.php"

    def adjust_format(self, result: ResultDict) -> None:
        """Override detected format, based on the file content."""
        if "template" not in result:
            return

        path = next(iter(self.finder.mask_matches(result["template"])))

        if not hasattr(path, "open"):
            return

        content = _read_binary_sample(self.finder, path)
        if (
            content is not None
            and b"return [" in content
            and LARAVEL_BYTES_RE.search(content)
        ):
            result["file_format"] = "laravel"


@register_discovery
class IDMLDiscovery(MonoTemplateDiscovery):
    """IDML files discovery."""

    file_format = "idml"
    mask = ("*.idml", "*.idms")


@register_discovery
class HTMLDiscovery(MonoTemplateDiscovery):
    """HTML files discovery."""

    file_format = "html"
    mask = ("*.html", "*.htm")
    requires_template = True


@register_discovery
class TXTDiscovery(MonoTemplateDiscovery, EnglishVariantsDiscovery):
    """TXT files discovery."""

    file_format = "txt"
    mask = "*.txt"

    def adjust_format(self, result: ResultDict) -> None:
        """Override detected format, based on the file content."""
        if _detect_csv_format(self.finder, result) == "csv-simple":
            result["file_format"] = "csv-simple"


@register_discovery
class ODFDiscovery(MonoTemplateDiscovery):
    """ODF files discovery."""

    file_format = "odf"
    mask = (
        "*.sxw",
        "*.odt",
        "*.ods",
        "*.odp",
        "*.odg",
        "*.odc",
        "*.odf",
        "*.odi",
        "*.odm",
        "*.ott",
        "*.ots",
        "*.otp",
        "*.otg",
        "*.otc",
        "*.otf",
        "*.oti",
        "*.oth",
    )


@register_discovery
class XLSXDiscovery(CSVDiscovery):
    """Excel Open XML files discovery."""

    file_format = "xlsx"
    mask = "*.xlsx"

    def adjust_format(self, result: ResultDict) -> None:  # ruff:ignore[no-self-use]
        """Keep Excel files on the Excel format."""
        return


@register_discovery
class INIDiscovery(BaseDiscovery):
    """INI files discovery."""

    file_format = "ini"
    mask = "*.ini"


@register_discovery
class InnoSetupDiscovery(BaseDiscovery):
    """InnoSetup files discovery."""

    file_format = "islu"
    mask = "*.islu"


@register_discovery
class TOMLDiscovery(BaseDiscovery):
    """TOML files discovery."""

    file_format = "toml"
    mask = "*.toml"

    def adjust_format(self, result: ResultDict) -> None:
        """Override detected format, based on the file content."""
        if "template" not in result:
            return

        path = next(iter(self.finder.mask_matches(result["template"])))

        if not hasattr(path, "open"):
            return

        content = _read_text_sniff_content(self.finder, path)
        if content is None:
            return
        try:
            data = tomllib.loads(content)
        except (tomllib.TOMLDecodeError, OSError, RecursionError) as error:
            warnings.warn(f"Could not parse TOML: {error}", stacklevel=0)
            return
        # go-i18n-toml detection - has messages array with 'id' field
        messages = data.get("messages") if isinstance(data, dict) else None
        if (
            isinstance(messages, list)
            and len(messages) > 0
            and isinstance(messages[0], dict)
            and "id" in messages[0]
        ):
            result["file_format"] = "go-i18n-toml"


@register_discovery
class ARBDiscovery(BaseDiscovery):
    """ARB files discovery."""

    file_format = "arb"
    mask = "*.arb"

    def fill_in_new_base(self, result: ResultDict) -> None:
        """Extend the result for new_base and intermediate parameters."""
        super().fill_in_new_base(result)
        if "intermediate" not in result:
            # Flutter intermediate files
            intermediate = result["filemask"].replace("*", "messages")
            if self.finder.has_file(intermediate):
                result["intermediate"] = intermediate


@register_discovery
class RCDiscovery(MonoTemplateDiscovery):
    """RC files discovery."""

    file_format = "rc"
    mask = ("*.rc",)

    def get_language_aliases(self, language: str) -> list[str]:
        """Language code aliases."""
        if language == "en":
            return [language, "enu", "ENU"]
        return super().get_language_aliases(language)


@register_discovery
class TBXDiscovery(BaseDiscovery):
    """TBX files discovery."""

    file_format = "tbx"
    mask = "*.tbx"


@register_discovery
class MarkdownDiscovery(MonoTemplateDiscovery):
    """Markdown files discovery."""

    file_format = "markdown"
    mask = ("*.md", "*.markdown")


@register_discovery
class DokuWikiDiscovery(MonoTemplateDiscovery):
    """DokuWiki text files discovery."""

    file_format = "dokuwiki"
    mask = "*.dw"


@register_discovery
class MediaWikiDiscovery(MonoTemplateDiscovery):
    """MediaWiki text files discovery."""

    file_format = "mediawiki"
    mask = "*.mw"


@register_discovery
class AsciiDocDiscovery(MonoTemplateDiscovery):
    """AsciiDoc files discovery."""

    file_format = "asciidoc"
    mask = ("*.ad", "*.adoc", "*.asciidoc")


@register_discovery
class WXLDiscovery(MonoTemplateDiscovery):
    """WiX localization files discovery."""

    file_format = "wxl"
    mask = "*.wxl"


@register_discovery
class FormatJSDiscovery(BaseDiscovery):
    """Format.JS JSON files discovery."""

    file_format = "formatjs"

    def get_masks(
        self, *, eager: bool = False, hint: str | None = None
    ) -> Generator[ResultDict]:
        """
        Return all file masks found in the directory.

        It is expected to contain duplicates.
        """
        for path in self.finder.filter_files(
            r"en.json",
            ".*/extracted",
            candidate_names=("en.json",),
        ):
            mask = list(path.parts)
            mask[-1] = "*.json"
            mask[-2] = "lang"

            yield {"filemask": "/".join(mask), "template": path.as_posix()}


@register_discovery
class DTDDiscovery(BaseDiscovery):
    """DTD files discovery."""

    file_format = "dtd"
    mask = "*.dtd"


@register_discovery
class FlatXMLDiscovery(MonoTemplateDiscovery):
    """Flat XML files discovery."""

    file_format = "flatxml"
    mask = "*.xml"
    requires_template = True

    def adjust_format(self, result: ResultDict) -> None:
        """Override detected format, based on the file content."""
        for path in _iter_result_paths(self.finder, result):
            content = _read_text_sample(self.finder, path)
            if content is None or "<xwikidoc" not in content:
                continue
            if (
                "XWiki.TranslationDocumentClass" in content
                or "<syntaxId>plain/" in content
            ):
                result["file_format"] = "xwiki-page-properties"
            else:
                result["file_format"] = "xwiki-fullpage"
            return


@register_discovery
class CatkeysDiscovery(BaseDiscovery):
    """Haiku catkeys files discovery."""

    file_format = "catkeys"
    mask = "*.catkeys"


@register_discovery
class CMPDiscovery(BaseDiscovery):
    """Compose Multiplatform Resource files discovery."""

    file_format = "cmp-resource"

    def get_masks(
        self, *, eager: bool = False, hint: str | None = None
    ) -> Generator[ResultDict]:
        """
        Return all file masks found in the directory.

        It is expected to contain duplicates.
        """
        for path in self.finder.filter_files(
            r"(strings.*|.*strings)\.xml",
            ".*/values",
            candidate_suffixes=(".xml",),
        ):
            # Only match files in composeResources directories
            if "composeResources" not in path.as_posix():
                continue

            mask = list(path.parts)
            mask[-2] = "values-*"

            yield {"filemask": "/".join(mask), "template": path.as_posix()}


@register_discovery
class Mi18nDiscovery(BaseDiscovery):
    """@draggable/i18n lang files discovery."""

    file_format = "mi18n-lang"
    mask = "*.lang"
