# fmt: off

"""A command-line interface wrapper for calling Cython."""

from __future__ import annotations

import sys
import typing as _t  # noqa: WPS111
from itertools import chain
from pathlib import Path

from Cython.Compiler.CmdLine import (
    parse_command_line as _split_cython_cli_args,
)
from Cython.Compiler.Main import compile as _translate_cython_cli_cmd

from ._cython_configuration import (
    get_local_cython_config as _get_local_cython_config,
    make_cythonize_cli_args_from_config as _make_cythonize_cli_args_from_config,
    patched_env as _patched_cython_env,
)


if _t.TYPE_CHECKING:
    import collections.abc as _c  # noqa: WPS111, WPS301


_PROJECT_PATH = Path(__file__).parents[2]


def run_main_program(argv: _c.Sequence[str]) -> int | str:
    """Invoke ``translate-cython`` or fail."""
    if len(argv) != 2:
        return 'This program only accepts one argument -- "translate-cython"'

    if argv[1] != 'translate-cython':
        return 'This program only implements the "translate-cython" subcommand'

    config = _get_local_cython_config()
    config['flags'] = {'keep-going': config['flags']['keep-going']}
    config['src'] = list(
        map(
            str,
            chain.from_iterable(
                map(_PROJECT_PATH.glob, config['src']),
            ),
        ),
    )
    translate_cython_cli_args = _make_cythonize_cli_args_from_config(config)

    cython_options, cython_sources = _split_cython_cli_args(  # type: ignore[no-untyped-call]
        translate_cython_cli_args,
    )

    with _patched_cython_env(config['env'], cython_line_tracing_requested=True):
        return _translate_cython_cli_cmd(  # type: ignore[no-any-return,no-untyped-call]
            cython_sources,
            cython_options,
        ).num_errors


if __name__ == '__main__':
    sys.exit(run_main_program(argv=sys.argv))
