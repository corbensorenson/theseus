# Regression test for https://github.com/psf/black/issues/2478.
def foo():
    arr = (
        (3833567325051000, 5, 1, 2, 4229.25, 6, 0),
        # fmt: off
    )


# Regression test for https://github.com/psf/black/issues/3458.
dependencies = {
    a: b,
    # fmt: off
}


# Regression test for https://github.com/psf/black/issues/4511.
# fmt: off inside brackets with an f-string should not crash.
(
    # fmt: off
    f"""
"""
    # fmt: on
)

[
    # fmt: off
    f"{x}"
    # fmt: on
]

# Same as above but unindented inside brackets.
(
# fmt: off
f"""
"""
# fmt: on
)

[
# fmt: off
f"{x}"
# fmt: on
]

# output

# Regression test for https://github.com/psf/black/issues/2478.
def foo():
    arr = (
        (3833567325051000, 5, 1, 2, 4229.25, 6, 0),
        # fmt: off
    )


# Regression test for https://github.com/psf/black/issues/3458.
dependencies = {
    a: b,
    # fmt: off
}


# Regression test for https://github.com/psf/black/issues/4511.
# fmt: off inside brackets with an f-string should not crash.
(
    # fmt: off
    f"""
"""
    # fmt: on
)

[
    # fmt: off
    f"{x}"
    # fmt: on
]

# Same as above but unindented inside brackets.
(
    # fmt: off
f"""
"""
    # fmt: on
)

[
    # fmt: off
f"{x}"
    # fmt: on
]
