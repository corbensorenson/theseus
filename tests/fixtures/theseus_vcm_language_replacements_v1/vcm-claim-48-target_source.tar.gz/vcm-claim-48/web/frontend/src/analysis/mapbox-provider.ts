/**
 * MapBox Provider
 *
 * MapBox GL JS implementation of the MapProvider interface.
 * Handles rendering of flight tracks, task turnpoints, and events.
 * Supports 3D track rendering via Threebox.
 */

import * as mapboxgl from 'mapbox-gl';
import { Threebox } from 'threebox-plugin';
import { getBoundingBox, getEventStyle, calculateGlideMarkers, calculateGlidePositions, getSegmentLengthMeters, calculateOptimizedTaskLine, getOptimizedSegmentDistances, calculateBearing, computeGoalLine, goalSemicirclePoints, andoyerDistance, type IGCFix, type XCTask, type FlightEvent, type GlideContext, type TurnpointSequenceResult, type PilotScore } from '@glidecomp/engine';
import type { MapProvider, MapBounds, MapPickDetails, LoadedTrack, OpenDistanceLine, BestProgressRoute } from './map-provider';
import { config } from './config';
import {
  MAP_FONT_FAMILY, GLIDE_LABEL_TEXT_SHADOW, GLIDE_LABEL_SPARSE_MIN_ZOOM, GLIDE_LABEL_SPEED_MIN_ZOOM,
  KEY_EVENT_TYPES, getAltitudeColorNormalized,
  findNearestFixIndex as sharedFindNearestFixIndex,
  createCirclePolygon, exitTurnpointArrowFeatures, createGlideLegend, showGlideLegend as sharedShowGlideLegend,
  createTrackPointHUD, updateTrackPointHUD, hideTrackPointHUD as sharedHideTrackPointHUD,
  CROSSHAIR_MAP_SVG,
  buildTrackPointHUDData, buildNextTurnpointContext, ensureTurnpointCache,
  formatGlideLabel, formatTurnpointLabel, computeSegmentLabels, updateGlideLabelElement, computeOccludedLabels,
  calculateAltitudeRange, buildTrackSegments,
} from './map-provider-shared';
import { formatAltitude, formatDistance } from './units-browser';
import { createMapAnnotationLayer, type MapAnnotationLayer } from './map-annotations';
import { escapeHtml } from '../escape-html';

const MAPBOX_ACCESS_TOKEN = import.meta.env.VITE_MAPBOX_TOKEN;

// Terrain exaggeration factor — applied to both the Mapbox terrain and
// Threebox 3D track altitudes so the track stays above the terrain surface.
const TERRAIN_EXAGGERATION = 1.5;
const SHOW_DROP_LINES = true; // Toggle vertical drop lines from track to ground

// MapBox style options
const MAPBOX_STYLES = [
  { id: 'outdoors', name: 'Outdoors', style: 'mapbox://styles/poklet/cmkceyuoc00ha01svg6lb767k' },
  { id: 'satellite', name: 'Satellite', style: 'mapbox://styles/mapbox/satellite-streets-v12' },
  { id: 'streets', name: 'Streets', style: 'mapbox://styles/mapbox/streets-v12' },
  { id: 'light', name: 'Light', style: 'mapbox://styles/mapbox/light-v11' },
  { id: 'dark', name: 'Dark', style: 'mapbox://styles/mapbox/dark-v11' },
];

/** Helper: set GeoJSON data on a named source, guarding against missing sources. */
function updateGeoJSONSource(
  map: mapboxgl.Map,
  sourceId: string,
  features: GeoJSON.Feature[],
): void {
  (map.getSource(sourceId) as mapboxgl.GeoJSONSource)?.setData({
    type: 'FeatureCollection',
    features,
  });
}

/**
 * Build the altitude-coloured LineString features for a track. Consecutive
 * fixes are batched into multi-point segments for reliable rendering:
 * individual 2-point segments get dropped at Mapbox vector tile boundaries,
 * causing visible breaks on long flights. ~500 segments balances visual
 * fidelity of altitude-based styling with rendering robustness.
 *
 * `altRange`/`minAlt` are passed in (rather than derived from `fixes`) so a
 * clipped track can keep the full flight's colour normalisation.
 */
function buildTrackFeatures(
  fixes: IGCFix[],
  altRange: number,
  minAlt: number,
): GeoJSON.Feature[] {
  return buildTrackSegments(fixes, altRange, minAlt).map(seg => {
    const coordinates: [number, number][] = [];
    for (let j = seg.startIndex; j < seg.endIndex; j++) {
      coordinates.push([fixes[j].longitude, fixes[j].latitude]);
    }
    return {
      type: 'Feature' as const,
      properties: { normalizedAlt: seg.normalizedAlt },
      geometry: {
        type: 'LineString' as const,
        coordinates,
      },
    };
  });
}

// How far (screen px) from an add-waypoint tap to look for a named label —
// slightly wider than the 44px waypoint-pick tolerance since labels render
// offset from the feature they name.
const PLACE_NAME_SEARCH_RADIUS_PX = 56;

// A peak label this tight (screen px) to the tap is close enough to auto-snap
// to — the same finger-width constant as waypoint picking. This is the
// screen-space half of the auto-snap rule; the metre cap (route-editor's
// AUTO_SNAP_MAX_DISTANCE_M) is the other half, and both must pass. Peaks that
// fall in the wider label-search box but fail this become opt-in offers.
const PEAK_AUTO_SNAP_RADIUS_PX = 44;

// Mapbox Streets v8 source layers that carry useful point names, for the
// classic styles (satellite/streets/light/dark). Filtering by source layer
// instead of style layer id keeps this working across styles, whose layer
// ids differ.
const PLACE_NAME_SOURCE_LAYERS = new Set([
  'natural_label', // peaks, ridges, water bodies
  'poi_label', // parks, landmarks
  'place_label', // settlements, localities
  'airport_label',
]);

/**
 * Whether a rendered label feature is a peak (the only feature we snap to).
 * A label comes in one of two shapes depending on the style's engine: classic
 * styles carry a `natural_label` source layer whose `class` distinguishes peaks
 * (`landform`) from water/wetland/glacier; Mapbox-Standard-based styles (the
 * default Outdoors style) return featuresets with no source layer but a
 * `group` of `natural-point` for summit nodes.
 */
function isPeakLabel(f: mapboxgl.GeoJSONFeature): boolean {
  const props = f.properties ?? {};
  if (props.group === 'natural-point') return true; // Standard featureset
  if (f.sourceLayer === 'natural_label') return props.class === 'landform';
  return false;
}

interface NearbyLabels {
  /** Nearest named point label (peak, locality, POI) — the name suggestion. */
  placeName?: string;
  /** Nearest peak label — the snap-to-peak candidate. */
  peak?: import('./map-provider').PickedPeak;
}

/**
 * The nearest named point label and the nearest peak label rendered around a
 * screen point, from the already-loaded map data (no network request).
 * Best-effort by design: only finds labels the current style renders at the
 * current zoom.
 *
 * A label feature comes in one of two shapes depending on the style's engine:
 * classic styles return vector-tile features whose `sourceLayer` names a
 * streets-v8 label layer; Mapbox-Standard-based styles (the default Outdoors
 * style) return featureset results with NO source/sourceLayer at all, e.g.
 * `{ name, class: 'landform', group: 'natural-point' }` for a peak. Features
 * from our own GeoJSON layers (waypoint markers, tracks) always carry their
 * source id, so requiring "no source" excludes them on the Standard path.
 */
function findNearbyLabels(
  map: mapboxgl.Map,
  point: { x: number; y: number },
  tap: { lat: number; lng: number },
): NearbyLabels {
  const r = PLACE_NAME_SEARCH_RADIUS_PX;
  let features: mapboxgl.GeoJSONFeature[];
  try {
    features = map.queryRenderedFeatures([
      [point.x - r, point.y - r],
      [point.x + r, point.y + r],
    ]);
  } catch {
    return {};
  }
  let bestName: string | undefined;
  let bestNameDist = Infinity;
  let peak: import('./map-provider').PickedPeak | undefined;
  let bestPeakDist = Infinity;
  for (const f of features) {
    // Line/area labels (rivers, ridgelines) have no single "here" — skip them.
    if (f.geometry.type !== 'Point') continue;
    const name = f.properties?.name;
    if (typeof name !== 'string' || name.length === 0) continue;
    const isStyleLabel = f.sourceLayer
      ? PLACE_NAME_SOURCE_LAYERS.has(f.sourceLayer)
      : !f.source;
    if (!isStyleLabel) continue;
    const [lon, lat] = f.geometry.coordinates as [number, number];
    const p = map.project([lon, lat]);
    const d = Math.hypot(p.x - point.x, p.y - point.y);
    if (d < bestNameDist) {
      bestNameDist = d;
      bestName = name;
    }
    if (isPeakLabel(f) && d < bestPeakDist) {
      bestPeakDist = d;
      // Prefer the style's surveyed summit elevation (classic peak labels carry
      // it); the Standard style doesn't, so fall back to the terrain DEM read
      // AT the summit rather than at the tap.
      const surveyed = Number(f.properties?.elevation_m);
      const elevation = Number.isFinite(surveyed)
        ? surveyed
        : map.queryTerrainElevation([lon, lat], { exaggerated: false }) ?? undefined;
      peak = {
        name,
        lat,
        lon,
        distanceM: andoyerDistance(tap.lat, tap.lng, lat, lon),
        elevation: elevation ?? undefined,
        withinTapPx: d <= PEAK_AUTO_SNAP_RADIUS_PX,
      };
    }
  }
  return { placeName: bestName, peak };
}

/**
 * Create a MapBox map provider
 */
export function createMapBoxProvider(
  container: HTMLElement,
  options: import('./map-provider').MapProviderOptions = {},
): Promise<MapProvider> {
  const appControls = options.appControls ?? true;
  return new Promise((resolve, reject) => {
    try {
      // Get saved or default style
      const savedStyleId = config.getPreferences().mapStyle;
      const savedStyle = savedStyleId ? MAPBOX_STYLES.find(s => s.id === savedStyleId) : null;
      const initialStyle = savedStyle ?? MAPBOX_STYLES[0];

      const savedLocation = config.getMapLocation();
      const map = new mapboxgl.Map({
        container,
        accessToken: MAPBOX_ACCESS_TOKEN,
        style: initialStyle.style,
        center: savedLocation?.center,
        zoom: savedLocation?.zoom ?? 2,
        pitch: savedLocation?.pitch ?? 45,
        bearing: savedLocation?.bearing ?? 0,
        maxPitch: 85,
        localFontFamily: MAP_FONT_FAMILY,
      });

      // State
      let boundsChangeCallback: (() => void) | null = null;
      let currentFixes: IGCFix[] = [];
      let currentTask: XCTask | null = null;
      let currentEvents: FlightEvent[] = [];
      const eventMarkers: mapboxgl.Marker[] = [];
      let activePopup: mapboxgl.Popup | null = null;
      let activeMarkers: mapboxgl.Marker[] = [];
      let glideLegendElement: HTMLElement | null = null;
      let hudElement: HTMLElement | null = null;

      // Track time-scrub state (the score-details scrubber): the 2D track is
      // clipped to fixes[0..N] with a position dot at N. Geometry rebuilds
      // are rAF-batched so slider drags cost at most one rebuild per frame.
      let trackScrubIndex: number | null = null;
      let trackScrubMarker: mapboxgl.Marker | null = null;
      let trackScrubRaf: number | null = null;

      // 3D rendering state
      let tb: Threebox | null = null;
      let is3DMode = false;
      let threeDObjects: unknown[] = [];

      // Drone follow camera state
      let gliderMarker: unknown = null;
      let currentFixIndex = 0;
      let scrubberElement: HTMLElement | null = null;
      let compassElement: HTMLElement | null = null;

      // Camera follow state — tracks previous target to compute translation delta
      let cameraPrevLng = 0;
      let cameraPrevLat = 0;
      let cameraPrevAlt = 0;

      // Camera preset state
      type CameraPreset = 'side' | 'top' | 'behind' | 'front';
      let activeCameraPreset: CameraPreset = 'side';
      let cameraPresetControl: CameraPresetControl | null = null;

      // Task visibility state
      let isTaskVisible = true;

      // Track visibility state
      let isTrackVisible = true;

      // Speed overlay state (separate from activeMarkers so it persists across event selections)
      let isSpeedOverlayActive = false;

      // Multi-track state
      let multiTrackData: LoadedTrack[] = [];
      let multiTrackScores: PilotScore[] = [];
      // Open-distance scored lines (take-off exit → furthest fix, per pilot)
      let openDistanceLineData: OpenDistanceLine[] = [];
      // Landed-out routed distance-to-goal line (best-progress → TPs → goal)
      let bestProgressRouteData: BestProgressRoute | null = null;
      let multiTrackClickCallback: ((trackIndex: number, fixIndex: number) => void) | null = null;
      let isMultiTrackMode = false;
      // 3D multi-track state. The track polylines live for as long as the
      // multi-track view does; the scrubber's position markers are rebuilt on
      // every scrub. They are kept apart so a scrub can clear its own markers
      // without taking the tracks with them.
      let multiTrack3DObjects: unknown[] = [];
      let multiTrackMarkerObjects: unknown[] = [];
      let speedOverlayMarkers: mapboxgl.Marker[] = [];

      // HUD crosshair marker (separate from activeMarkers so segment markers aren't cleared)
      let hudCrosshairMarker: mapboxgl.Marker | null = null;

      function clearHudCrosshair(): void {
        if (hudCrosshairMarker) {
          hudCrosshairMarker.remove();
          hudCrosshairMarker = null;
        }
      }

      // Cached turnpoint sequence and optimized path (invalidated on track/task change)
      let cachedSequenceResult: TurnpointSequenceResult | null = null;
      let cachedOptimizedPath: { lat: number; lon: number }[] | null = null;

      // Pickable waypoint markers (task route editor); replayed on style reload
      type MapWaypoint = import('./map-provider').MapWaypoint;
      let waypointsData: MapWaypoint[] = [];
      // A tap this many screen px from a waypoint still picks it — sized for a
      // finger, so exact aim at the small marker is never required on touch.
      const WAYPOINT_TAP_TOLERANCE_PX = 44;

      // Click callbacks (mutable refs — registered once, updated via setter)
      let trackClickCallback: ((fixIndex: number) => void) | null = null;
      let turnpointClickCallback: ((turnpointIndex: number) => void) | null = null;
      let mapClickCallback: ((lat: number, lon: number, details?: MapPickDetails) => void) | null = null;
      let waypointsClickCallback: ((waypoint: MapWaypoint) => void) | null = null;

      // Annotation layer (created after map loads)
      let annotationLayer: MapAnnotationLayer | null = null;

      /** Hide glide speed labels when zoomed out and resolve screen-space collisions. */
      function updateGlideLabelVisibility(): void {
        const zoom = map.getZoom();

        // Collect all label markers that would pass zoom/sparse checks, with screen positions
        interface LabelInfo { el: HTMLElement; labelIndex: number; markerIdx: number; source: 'active' | 'overlay'; }
        const visibleLabels: LabelInfo[] = [];

        function collectFromActive(): void {
          for (let i = 0; i < activeMarkers.length; i++) {
            const el = activeMarkers[i].getElement();
            if (el.dataset.glideLabel === 'true') {
              const labelIndex = parseInt(el.dataset.labelIndex || '0', 10);
              visibleLabels.push({ el, labelIndex, markerIdx: i, source: 'active' });
            }
          }
        }

        function collectFromOverlay(): void {
          // speedOverlayMarkers: alternating chevron (2*i) and label (2*i+1)
          for (let i = 0; i < speedOverlayMarkers.length; i++) {
            const el = speedOverlayMarkers[i].getElement();
            if (el.dataset.glideLabel === 'true') {
              const labelIndex = parseInt(el.dataset.labelIndex || '0', 10);
              visibleLabels.push({ el, labelIndex, markerIdx: i, source: 'overlay' });
            }
          }
        }

        collectFromActive();
        collectFromOverlay();

        // Build screen positions for labels that pass zoom/sparse filters
        const screenPositions: import('./map-provider-shared').LabelScreenPos[] = [];
        const labelInfoByIndex = new Map<number, LabelInfo>();

        for (const info of visibleLabels) {
          const { el, labelIndex } = info;
          // Set format (compact vs detail) — skip zoom-based hiding since collision detection handles it
          updateGlideLabelElement(el, zoom, labelIndex, false, true);

          // Project to screen
          const marker = info.source === 'active' ? activeMarkers[info.markerIdx] : speedOverlayMarkers[info.markerIdx];
          const lngLat = marker.getLngLat();
          const point = map.project(lngLat);

          screenPositions.push({
            index: labelIndex,
            x: point.x,
            y: point.y,
            isFastest: el.dataset.fastest === 'true',
          });
          labelInfoByIndex.set(labelIndex, info);
        }

        // Compute which labels to hide due to overlap
        const occluded = computeOccludedLabels(screenPositions, zoom);

        // Apply occlusion: hide occluded labels and their paired chevrons
        for (const labelIndex of occluded) {
          const info = labelInfoByIndex.get(labelIndex);
          if (!info) continue;
          info.el.style.display = 'none';

          // Hide paired chevron (chevron is at markerIdx - 1 in speedOverlayMarkers)
          if (info.source === 'overlay' && info.markerIdx > 0) {
            const chevronEl = speedOverlayMarkers[info.markerIdx - 1].getElement();
            if (!chevronEl.dataset.glideLabel) {
              chevronEl.style.display = 'none';
            }
          }
        }

        // Show chevrons for non-occluded labels
        for (const [labelIndex, info] of labelInfoByIndex) {
          if (occluded.has(labelIndex)) continue;
          if (info.source === 'overlay' && info.markerIdx > 0) {
            const chevronEl = speedOverlayMarkers[info.markerIdx - 1].getElement();
            if (!chevronEl.dataset.glideLabel) {
              chevronEl.style.display = '';
            }
          }
        }
      }

      /** Lazily create and show/hide the glide legend */
      function showGlideLegend(show: boolean): void {
        if (show && !glideLegendElement) {
          glideLegendElement = createGlideLegend(container);
          glideLegendElement.style.display = 'none';
        }
        sharedShowGlideLegend(glideLegendElement, show);
      }

      /**
       * Resolve target altitude at a point — try terrain first, fall back to turnpoint altSmoothed.
       */
      function getElevationAtPoint(lat: number, lon: number, turnpointAltSmoothed: number | undefined): number | null {
        const terrainElev = map.queryTerrainElevation([lon, lat], { exaggerated: false });
        if (terrainElev != null) return terrainElev;
        if (turnpointAltSmoothed != null) return turnpointAltSmoothed;
        return null;
      }

      /**
       * Get the GlideContext for a glide starting at glideStartTime.
       * Finds the next turnpoint after the last one reached before glideStartTime.
       */
      function getNextTurnpointContext(glideStartTime: number): GlideContext | undefined {
        if (!currentTask || currentFixes.length === 0) return undefined;

        const cache = ensureTurnpointCache(currentTask, currentFixes, {
          sequenceResult: cachedSequenceResult,
          optimizedPath: cachedOptimizedPath,
        });
        cachedSequenceResult = cache.sequenceResult;
        cachedOptimizedPath = cache.optimizedPath;

        return buildNextTurnpointContext(
          currentTask, currentFixes, cache.sequenceResult, cache.optimizedPath,
          glideStartTime, getElevationAtPoint,
        );
      }

      /** Remove all speed overlay markers from the map (does not change isSpeedOverlayActive) */
      function clearSpeedOverlay(): void {
        for (const marker of speedOverlayMarkers) {
          marker.remove();
        }
        speedOverlayMarkers = [];
        updateGeoJSONSource(map, 'speed-fastest-segment', []);
      }

      /** Render speed overlay for all glide segments */
      function renderSpeedOverlay(): void {
        clearSpeedOverlay();
        if (currentFixes.length < 2) return;
        const segLen = getSegmentLengthMeters(config.getUnits().distance);

        // Treat the entire track as one continuous segment
        const markers = calculateGlideMarkers(currentFixes, getNextTurnpointContext, segLen);
        const positions = calculateGlidePositions(currentFixes, segLen / 2);

        // Find the fastest speed-label
        let fastestIdx = -1;
        let maxSpeed = -1;
        for (let i = 0; i < markers.length; i++) {
          if (markers[i].type === 'speed-label' && (markers[i].speedMps ?? 0) > maxSpeed) {
            maxSpeed = markers[i].speedMps ?? 0;
            fastestIdx = i;
          }
        }

        // Draw red polyline for the fastest segment
        if (fastestIdx >= 0 && positions.length > 0) {
          const startTime = fastestIdx > 0 ? positions[fastestIdx - 1].time : currentFixes[0].time.getTime();
          const endTime = fastestIdx + 1 < positions.length ? positions[fastestIdx + 1].time : currentFixes[currentFixes.length - 1].time.getTime();

          let startFixIdx = 0;
          for (let i = 0; i < currentFixes.length; i++) {
            if (currentFixes[i].time.getTime() >= startTime) { startFixIdx = i; break; }
          }
          let endFixIdx = currentFixes.length - 1;
          for (let i = 0; i < currentFixes.length; i++) {
            if (currentFixes[i].time.getTime() >= endTime) { endFixIdx = i; break; }
          }

          const segFixes = currentFixes.slice(startFixIdx, endFixIdx + 1);
          if (segFixes.length > 1) {
            const coordinates = segFixes.map(f => [f.longitude, f.latitude, f.gnssAltitude]);
            updateGeoJSONSource(map, 'speed-fastest-segment', [{
              type: 'Feature',
              properties: {},
              geometry: { type: 'LineString', coordinates },
            }]);
          }
        }

        const FASTEST_COLOR = '#ef4444';
        const NORMAL_COLOR = '#3b82f6';

        let labelIndex = 0;

        for (let i = 0; i < markers.length; i++) {
          const gm = markers[i];
          const isFastest = i === fastestIdx;
          const color = isFastest ? FASTEST_COLOR : NORMAL_COLOR;

          {
            // Chevron centered on the track point
            const chevronEl = document.createElement('div');
            chevronEl.style.cssText = 'display:flex;align-items:center;justify-content:center;';
            chevronEl.innerHTML = `<svg width="28" height="16" viewBox="0 0 20 12" style="transform:rotate(${gm.bearing}deg);">
              <path d="M2 10 L10 2 L18 10" fill="none" stroke="${color}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>`;
            const chevronMarker = new mapboxgl.Marker({
              element: chevronEl,
              rotationAlignment: 'map',
              pitchAlignment: 'map',
            })
              .setLngLat([gm.lon, gm.lat])
              .addTo(map);
            speedOverlayMarkers.push(chevronMarker);

            // Label below the chevron
            const { speed, altitude, detailText, reqText } = formatGlideLabel(gm);
            const speedDisplay = isFastest ? `${speed} (fastest)` : speed;
            const metricsLine = altitude ? `${speedDisplay}\u2002${altitude}` : speedDisplay;

            const labelEl = document.createElement('div');
            labelEl.style.cssText = `
              font-family: ${MAP_FONT_FAMILY};
              font-size: 20px;
              font-weight: 600;
              color: ${isFastest ? FASTEST_COLOR : '#333'};
              white-space: nowrap;
              text-shadow: ${GLIDE_LABEL_TEXT_SHADOW};
              text-align: center;
              line-height: 1.3;
            `;
            labelEl.innerHTML = reqText
              ? `${metricsLine}<br>${detailText}<br>${reqText}`
              : `${metricsLine}<br>${detailText}`;
            labelEl.dataset.glideLabel = 'true';
            labelEl.dataset.speedLabel = speedDisplay;
            labelEl.dataset.altLabel = altitude;
            labelEl.dataset.detailLabel = detailText;
            labelEl.dataset.reqLabel = reqText;
            labelEl.dataset.labelIndex = String(labelIndex);
            if (isFastest) labelEl.dataset.fastest = 'true';
            labelIndex++;

            const labelMarker = new mapboxgl.Marker({ element: labelEl, anchor: 'top', offset: [0, 12] })
              .setLngLat([gm.lon, gm.lat])
              .addTo(map);
            if (isFastest) labelMarker.getElement().style.zIndex = '1';
            speedOverlayMarkers.push(labelMarker);
          }
        }

        // Apply zoom-dependent label visibility
        updateGlideLabelVisibility();
      }

      /**
       * Clear all event-related highlights from the map
       * (segment highlight, markers, legend)
       */
      function clearEventHighlights(): void {
        // Remove popup if present
        if (activePopup) {
          activePopup.remove();
          activePopup = null;
        }

        // Remove all active markers (chevrons, speed labels, endpoint markers)
        for (const marker of activeMarkers) {
          marker.remove();
        }
        activeMarkers = [];

        clearHudCrosshair();

        // Clear highlight segment source
        updateGeoJSONSource(map, 'highlight-segment', []);

        // Hide glide legend and HUD
        showGlideLegend(false);
        sharedHideTrackPointHUD(hudElement);
      }

      /**
       * Add custom sources and layers for track/task visualization
       */
      function addCustomLayers(): void {
        // Remove existing custom layers to ensure correct ordering
        const customLayers = [
          'waypoint-labels',
          'waypoints',
          'multi-track-name-labels',
          'open-distance-labels',
          'open-distance-line',
          'task-segment-labels',
          'task-labels',
          'task-points',
          'highlight-segment',
          'speed-fastest-segment',
          'track-line',
          'track-line-outline',
          'task-goal-line',
          'task-exit-arrows',
          'task-cylinders-stroke',
          'task-cylinders-fill',
          'task-line-arrows',
          'task-line',
        ];
        for (const layerId of customLayers) {
          if (map.getLayer(layerId)) {
            map.removeLayer(layerId);
          }
        }

        // Add sources (only if they don't exist)
        // Track source with minimal simplification for visibility at all zoom levels
        if (!map.getSource('track')) {
          map.addSource('track', {
            type: 'geojson',
            data: { type: 'FeatureCollection', features: [] },
            tolerance: 0.1, // Minimal simplification
          });
        }

        // Multi-track source (used when multiple tracks are loaded in 'all' view)
        if (!map.getSource('multi-track')) {
          map.addSource('multi-track', {
            type: 'geojson',
            data: { type: 'FeatureCollection', features: [] },
            tolerance: 0.1,
          });
        }

        // Other sources with default simplification
        const sourcesToAdd = ['task-line', 'task-points', 'task-cylinders', 'task-exit-arrows', 'task-goal-line', 'task-segment-labels', 'highlight-segment', 'speed-fastest-segment', 'open-distance-lines', 'best-progress-route', 'multi-track-names', 'waypoints'];
        for (const sourceId of sourcesToAdd) {
          if (!map.getSource(sourceId)) {
            map.addSource(sourceId, {
              type: 'geojson',
              data: { type: 'FeatureCollection', features: [] },
            });
          }
        }

        // Add layers in order from bottom to top
        const width_mul = 0.7;

        // 1. Task line (dashed route with directional arrows)
        map.addLayer({
          id: 'task-line',
          type: 'line',
          source: 'task-line',
          layout: {
            'line-join': 'round',
            'line-cap': 'round',
          },
          paint: {
            'line-color': '#f97316',
            'line-width': 2,
            'line-dasharray': [4, 4],
            'line-opacity': 0.8,
          },
        });

        // 1b. Arrow icons along task line to show direction
        if (!map.hasImage('task-arrow')) {
          const size = 20;
          const canvas = document.createElement('canvas');
          canvas.width = size;
          canvas.height = size;
          const ctx = canvas.getContext('2d')!;
          // Orange arrow matching the optimized route line color
          ctx.beginPath();
          ctx.moveTo(size, size / 2);     // right tip
          ctx.lineTo(1, 1);               // top-left
          ctx.lineTo(1, size - 1);        // bottom-left
          ctx.closePath();
          ctx.fillStyle = '#f97316';
          ctx.globalAlpha = 0.8;
          ctx.fill();
          const imageData = ctx.getImageData(0, 0, size, size);
          map.addImage('task-arrow', { width: size, height: size, data: new Uint8Array(imageData.data.buffer) });
        }

        map.addLayer({
          id: 'task-line-arrows',
          type: 'symbol',
          source: 'task-line',
          layout: {
            'symbol-placement': 'line',
            'symbol-spacing': 40,
            'icon-image': 'task-arrow',
            'icon-size': 0.55,
            'icon-allow-overlap': true,
            'icon-rotation-alignment': 'map',
          },
        });

        // 2. Task cylinders fill
        map.addLayer({
          id: 'task-cylinders-fill',
          type: 'fill',
          source: 'task-cylinders',
          paint: {
            'fill-color': [
              'case',
              ['==', ['get', 'type'], 'SSS'], '#22c55e',
              ['==', ['get', 'type'], 'ESS'], '#eab308',
              ['==', ['get', 'type'], 'TAKEOFF'], '#3b82f6',
              '#a855f7',
            ],
            'fill-opacity': 0.15,
          },
        });

        // 3. Task cylinders stroke
        map.addLayer({
          id: 'task-cylinders-stroke',
          type: 'line',
          source: 'task-cylinders',
          paint: {
            'line-color': [
              'case',
              ['==', ['get', 'type'], 'SSS'], '#22c55e',
              ['==', ['get', 'type'], 'ESS'], '#eab308',
              ['==', ['get', 'type'], 'TAKEOFF'], '#3b82f6',
              '#a855f7',
            ],
            'line-width': 2,
            'line-opacity': 0.8,
          },
        });

        // 3a-bis. Exit-turnpoint arrowheads: solid outward-pointing
        // triangles on the rings of inferred exit cylinders (see
        // exitTurnpointArrowFeatures / mapbox-interactions-spec.md).
        map.addLayer({
          id: 'task-exit-arrows',
          type: 'fill',
          source: 'task-exit-arrows',
          paint: {
            'fill-color': '#a855f7',
            'fill-opacity': 0.9,
          },
        });

        // 3b. Goal line (LINE goals only): the line the pilot must cross,
        // drawn heavier than a cylinder stroke; its control semicircle is a
        // regular task-cylinders feature behind it.
        map.addLayer({
          id: 'task-goal-line',
          type: 'line',
          source: 'task-goal-line',
          layout: {
            'line-cap': 'round',
          },
          paint: {
            'line-color': '#a855f7',
            'line-width': 4,
            'line-opacity': 0.9,
          },
        });

        // 4. Track outline (shadow for visibility)
        map.addLayer({
          id: 'track-line-outline',
          type: 'line',
          source: 'track',
          layout: {
            'line-join': 'round',
            'line-cap': 'round',
          },
          paint: {
            'line-color': '#000000',
            // Altitude-adaptive width: wider at high altitude for depth effect
            'line-width': [
              'interpolate', ['linear'], ['zoom'],
              3, ['interpolate', ['linear'], ['get', 'normalizedAlt'], 0, 4 * width_mul, 1, 12 * width_mul],
              8, ['interpolate', ['linear'], ['get', 'normalizedAlt'], 0, 6 * width_mul, 1, 18 * width_mul],
              12, ['interpolate', ['linear'], ['get', 'normalizedAlt'], 0, 5 * width_mul, 1, 16 * width_mul],
            ],
            'line-opacity': 0.6,
          },
        });

        // 5. Track line with altitude-based colors and width
        map.addLayer({
          id: 'track-line',
          type: 'line',
          source: 'track',
          layout: {
            'line-join': 'round',
            'line-cap': 'round',
          },
          paint: {
            // Altitude-based coloring: brown (low) → green → cyan → sky blue (high)
            'line-color': [
              'interpolate', ['linear'], ['get', 'normalizedAlt'],
              0, '#8B5A2B',
              0.25, '#43A047',
              0.5, '#039BE5',
              0.75, '#29B6F6',
              1, '#4FC3F7',
            ],
            'line-width': [
              'interpolate', ['linear'], ['zoom'],
              3, ['interpolate', ['linear'], ['get', 'normalizedAlt'], 0, 2 * width_mul, 1, 6 * width_mul],
              8, ['interpolate', ['linear'], ['get', 'normalizedAlt'], 0, 3 * width_mul, 1, 9 * width_mul],
              12, ['interpolate', ['linear'], ['get', 'normalizedAlt'], 0, 3 * width_mul, 1, 9 * width_mul],
            ],
            'line-opacity': 0.95,
          },
        });

        // 5a-multi. Multi-track outline layer
        map.addLayer({
          id: 'multi-track-outline',
          type: 'line',
          source: 'multi-track',
          layout: {
            'line-join': 'round',
            'line-cap': 'round',
            'visibility': 'none',
          },
          paint: {
            'line-color': '#000000',
            'line-width': ['interpolate', ['linear'], ['zoom'], 3, 4, 8, 6, 12, 5],
            'line-opacity': 0.4,
          },
        });

        // 5a-multi. Multi-track colored line layer
        map.addLayer({
          id: 'multi-track-line',
          type: 'line',
          source: 'multi-track',
          layout: {
            'line-join': 'round',
            'line-cap': 'round',
            'visibility': 'none',
          },
          paint: {
            'line-color': ['get', 'color'],
            'line-width': ['interpolate', ['linear'], ['zoom'], 3, 2, 8, 4, 12, 4],
            'line-opacity': 0.9,
          },
        });

        // 5b. Highlight segment (for selected events)
        map.addLayer({
          id: 'highlight-segment',
          type: 'line',
          source: 'highlight-segment',
          layout: {
            'line-join': 'round',
            'line-cap': 'round',
          },
          paint: {
            'line-color': '#00ffff',
            'line-width': 6,
            'line-opacity': 0.9,
          },
        });

        // 5c. Speed fastest segment (red overlay for fastest speed segment)
        map.addLayer({
          id: 'speed-fastest-segment',
          type: 'line',
          source: 'speed-fastest-segment',
          layout: {
            'line-join': 'round',
            'line-cap': 'round',
          },
          paint: {
            'line-color': '#ef4444',
            'line-width': 6,
            'line-opacity': 0.9,
          },
        });

        // 6. Task points (turnpoint circles)
        map.addLayer({
          id: 'task-points',
          type: 'circle',
          source: 'task-points',
          paint: {
            'circle-radius': 6,
            'circle-color': [
              'case',
              ['==', ['get', 'type'], 'SSS'], '#22c55e',
              ['==', ['get', 'type'], 'ESS'], '#eab308',
              ['==', ['get', 'type'], 'TAKEOFF'], '#3b82f6',
              '#a855f7',
            ],
            'circle-stroke-width': 2,
            'circle-stroke-color': '#ffffff',
          },
        });

        // 7. Task point labels
        map.addLayer({
          id: 'task-labels',
          type: 'symbol',
          source: 'task-points',
          layout: {
            'text-field': ['get', 'name'],
            'text-size': 20,
            'text-offset': [0, 1.5],
            'text-anchor': 'top',
          },
          paint: {
            'text-color': '#1e293b',
            'text-halo-color': '#ffffff',
            'text-halo-width': 2,
          },
        });

        // 7b. Pickable waypoint markers (task route editor) — loaded from a
        // waypoint file, drawn as secondary slate dots the user can click to
        // add as turnpoints. Labels appear only when zoomed in, to avoid
        // clutter when a whole regional database is on screen.
        map.addLayer({
          id: 'waypoints',
          type: 'circle',
          source: 'waypoints',
          paint: {
            'circle-radius': 5,
            'circle-color': '#64748b',
            'circle-stroke-width': 1.5,
            'circle-stroke-color': '#ffffff',
            'circle-opacity': 0.9,
          },
        });
        map.addLayer({
          id: 'waypoint-labels',
          type: 'symbol',
          source: 'waypoints',
          minzoom: 10,
          layout: {
            'text-field': ['get', 'code'],
            'text-size': 11,
            'text-offset': [0, 1.1],
            'text-anchor': 'top',
            'text-allow-overlap': false,
          },
          paint: {
            'text-color': '#475569',
            'text-halo-color': '#ffffff',
            'text-halo-width': 1.5,
          },
        });

        // 8. Task segment distance labels
        map.addLayer({
          id: 'task-segment-labels',
          type: 'symbol',
          source: 'task-segment-labels',
          layout: {
            'text-field': ['get', 'distance'],
            'text-size': 16,
            'text-rotate': ['get', 'bearing'],
            'text-rotation-alignment': 'map',
            'text-offset': [0, 0],
            'text-anchor': 'center',
          },
          paint: {
            'text-color': '#f97316',
            'text-halo-color': '#eeeeee',
            'text-halo-width': 2,
          },
        });

        // 9. Open-distance scored lines (take-off exit → furthest fix, per pilot)
        map.addLayer({
          id: 'open-distance-line',
          type: 'line',
          source: 'open-distance-lines',
          layout: {
            'line-join': 'round',
            'line-cap': 'round',
          },
          paint: {
            'line-color': '#f97316',
            'line-width': 2,
            'line-dasharray': [4, 4],
            'line-opacity': 0.8,
          },
        });

        // 9b. Distance label riding along each open-distance line
        map.addLayer({
          id: 'open-distance-labels',
          type: 'symbol',
          source: 'open-distance-lines',
          layout: {
            'symbol-placement': 'line-center',
            'text-field': ['get', 'label'],
            'text-size': 16,
            'text-offset': [0, -0.8],
          },
          paint: {
            'text-color': '#f97316',
            'text-halo-color': '#eeeeee',
            'text-halo-width': 2,
          },
        });

        // 9c. Landed-out routed distance-to-goal line (best-progress point →
        // un-reached turnpoints → goal). Solid amber so it reads as distinct
        // from the dashed orange task line it runs alongside.
        map.addLayer({
          id: 'best-progress-route-line',
          type: 'line',
          source: 'best-progress-route',
          layout: {
            'line-join': 'round',
            'line-cap': 'round',
          },
          paint: {
            'line-color': '#f59e0b',
            'line-width': 2.5,
            'line-opacity': 0.9,
          },
        });

        // 9d. Remaining-distance label riding along the best-progress route
        map.addLayer({
          id: 'best-progress-route-label',
          type: 'symbol',
          source: 'best-progress-route',
          layout: {
            'symbol-placement': 'line-center',
            'text-field': ['get', 'label'],
            'text-size': 15,
            'text-offset': [0, -0.8],
          },
          paint: {
            'text-color': '#b45309',
            'text-halo-color': '#ffffff',
            'text-halo-width': 2,
          },
        });

        // 10. Pilot name at each track's landing point (multi-track mode) so
        // tracks are attributable when the whole field is on screen
        map.addLayer({
          id: 'multi-track-name-labels',
          type: 'symbol',
          source: 'multi-track-names',
          layout: {
            'text-field': ['get', 'name'],
            'text-size': 13,
            'text-anchor': 'left',
            'text-offset': [0.6, 0],
          },
          paint: {
            'text-color': ['get', 'color'],
            'text-halo-color': '#ffffff',
            'text-halo-width': 2,
          },
        });
      }

      /**
       * Restore data after style change
       */
      function restoreData(): void {
        if (currentFixes.length > 0) {
          // setTrack resets the scrub (it's a new track as far as the
          // provider knows) — re-apply it so a style change doesn't lose
          // the scrubbed view.
          const scrub = trackScrubIndex;
          renderer.setTrack(currentFixes);
          if (scrub != null) renderer.setTrackScrub?.(scrub);
        }
        if (currentTask) {
          renderer.setTask(currentTask);
        }
        if (currentEvents.length > 0) {
          renderer.setEvents(currentEvents);
        }
        if (openDistanceLineData.length > 0) {
          renderer.setOpenDistanceLines?.(openDistanceLineData);
        }
        if (bestProgressRouteData) {
          renderer.setBestProgressRoute?.(bestProgressRouteData);
        }
        if (waypointsData.length > 0) {
          renderer.setWaypoints?.(waypointsData);
        }
        updateTrackRendering();
      }

      // ── Track time-scrub (score-details scrubber) ──

      /**
       * Redraw the 'track' source clipped to fixes[0..index] (null = whole
       * flight). Altitude colours stay normalised against the FULL track so
       * they don't shift while scrubbing.
       */
      function renderTrackScrubClip(index: number | null): void {
        if (currentFixes.length < 2) return;
        const { minAlt, altRange } = calculateAltitudeRange(currentFixes);
        const upTo = index == null ? currentFixes.length : Math.max(2, index + 1);
        const fixes = upTo >= currentFixes.length ? currentFixes : currentFixes.slice(0, upTo);
        updateGeoJSONSource(map, 'track', buildTrackFeatures(fixes, altRange, minAlt));
      }

      function updateTrackScrubMarker(index: number): void {
        const fix = currentFixes[index];
        if (!fix) return;
        if (!trackScrubMarker) {
          // A GPS-style position dot: white ring so it reads on any terrain.
          const el = document.createElement('div');
          el.style.cssText =
            'width:14px;height:14px;border-radius:50%;background:#3b82f6;' +
            'border:2.5px solid #fff;box-shadow:0 0 4px rgba(0,0,0,0.5);';
          trackScrubMarker = new mapboxgl.Marker({ element: el })
            .setLngLat([fix.longitude, fix.latitude])
            .addTo(map);
        } else {
          trackScrubMarker.setLngLat([fix.longitude, fix.latitude]);
        }
        trackScrubMarker.getElement().style.display = isTrackVisible ? '' : 'none';
      }

      function clearTrackScrub(): void {
        if (trackScrubRaf != null) {
          cancelAnimationFrame(trackScrubRaf);
          trackScrubRaf = null;
        }
        trackScrubIndex = null;
        trackScrubMarker?.remove();
        trackScrubMarker = null;
      }

      // Custom panel toggle control (top-right, added first so it's topmost)
      let panelToggleCallback: (() => void) | null = null;
      let panelToggleBtn: HTMLElement | null = null;
      class PanelToggleControl implements mapboxgl.IControl {
        private container: HTMLElement | null = null;
        onAdd(): HTMLElement {
          this.container = document.createElement('div');
          this.container.className = 'mapboxgl-ctrl mapboxgl-ctrl-group';
          const btn = document.createElement('button');
          panelToggleBtn = btn;
          btn.type = 'button';
          btn.title = 'Toggle analysis panel';
          btn.setAttribute('aria-label', 'Toggle analysis panel');
          btn.style.cssText = 'display:flex;align-items:center;gap:6px;height:36px;padding:0 10px;border:none;cursor:pointer;background:transparent;color:#333;font-size:13px;font-weight:500;white-space:nowrap;';
          // Bar-chart icon + label (label hidden on mobile via media query class)
          btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" x2="12" y1="20" y2="10"/><line x1="18" x2="18" y1="20" y2="4"/><line x1="6" x2="6" y1="20" y2="16"/></svg><span class="mapctl-label">Analysis</span>`;
          btn.addEventListener('click', () => panelToggleCallback?.());
          this.container.appendChild(btn);
          return this.container;
        }
        onRemove(): void {
          this.container?.remove();
          this.container = null;
          panelToggleBtn = null;
        }
      }
      if (appControls) map.addControl(new PanelToggleControl(), 'top-right');

      // Navigation controls (top-right, below panel toggle)
      map.addControl(new mapboxgl.NavigationControl({ visualizePitch: true }));

      // "Where am I" — the only landmark a first-time organiser has when the
      // competition has no waypoints yet and the map opens on the whole globe.
      // Not gated on appControls: the route and waypoint editors are exactly
      // who needs it. It costs nothing (browser geolocation, no Mapbox request)
      // and self-disables when the browser has no geolocation or the page isn't
      // a secure context. maxZoom caps the fit at region scale — the default
      // (15) lands on the user's street, which is no use for laying out a task.
      map.addControl(
        new mapboxgl.GeolocateControl({
          positionOptions: { enableHighAccuracy: true },
          fitBoundsOptions: { maxZoom: 11 },
          trackUserLocation: false,
          showUserLocation: true,
        }),
      );
      if (appControls) map.addControl(new mapboxgl.FullscreenControl());
      map.addControl(new mapboxgl.ScaleControl({ maxWidth: 200 }));

      // The large compass overlay is analysis-page chrome — embedded maps
      // (score details) rely on NavigationControl's built-in compass, and the
      // embedding page provides its own expand/restore control (the native
      // FullscreenControl self-hides on iOS, where the Fullscreen API is
      // unavailable).
      if (appControls) createCompass();

      // Custom menu button control (top-left, added first so it's topmost)
      let menuButtonCallback: (() => void) | null = null;
      let menuButtonContainer: HTMLElement | null = null;
      // Interaction mode — controls which click/hover handlers are active
      type MapInteractionMode = import('./map-provider').MapInteractionMode;
      let interactionMode: MapInteractionMode = 'view';
      let isHoveringInteractive = false;

      function syncCursor(): void {
        // A pickable waypoint under the pointer always wins — even in
        // add-waypoint mode, so it reads as "click this point, not the ground".
        if (isHoveringInteractive) {
          map.getCanvas().style.cursor = 'pointer';
          return;
        }
        if (interactionMode !== 'view') {
          map.getCanvas().style.cursor = 'crosshair';
          return;
        }
        map.getCanvas().style.cursor = '';
      }
      class MenuButtonControl implements mapboxgl.IControl {
        private container: HTMLElement | null = null;
        onAdd(): HTMLElement {
          this.container = document.createElement('div');
          this.container.className = 'mapboxgl-ctrl mapboxgl-ctrl-group';
          menuButtonContainer = this.container;
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.title = 'Menu (\u2318K)';
          btn.setAttribute('aria-label', 'Menu (\u2318K)');
          btn.style.cssText = 'display:flex;align-items:center;gap:6px;height:36px;padding:0 10px;border:none;cursor:pointer;background:transparent;color:#333;font-size:13px;font-weight:500;white-space:nowrap;';
          const isMac = /Mac|iPhone|iPad/.test(navigator.platform ?? '');
          const kbdHint = isMac ? '\u2318K' : 'Ctrl+K';
          btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg><span class="mapctl-label">Menu</span><kbd class="mapctl-label" style="font-size:11px;padding:1px 5px;border-radius:3px;background:rgba(0,0,0,0.08);color:#333;opacity:0.6;font-family:inherit;">${kbdHint}</kbd>`;
          btn.addEventListener('click', () => menuButtonCallback?.());
          this.container.appendChild(btn);
          return this.container;
        }
        onRemove(): void {
          this.container?.remove();
          this.container = null;
          menuButtonContainer = null;
        }
      }
      if (appControls) map.addControl(new MenuButtonControl(), 'top-left');

      // Style selector control (top-left, below menu button)
      class MapBoxStyleControl implements mapboxgl.IControl {
        private container: HTMLElement | null = null;

        onAdd(): HTMLElement {
          this.container = document.createElement('div');
          this.container.className = 'mapboxgl-ctrl mapboxgl-ctrl-group';

          const select = document.createElement('select');
          select.style.cssText = 'padding: 6px 8px; border: none; background: white; color: #1e293b; cursor: pointer; font-size: 12px;';

          for (const style of MAPBOX_STYLES) {
            const option = document.createElement('option');
            option.value = style.id;
            option.textContent = style.name;
            select.appendChild(option);
          }

          select.value = initialStyle.id;

          select.addEventListener('change', () => {
            const selectedStyle = MAPBOX_STYLES.find(s => s.id === select.value);
            if (selectedStyle) {
              map.setStyle(selectedStyle.style);
              config.setPreferences({ mapStyle: selectedStyle.id });
            }
          });

          this.container.appendChild(select);
          return this.container;
        }

        onRemove(): void {
          this.container?.remove();
          this.container = null;
        }
      }

      map.addControl(new MapBoxStyleControl(), 'top-left');

      // Camera preset control (shown only in 3D mode)
      const CAMERA_PRESETS: { id: CameraPreset; label: string; icon: string }[] = [
        { id: 'side', label: 'Side', icon: '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>' },
        { id: 'top', label: 'Top', icon: '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="1"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="10"/></svg>' },
        { id: 'behind', label: 'Behind', icon: '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V5"/><path d="m5 12 7-7 7 7"/></svg>' },
        { id: 'front', label: 'Front', icon: '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14"/><path d="m19 12-7 7-7-7"/></svg>' },
      ];

      class CameraPresetControl {
        private el: HTMLElement | null = null;
        private buttons: Map<CameraPreset, HTMLButtonElement> = new Map();

        create(): void {
          if (this.el) return;
          this.el = document.createElement('div');
          this.el.style.cssText = 'position:absolute;top:8px;left:50%;transform:translateX(-50%);z-index:10;display:flex;gap:0;border-radius:6px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,0.3);';

          for (const preset of CAMERA_PRESETS) {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.title = preset.label;
            btn.style.cssText = 'display:flex;align-items:center;justify-content:center;gap:3px;padding:6px 10px;border:none;cursor:pointer;font-size:11px;font-family:inherit;color:#1e293b;background:white;border-right:1px solid #e2e8f0;';
            btn.innerHTML = `${preset.icon}<span>${preset.label}</span>`;
            if (preset.id === activeCameraPreset) {
              btn.style.background = '#e2e8f0';
              btn.style.fontWeight = 'bold';
            }
            btn.addEventListener('click', () => {
              applyCameraPreset(preset.id);
              this.updateActive(preset.id);
            });
            this.buttons.set(preset.id, btn);
            this.el.appendChild(btn);
          }
          // Remove border-right from last button
          const lastBtn = this.el.lastElementChild as HTMLElement;
          if (lastBtn) lastBtn.style.borderRight = 'none';

          map.getContainer().appendChild(this.el);
        }

        updateActive(id: CameraPreset): void {
          for (const [presetId, btn] of this.buttons) {
            if (presetId === id) {
              btn.style.background = '#e2e8f0';
              btn.style.fontWeight = 'bold';
            } else {
              btn.style.background = 'white';
              btn.style.fontWeight = '';
            }
          }
        }

        remove(): void {
          this.el?.remove();
          this.el = null;
          this.buttons.clear();
        }
      }

      cameraPresetControl = new CameraPresetControl();

      // Handle style changes
      let isInitialLoad = true;
      map.on('style.load', () => {
        // Add 3D terrain
        if (!map.getSource('mapbox-dem')) {
          map.addSource('mapbox-dem', {
            type: 'raster-dem',
            url: 'mapbox://mapbox.mapbox-terrain-dem-v1',
            tileSize: 512,
            maxzoom: 14,
          });
        }
        map.setTerrain({ source: 'mapbox-dem', exaggeration: TERRAIN_EXAGGERATION });

        // Add sky layer for atmosphere effect
        if (!map.getLayer('sky')) {
          map.addLayer({
            id: 'sky',
            type: 'sky',
            paint: {
              'sky-type': 'atmosphere',
              'sky-atmosphere-sun': [0.0, 90.0],
              'sky-atmosphere-sun-intensity': 15,
            },
          });
        }

        addCustomLayers();

        // Recreate Threebox after style changes — setStyle() removes all layers
        // and may trigger a WebGL context loss/restore cycle.
        // IMPORTANT: Do NOT call tb.dispose() — it crashes on a lost WebGL context
        // and corrupts the shared GL state, breaking the entire map.
        // On initial load, tb is still null; it's created in the 'load' handler.
        if (tb) {
          // Abandon old instance (GC will clean it up) and clear stale references
          tb = null;
          threeDObjects = [];

          const gl = map.getCanvas().getContext('webgl2') || map.getCanvas().getContext('webgl');
          tb = new Threebox(map, gl, { defaultLights: true });

          map.addLayer({
            id: 'threebox-layer',
            type: 'custom',
            renderingMode: '3d',
            onAdd: function () {
              // Layer added
            },
            render: function () {
              if (!tb) return;
              try {
                tb.update();
              } catch {
                // Ignore errors during WebGL context loss transitions
              }
            },
          });
        }

        if (!isInitialLoad) {
          restoreData();
          // Re-create glider marker after style change if in 3D drone follow mode
          if (is3DMode && currentFixes.length > 0) {
            gliderMarker = null; // Old marker was in the abandoned Threebox instance
            updateGliderMarker(currentFixIndex);
          }
        }
      });

      // Keep glide labels hidden while zoomed out.
      map.on('zoom', updateGlideLabelVisibility);

      function findNearestFixIndex(clickLat: number, clickLon: number): number {
        return sharedFindNearestFixIndex(currentFixes, clickLat, clickLon);
      }

      map.on('load', () => {
        isInitialLoad = false;

        // Initialize Threebox for 3D rendering.
        // Mapbox GL JS v3 uses WebGL2; pass the matching context so Threebox
        // shares it rather than relying on Three.js fallback behaviour.
        const gl = map.getCanvas().getContext('webgl2') || map.getCanvas().getContext('webgl');
        tb = new Threebox(
          map,
          gl,
          {
            defaultLights: true,
          }
        );

        // Add custom layer for Threebox rendering
        map.addLayer({
          id: 'threebox-layer',
          type: 'custom',
          renderingMode: '3d',
          onAdd: function () {
            // Layer added
          },
          render: function () {
            if (!tb) return;
            try {
              tb.update();
            } catch {
              // Ignore errors during WebGL context loss transitions
            }
          },
        });

        // Track click and hover handlers
        const trackLayers = ['track-line', 'track-line-outline'];

        // Click handler for track
        for (const layerId of trackLayers) {
          map.on('click', layerId, (e) => {
            if (interactionMode !== 'view') return;
            if (!trackClickCallback || currentFixes.length === 0) return;
            if (!isTrackVisible) return;

            const { lng, lat } = e.lngLat;
            const fixIndex = findNearestFixIndex(lat, lng);
            if (fixIndex >= 0) {
              trackClickCallback(fixIndex);
            }
          });
        }

        // Hover effects - change cursor to pointer when hovering over track
        for (const layerId of trackLayers) {
          map.on('mouseenter', layerId, () => {
            if (interactionMode !== 'view') return;
            if (currentFixes.length === 0 || !isTrackVisible) return;
            isHoveringInteractive = true;
            syncCursor();
          });

          map.on('mouseleave', layerId, () => {
            isHoveringInteractive = false;
            syncCursor();
          });
        }

        // Turnpoint click handler
        map.on('click', 'task-points', (e) => {
          if (interactionMode !== 'view') return;
          if (!turnpointClickCallback || !currentTask || !isTaskVisible) return;
          if (!e.features || e.features.length === 0) return;

          // Find which turnpoint was clicked based on coordinates
          const clickedCoords = e.features[0].geometry;
          if (clickedCoords.type !== 'Point') return;

          const [clickLon, clickLat] = clickedCoords.coordinates;

          // Find the matching turnpoint index
          for (let i = 0; i < currentTask.turnpoints.length; i++) {
            const tp = currentTask.turnpoints[i];
            if (Math.abs(tp.waypoint.lon - clickLon) < 0.0001 &&
                Math.abs(tp.waypoint.lat - clickLat) < 0.0001) {
              turnpointClickCallback(i);
              break;
            }
          }
        });

        // Hover effects for turnpoints
        map.on('mouseenter', 'task-points', () => {
          if (interactionMode !== 'view') return;
          if (!currentTask || !isTaskVisible) return;
          isHoveringInteractive = true;
          syncCursor();
        });

        map.on('mouseleave', 'task-points', () => {
          isHoveringInteractive = false;
          syncCursor();
        });

        // Multi-track click handler
        map.on('click', 'multi-track-line', (e) => {
          if (interactionMode !== 'view') return;
          if (!multiTrackClickCallback || !isMultiTrackMode) return;
          if (!e.features || e.features.length === 0) return;

          const feature = e.features[0];
          const trackIndex = feature.properties?.trackIndex;
          if (trackIndex === undefined) return;

          const track = multiTrackData[trackIndex];
          if (!track) return;

          const { lng, lat } = e.lngLat;
          // Find nearest fix in this track
          let bestIdx = 0;
          let bestDist = Infinity;
          for (let i = 0; i < track.fixes.length; i++) {
            const dx = track.fixes[i].longitude - lng;
            const dy = track.fixes[i].latitude - lat;
            const d = dx * dx + dy * dy;
            if (d < bestDist) {
              bestDist = d;
              bestIdx = i;
            }
          }
          multiTrackClickCallback(trackIndex, bestIdx);
        });

        map.on('mouseenter', 'multi-track-line', () => {
          if (interactionMode !== 'view' || !isMultiTrackMode) return;
          isHoveringInteractive = true;
          syncCursor();
        });
        map.on('mouseleave', 'multi-track-line', () => {
          if (!isMultiTrackMode) return;
          isHoveringInteractive = false;
          syncCursor();
        });

        // Route editor picking. In select mode (view) a tap picks the NEAREST
        // loaded waypoint within a finger-friendly tolerance — aiming exactly at
        // the small marker isn't needed, which is what made picking impossible on
        // touch. In add-waypoint mode a tap instead reports the ground point so
        // the editor can place a brand-new waypoint there.
        map.on('click', (e: mapboxgl.MapMouseEvent) => {
          if (interactionMode === 'add-waypoint') {
            // Ground elevation from the terrain DEM (metres AMSL, un-exaggerated).
            // Null when the DEM tile isn't loaded — report undefined, never 0.
            const elevation = map.queryTerrainElevation(e.lngLat, { exaggerated: false });
            const { placeName, peak } = findNearbyLabels(map, e.point, e.lngLat);
            mapClickCallback?.(e.lngLat.lat, e.lngLat.lng, {
              elevation: elevation ?? undefined,
              placeName,
              peak,
            });
            return;
          }
          if (!waypointsClickCallback || waypointsData.length === 0) return;
          let best: MapWaypoint | null = null;
          let bestDist = WAYPOINT_TAP_TOLERANCE_PX;
          for (const w of waypointsData) {
            const p = map.project([w.lon, w.lat]);
            const d = Math.hypot(p.x - e.point.x, p.y - e.point.y);
            if (d <= bestDist) {
              bestDist = d;
              best = w;
            }
          }
          if (best) waypointsClickCallback(best);
        });

        // Create annotation overlay
        annotationLayer = createMapAnnotationLayer(map, container);

        resolve(renderer);
      });

      map.on('error', (e) => {
        console.error('MapBox error:', e.error);
      });

      // Keep compass in sync with camera bearing/pitch
      map.on('move', updateCompassTransform);

      // Track bounds changes and persist map location
      let saveLocationTimer: ReturnType<typeof setTimeout> | null = null;
      map.on('moveend', () => {
        updateGlideLabelVisibility();
        if (boundsChangeCallback) {
          boundsChangeCallback();
        }
        // Debounce saving to avoid excessive localStorage writes during animations
        if (saveLocationTimer) clearTimeout(saveLocationTimer);
        saveLocationTimer = setTimeout(() => {
          const center = map.getCenter();
          config.setMapLocation({
            center: [center.lng, center.lat],
            zoom: map.getZoom(),
            pitch: map.getPitch(),
            bearing: map.getBearing(),
          });
        }, 5000);
      });

      /**
       * Clear all 3D objects from the scene
       */
      function clear3DTrack(): void {
        if (!tb) return;
        for (const obj of threeDObjects) {
          tb.remove(obj);
        }
        threeDObjects = [];
      }

      /**
       * Render the track as 3D tubes using Threebox
       */
      function render3DTrack(fixes: IGCFix[]): void {
        if (!tb || fixes.length < 2) return;

        clear3DTrack();

        // Calculate min and max altitude for color scaling
        const { minAlt, altRange } = calculateAltitudeRange(fixes);

        // Create line segments for the track
        // We'll create the track as connected line segments with altitude
        // Scale altitude by terrain exaggeration so the track stays above the
        // visually exaggerated terrain surface (otherwise it clips into terrain
        // when viewed from directly above).
        for (let i = 1; i < fixes.length; i++) {
          const prev = fixes[i - 1];
          const curr = fixes[i];

          // Normalize altitude for color
          const normalizedAlt = altRange > 0 ? (prev.gnssAltitude - minAlt) / altRange : 0;

          // Create a line segment between consecutive points
          // Threebox uses [longitude, latitude, altitude] format
          const lineSegment = tb.line({
            geometry: [
              [prev.longitude, prev.latitude, prev.gnssAltitude * TERRAIN_EXAGGERATION],
              [curr.longitude, curr.latitude, curr.gnssAltitude * TERRAIN_EXAGGERATION],
            ],
            color: getAltitudeColorNormalized(normalizedAlt),
            width: 3,
            opacity: 0.9,
          });
          // Disable depth testing so the track renders on top of terrain
          // (prevents z-fighting when viewed from directly above)
          const lsMat = (lineSegment as { material?: { depthTest: boolean } }).material;
          if (lsMat) lsMat.depthTest = false;
          tb.add(lineSegment);
          threeDObjects.push(lineSegment);
        }

        // Add vertical "drop lines" once per km for depth perception
        if (SHOW_DROP_LINES) {
          const DROP_LINE_INTERVAL_M = 1000;
          const DEG_TO_RAD = Math.PI / 180;
          const R = 6371000; // Earth radius in meters
          let distAccum = 0;
          for (let i = 0; i < fixes.length; i++) {
            if (i > 0) {
              // Fast equirectangular approximation — accurate enough for 1km spacing
              const dLat = (fixes[i].latitude - fixes[i - 1].latitude) * DEG_TO_RAD;
              const dLon = (fixes[i].longitude - fixes[i - 1].longitude) * DEG_TO_RAD;
              const cosLat = Math.cos((fixes[i - 1].latitude + fixes[i].latitude) * 0.5 * DEG_TO_RAD);
              distAccum += R * Math.sqrt(dLat * dLat + (dLon * cosLat) * (dLon * cosLat));
            }
            if (i === 0 || distAccum >= DROP_LINE_INTERVAL_M) {
              distAccum = 0;
              const fix = fixes[i];
              const dropLine = tb.line({
                geometry: [
                  [fix.longitude, fix.latitude, fix.gnssAltitude * TERRAIN_EXAGGERATION],
                  [fix.longitude, fix.latitude, 0],
                ],
                color: '#888888',
                width: 1,
                opacity: 0.3,
              });
              // Keep depthTest enabled — vertical lines don't z-fight with terrain,
              // and disabling it makes far-side lines bleed through on rotation
              tb.add(dropLine);
              threeDObjects.push(dropLine);
            }
          }
        }

        // Trigger a repaint so the threebox-layer render callback fires
        map.triggerRepaint();
      }

      /**
       * Update the glider marker at the given fix index
       */
      function updateGliderMarker(fixIndex: number): void {
        if (!tb || currentFixes.length === 0) return;

        // Remove old marker
        if (gliderMarker) {
          tb.remove(gliderMarker);
          gliderMarker = null;
        }

        const fix = currentFixes[fixIndex];
        const alt = fix.gnssAltitude * TERRAIN_EXAGGERATION;

        // Create a short vertical spike as the glider marker
        gliderMarker = tb.line({
          geometry: [
            [fix.longitude, fix.latitude, alt],
            [fix.longitude, fix.latitude, alt + 30],
          ],
          color: '#ff3333',
          width: 8,
          opacity: 1.0,
        });
        const mat = (gliderMarker as { material?: { depthTest: boolean } }).material;
        if (mat) mat.depthTest = false;
        tb.add(gliderMarker);
        map.triggerRepaint();
      }

      /**
       * Remove the glider marker from the scene
       */
      function clearGliderMarker(): void {
        if (!tb || !gliderMarker) return;
        tb.remove(gliderMarker);
        gliderMarker = null;
      }

      /**
       * Compute drone camera parameters for the given fix index.
       * Keeps the glider centred without rotating the map.
       */
      function computeDroneCamera(fixIndex: number, includeZoom = false): { center: [number, number]; pitch: number; zoom?: number } {
        const fix = currentFixes[fixIndex];
        const cam: { center: [number, number]; pitch: number; zoom?: number } = {
          center: [fix.longitude, fix.latitude],
          pitch: 75,
        };
        if (includeZoom) cam.zoom = 14.5;
        return cam;
      }

      /**
       * Get track bearing at the given fix index (degrees, clockwise from north)
       */
      function getTrackBearing(fixIndex: number): number {
        const fixes = currentFixes;
        const lookAhead = Math.min(20, fixes.length - 1 - fixIndex);
        if (lookAhead > 0) {
          return calculateBearing(
            fixes[fixIndex].latitude, fixes[fixIndex].longitude,
            fixes[fixIndex + lookAhead].latitude, fixes[fixIndex + lookAhead].longitude,
          );
        }
        if (fixIndex > 0) {
          return calculateBearing(
            fixes[fixIndex - 1].latitude, fixes[fixIndex - 1].longitude,
            fixes[fixIndex].latitude, fixes[fixIndex].longitude,
          );
        }
        return 0;
      }

      /**
       * Apply a camera preset (bearing/pitch) with animation
       */
      function applyCameraPreset(preset: CameraPreset): void {
        activeCameraPreset = preset;
        const trackBearing = getTrackBearing(currentFixIndex);

        let bearing: number;
        let pitch: number;
        switch (preset) {
          case 'side':
            bearing = trackBearing - 90;
            pitch = 75;
            break;
          case 'top':
            bearing = map.getBearing(); // keep current bearing
            pitch = 0;
            break;
          case 'behind':
            bearing = trackBearing;
            pitch = 75;
            break;
          case 'front':
            bearing = trackBearing + 180;
            pitch = 75;
            break;
        }
        map.easeTo({ bearing, pitch, duration: 800 });
      }

      /**
       * Update bearing for presets that track the flight direction.
       * Called during scrubbing so behind/front stay aligned with the track.
       */
      function updatePresetBearing(): void {
        if (activeCameraPreset === 'side' || activeCameraPreset === 'top') return;
        const trackBearing = getTrackBearing(currentFixIndex);
        const bearing = activeCameraPreset === 'behind' ? trackBearing : trackBearing + 180;
        map.easeTo({ bearing, duration: 200 });
      }

      /**
       * Translate the free camera by the delta between the previous and new
       * target positions in mercator space. This preserves user zoom/bearing/pitch
       * without needing a continuous rAF loop.
       */
      function setCameraTarget(fixIndex: number): void {
        if (!is3DMode) return;
        const fix = currentFixes[fixIndex];
        const newLng = fix.longitude;
        const newLat = fix.latitude;
        const newAlt = fix.gnssAltitude * TERRAIN_EXAGGERATION;

        const prevMerc = mapboxgl.MercatorCoordinate.fromLngLat(
          { lng: cameraPrevLng, lat: cameraPrevLat }, cameraPrevAlt
        );
        const newMerc = mapboxgl.MercatorCoordinate.fromLngLat(
          { lng: newLng, lat: newLat }, newAlt
        );

        const dx = newMerc.x - prevMerc.x;
        const dy = newMerc.y - prevMerc.y;
        const dz = newMerc.z - prevMerc.z;
        if (Math.abs(dx) > 1e-12 || Math.abs(dy) > 1e-12 || Math.abs(dz) > 1e-12) {
          const cam = map.getFreeCameraOptions();
          if (cam.position) {
            cam.position = new mapboxgl.MercatorCoordinate(
              cam.position.x + dx,
              cam.position.y + dy,
              cam.position.z + dz,
            );
            map.setFreeCameraOptions(cam);
          }
        }

        cameraPrevLng = newLng;
        cameraPrevLat = newLat;
        cameraPrevAlt = newAlt;
      }

      /**
       * Snapshot the current target so the first setCameraTarget() call
       * produces zero delta.
       */
      function initCameraFollow(): void {
        const fix = currentFixes[currentFixIndex];
        cameraPrevLng = fix.longitude;
        cameraPrevLat = fix.latitude;
        cameraPrevAlt = fix.gnssAltitude * TERRAIN_EXAGGERATION;
      }

      /**
       * Create the altitude scrubber overlay
       */
      function createAltitudeScrubber(fixes: IGCFix[]): HTMLElement {
        // Layout constants for axis padding
        const Y_AXIS_WIDTH = 40; // px, left padding for altitude labels
        const X_AXIS_HEIGHT = 16; // px, bottom padding for time labels

        const wrapper = document.createElement('div');
        wrapper.style.cssText = 'position:absolute;bottom:0;left:0;right:0;height:15%;z-index:10;background:rgba(0,0,0,0.65);cursor:crosshair;touch-action:none;';

        const { minAlt, altRange } = calculateAltitudeRange(fixes);
        const maxAlt = minAlt + altRange;

        // Chart area (inset from axes)
        const chartArea = document.createElement('div');
        chartArea.style.cssText = `position:absolute;top:0;left:${Y_AXIS_WIDTH}px;right:0;bottom:${X_AXIS_HEIGHT}px;`;

        // Create SVG altitude profile
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('width', '100%');
        svg.setAttribute('height', '100%');
        svg.setAttribute('preserveAspectRatio', 'none');
        svg.setAttribute('viewBox', `0 0 ${fixes.length} 100`);
        svg.style.cssText = 'display:block;width:100%;height:100%;';

        // Build filled area polygon
        let pathD = `M 0 100 `;
        for (let i = 0; i < fixes.length; i++) {
          const y = altRange > 0 ? 100 - ((fixes[i].gnssAltitude - minAlt) / altRange) * 95 : 50;
          pathD += `L ${i} ${y} `;
        }
        pathD += `L ${fixes.length - 1} 100 Z`;

        // Create gradient definition
        const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
        const gradient = document.createElementNS('http://www.w3.org/2000/svg', 'linearGradient');
        gradient.setAttribute('id', 'scrubber-grad');
        gradient.setAttribute('x1', '0');
        gradient.setAttribute('y1', '0');
        gradient.setAttribute('x2', '1');
        gradient.setAttribute('y2', '0');

        const numStops = Math.min(50, fixes.length);
        for (let i = 0; i < numStops; i++) {
          const idx = Math.round((i / (numStops - 1)) * (fixes.length - 1));
          const normalizedAlt = altRange > 0 ? (fixes[idx].gnssAltitude - minAlt) / altRange : 0.5;
          const stop = document.createElementNS('http://www.w3.org/2000/svg', 'stop');
          stop.setAttribute('offset', `${(i / (numStops - 1)) * 100}%`);
          stop.setAttribute('stop-color', getAltitudeColorNormalized(normalizedAlt));
          gradient.appendChild(stop);
        }
        defs.appendChild(gradient);
        svg.appendChild(defs);

        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path.setAttribute('d', pathD);
        path.setAttribute('fill', 'url(#scrubber-grad)');
        path.setAttribute('opacity', '0.8');
        svg.appendChild(path);

        // Altitude profile outline
        let outlineD = '';
        for (let i = 0; i < fixes.length; i++) {
          const y = altRange > 0 ? 100 - ((fixes[i].gnssAltitude - minAlt) / altRange) * 95 : 50;
          outlineD += (i === 0 ? 'M ' : 'L ') + `${i} ${y} `;
        }
        const outline = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        outline.setAttribute('d', outlineD);
        outline.setAttribute('fill', 'none');
        outline.setAttribute('stroke', 'rgba(255,255,255,0.5)');
        outline.setAttribute('stroke-width', '0.5');
        outline.setAttribute('vector-effect', 'non-scaling-stroke');
        svg.appendChild(outline);

        chartArea.appendChild(svg);

        // Position indicator line (within chart area)
        const indicator = document.createElement('div');
        indicator.style.cssText = 'position:absolute;top:0;bottom:0;width:2px;background:#ff8c00;pointer-events:none;left:0;';
        chartArea.appendChild(indicator);

        wrapper.appendChild(chartArea);

        // ── Y-axis (altitude) labels ──
        const yAxis = document.createElement('div');
        yAxis.style.cssText = `position:absolute;top:0;left:0;width:${Y_AXIS_WIDTH}px;bottom:${X_AXIS_HEIGHT}px;pointer-events:none;`;

        if (altRange > 0) {
          const niceStep = niceAltitudeStep(altRange, 3);
          const firstTick = Math.ceil(minAlt / niceStep) * niceStep;
          for (let val = firstTick; val <= maxAlt; val += niceStep) {
            const pct = ((val - minAlt) / altRange) * 100;
            const label = document.createElement('div');
            label.style.cssText = `position:absolute;right:2px;bottom:${pct}%;transform:translateY(50%);font-size:9px;line-height:1;color:rgba(255,255,255,0.7);display:flex;align-items:center;gap:1px;white-space:nowrap;`;
            const fv = formatAltitude(val);
            label.innerHTML = `<span>${fv.formatted}</span><span style="width:4px;height:1px;background:rgba(255,255,255,0.4);display:inline-block;flex-shrink:0;"></span>`;
            yAxis.appendChild(label);
          }
        }
        wrapper.appendChild(yAxis);

        // ── X-axis (time) labels ──
        const xAxis = document.createElement('div');
        xAxis.style.cssText = `position:absolute;left:${Y_AXIS_WIDTH}px;right:0;bottom:0;height:${X_AXIS_HEIGHT}px;pointer-events:none;`;

        if (fixes.length >= 2) {
          const startMs = fixes[0].time.getTime();
          const endMs = fixes[fixes.length - 1].time.getTime();
          const durationMs = endMs - startMs;
          if (durationMs > 0) {
            const durationMin = durationMs / 60000;
            const stepMin = niceTimeStep(durationMin, 5);
            const stepMs = stepMin * 60000;

            // Snap first tick to next multiple of stepMin
            const startMinOfDay = fixes[0].time.getHours() * 60 + fixes[0].time.getMinutes();
            const firstTickMin = Math.ceil(startMinOfDay / stepMin) * stepMin;
            const firstTickMs = fixes[0].time.getTime() - startMinOfDay * 60000 + firstTickMin * 60000;

            for (let tickMs = firstTickMs; tickMs <= endMs; tickMs += stepMs) {
              if (tickMs < startMs) continue;
              const pct = ((tickMs - startMs) / durationMs) * 100;
              const label = document.createElement('div');
              label.style.cssText = `position:absolute;left:${pct}%;top:0;transform:translateX(-50%);font-size:9px;line-height:1;color:rgba(255,255,255,0.7);display:flex;flex-direction:column;align-items:center;`;
              const d = new Date(tickMs);
              const h = d.getHours().toString().padStart(2, '0');
              const m = d.getMinutes().toString().padStart(2, '0');
              label.innerHTML = `<span style="width:1px;height:4px;background:rgba(255,255,255,0.4);display:block;"></span><span>${h}:${m}</span>`;
              xAxis.appendChild(label);
            }
          }
        }
        wrapper.appendChild(xAxis);

        // Scrub interaction — uses chartArea for position calculations
        function scrubToX(clientX: number): void {
          const rect = chartArea.getBoundingClientRect();
          const fraction = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
          const fixIndex = Math.round(fraction * (fixes.length - 1));
          currentFixIndex = fixIndex;

          // Update indicator position
          indicator.style.left = `${fraction * 100}%`;

          // Update glider marker and camera target (momentum loop handles animation)
          updateGliderMarker(fixIndex);
          setCameraTarget(fixIndex);
          updatePresetBearing();

          // Update HUD for this fix
          updateScrubberHUD(fixIndex);
        }

        wrapper.addEventListener('pointerdown', (e: PointerEvent) => {
          wrapper.setPointerCapture(e.pointerId);
          scrubToX(e.clientX);
        });
        wrapper.addEventListener('pointermove', (e: PointerEvent) => {
          if (wrapper.hasPointerCapture(e.pointerId)) {
            scrubToX(e.clientX);
          }
        });

        container.appendChild(wrapper);
        return wrapper;
      }

      /**
       * Compute a nice round step for altitude axis
       */
      function niceAltitudeStep(range: number, targetTicks: number): number {
        const rough = range / targetTicks;
        const fv = formatAltitude(rough);
        const unitValue = fv.value;
        const magnitude = Math.pow(10, Math.floor(Math.log10(unitValue)));
        const residual = unitValue / magnitude;
        let nice: number;
        if (residual <= 1.5) nice = 1;
        else if (residual <= 3.5) nice = 2;
        else if (residual <= 7.5) nice = 5;
        else nice = 10;
        const niceUnitValue = nice * magnitude;
        return (niceUnitValue / unitValue) * rough;
      }

      /**
       * Compute a nice time step in minutes
       */
      function niceTimeStep(durationMinutes: number, targetTicks: number): number {
        const rough = durationMinutes / targetTicks;
        const steps = [5, 10, 15, 20, 30, 60, 120, 180, 240];
        for (const s of steps) {
          if (s >= rough) return s;
        }
        return 240;
      }

      /**
       * Show/update the HUD for the current scrubber position
       */
      function updateScrubberHUD(fixIndex: number): void {
        const data = buildTrackPointHUDData(currentFixes, currentEvents, fixIndex, getNextTurnpointContext);
        if (!data) return;
        if (!hudElement) {
          hudElement = createTrackPointHUD(container);
        }
        hudElement.style.bottom = 'calc(15% + 8px)';
        updateTrackPointHUD(hudElement, data);
      }

      /**
       * Remove the altitude scrubber overlay
       */
      function removeAltitudeScrubber(): void {
        if (scrubberElement) {
          scrubberElement.remove();
          scrubberElement = null;
        }
        // Reset HUD position back to default
        if (hudElement) {
          hudElement.style.bottom = '32px';
        }
      }

      // ── Multi-track helpers ──

      /** Get a color for a ranked pilot: bright orange for #1, grey for last */
      function getRankColor(rank: number, totalPilots: number): string {
        if (totalPilots <= 1) return '#ff8c00';
        const t = (rank - 1) / (totalPilots - 1); // 0 = leader, 1 = last
        // Interpolate from orange (#ff8c00) to grey (#888888)
        const r = Math.round(255 * (1 - t) + 136 * t);
        const g = Math.round(140 * (1 - t) + 136 * t);
        const b = Math.round(0 * (1 - t) + 136 * t);
        return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
      }

      /** Remove the scrubber's position markers. Runs on every scrub. */
      function clearMultiTrackMarkers(): void {
        if (tb) {
          for (const obj of multiTrackMarkerObjects) {
            tb.remove(obj);
          }
        }
        multiTrackMarkerObjects = [];
      }

      function clearMulti3DTracks(): void {
        if (tb) {
          for (const obj of multiTrack3DObjects) {
            tb.remove(obj);
          }
        }
        multiTrack3DObjects = [];
        // The markers are the scrubber's, and the scrubber belongs to the view
        // being torn down — so they go too. Without this they would outlive
        // every track they were pointing at.
        clearMultiTrackMarkers();
      }

      function renderMulti3DTracks(tracks: LoadedTrack[], pilotScores: PilotScore[]): void {
        if (!tb) return;
        clearMulti3DTracks();

        // Render each track as a SINGLE polyline. Threebox's line() builds one
        // THREE.Line2 (with its own instanced geometry + shader material) per
        // call regardless of point count, so creating one line PER SEGMENT
        // explodes into hundreds of thousands of objects for a full competition
        // (33 tracks × ~10k fixes ≈ 287k objects) — that exhausts memory and
        // freezes the browser. The rank colour is constant across each track, so
        // a single multi-point line is visually identical and ~4 orders of
        // magnitude cheaper (one object per track instead of one per fix).
        for (let ti = 0; ti < tracks.length; ti++) {
          const track = tracks[ti];
          if (track.fixes.length < 2) continue;
          // Color by position in the visible set, not original rank
          const color = getRankColor(ti + 1, tracks.length);

          const geometry: [number, number, number][] = track.fixes.map(
            (fix) => [fix.longitude, fix.latitude, fix.gnssAltitude * TERRAIN_EXAGGERATION],
          );

          const trackLine = tb.line({ geometry, color, width: 3, opacity: 0.85 });
          const lsMat = (trackLine as { material?: { depthTest: boolean } }).material;
          if (lsMat) lsMat.depthTest = false;
          tb.add(trackLine);
          multiTrack3DObjects.push(trackLine);
        }
        map.triggerRepaint();
      }

      /** Create a multi-track scrubber that aligns tracks by SSS crossing time */
      function createMultiTrackScrubber(tracks: LoadedTrack[], pilotScores: PilotScore[]): void {
        removeAltitudeScrubber();

        const Y_AXIS_WIDTH = 40;
        const X_AXIS_HEIGHT = 16;

        const wrapper = document.createElement('div');
        wrapper.style.cssText = 'position:absolute;bottom:0;left:0;right:0;height:15%;z-index:10;background:rgba(0,0,0,0.65);cursor:crosshair;touch-action:none;';

        const chartArea = document.createElement('div');
        chartArea.style.cssText = `position:absolute;top:0;left:${Y_AXIS_WIDTH}px;right:0;bottom:${X_AXIS_HEIGHT}px;`;

        // Find SSS crossing times for alignment (fallback to first fix)
        const trackAlignments = tracks.map((track, ti) => {
          const score = pilotScores.find(ps => ps.pilotName === track.pilotName);
          // Try to find SSS reaching from the turnpoint result
          let sssTime: number | null = null;
          if (score?.turnpointResult?.sssReaching) {
            sssTime = score.turnpointResult.sssReaching.time.getTime();
          }
          const startTime = sssTime ?? track.fixes[0]?.time.getTime() ?? 0;
          const endTime = track.fixes[track.fixes.length - 1]?.time.getTime() ?? 0;
          return { track, startTime, endTime, duration: endTime - startTime, trackIndex: ti };
        });

        // Max duration for x-axis
        const maxDuration = Math.max(...trackAlignments.map(a => a.duration), 1);

        // Create SVG with all track profiles
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('width', '100%');
        svg.setAttribute('height', '100%');
        svg.setAttribute('preserveAspectRatio', 'none');
        svg.setAttribute('viewBox', `0 0 1000 100`);
        svg.style.cssText = 'display:block;width:100%;height:100%;';

        // Find global alt range
        let globalMinAlt = Infinity, globalMaxAlt = -Infinity;
        for (const track of tracks) {
          for (const fix of track.fixes) {
            if (fix.gnssAltitude < globalMinAlt) globalMinAlt = fix.gnssAltitude;
            if (fix.gnssAltitude > globalMaxAlt) globalMaxAlt = fix.gnssAltitude;
          }
        }
        const altRange = globalMaxAlt - globalMinAlt || 1;

        // Draw each track as a squiggly line
        for (let ti = 0; ti < trackAlignments.length; ti++) {
          const alignment = trackAlignments[ti];
          const { track } = alignment;
          // Color by position in the visible set, not original rank
          const color = getRankColor(ti + 1, tracks.length);

          let pathD = '';
          for (let i = 0; i < track.fixes.length; i++) {
            const fix = track.fixes[i];
            const elapsed = fix.time.getTime() - alignment.startTime;
            const x = (elapsed / maxDuration) * 1000;
            const y = 100 - ((fix.gnssAltitude - globalMinAlt) / altRange) * 90;
            pathD += (i === 0 ? 'M ' : 'L ') + `${x.toFixed(1)} ${y.toFixed(1)} `;
          }

          const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
          path.setAttribute('d', pathD);
          path.setAttribute('fill', 'none');
          path.setAttribute('stroke', color);
          path.setAttribute('stroke-width', '1.5');
          path.setAttribute('vector-effect', 'non-scaling-stroke');
          path.setAttribute('opacity', '0.85');
          svg.appendChild(path);
        }

        chartArea.appendChild(svg);

        // Position indicator
        const indicator = document.createElement('div');
        indicator.style.cssText = 'position:absolute;top:0;bottom:0;width:2px;background:#ff8c00;pointer-events:none;left:0;';
        chartArea.appendChild(indicator);

        wrapper.appendChild(chartArea);

        // Top-3 pilot labels container (positioned above scrubber)
        const labelsContainer = document.createElement('div');
        labelsContainer.id = 'multi-scrubber-labels';
        labelsContainer.style.cssText = 'position:absolute;top:-80px;left:0;right:0;height:80px;pointer-events:none;z-index:11;';
        wrapper.appendChild(labelsContainer);

        // Scrub interaction
        let scrubbing = false;

        function scrubToX(clientX: number): void {
          const rect = chartArea.getBoundingClientRect();
          const fraction = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
          indicator.style.left = `${fraction * 100}%`;

          // Update top-3 markers on the map
          updateMultiTrackMarkers(fraction, trackAlignments, pilotScores, labelsContainer);
        }

        chartArea.addEventListener('pointerdown', (e) => {
          scrubbing = true;
          chartArea.setPointerCapture(e.pointerId);
          scrubToX(e.clientX);
        });
        chartArea.addEventListener('pointermove', (e) => {
          if (scrubbing) scrubToX(e.clientX);
        });
        chartArea.addEventListener('pointerup', () => { scrubbing = false; });

        container.appendChild(wrapper);
        scrubberElement = wrapper;

        // Shift HUD up to avoid overlap
        if (hudElement) {
          hudElement.style.bottom = 'calc(15% + 40px)';
        }
      }

      /** Update the top-3 ranked pilot 3D markers at the current scrub position */
      function updateMultiTrackMarkers(
        fraction: number,
        trackAlignments: Array<{ track: LoadedTrack; startTime: number; duration: number; trackIndex: number }>,
        pilotScores: PilotScore[],
        labelsContainer: HTMLElement,
      ): void {
        // Clear what the last scrub position drew — the screen-space labels and,
        // in 3D, the position markers. Both are rebuilt below for the new
        // position; neither may be left behind, or a drag leaves a trail.
        labelsContainer.innerHTML = '';
        clearMultiTrackMarkers();

        // Get top 3 ranked pilots
        const top3 = pilotScores.slice(0, 3);
        const maxDuration = Math.max(...trackAlignments.map(a => a.duration), 1);
        const currentElapsed = fraction * maxDuration;

        for (let mi = 0; mi < top3.length; mi++) {
          const ps = top3[mi];
          const alignment = trackAlignments.find(a => a.track.pilotName === ps.pilotName);
          if (!alignment) continue;

          const targetTime = alignment.startTime + currentElapsed;
          // Find the closest fix
          let bestIdx = 0;
          let bestDiff = Infinity;
          for (let i = 0; i < alignment.track.fixes.length; i++) {
            const diff = Math.abs(alignment.track.fixes[i].time.getTime() - targetTime);
            if (diff < bestDiff) {
              bestDiff = diff;
              bestIdx = i;
            }
          }

          const fix = alignment.track.fixes[bestIdx];
          if (!fix) continue;

          // Project to screen coordinates and show label
          const point = map.project([fix.longitude, fix.latitude]);
          const label = document.createElement('div');
          label.style.cssText = `position:absolute;left:${point.x}px;top:0;transform:translateX(-50%);text-align:center;font-size:11px;color:#fff;text-shadow:0 1px 3px rgba(0,0,0,0.8);white-space:nowrap;`;
          label.textContent = `${ps.rank}. ${ps.pilotName}`;
          labelsContainer.appendChild(label);

          // If in 3D mode, also add a marker
          if (tb) {
            const color = getRankColor(mi + 1, top3.length);
            const marker = tb.line({
              geometry: [
                [fix.longitude, fix.latitude, fix.gnssAltitude * TERRAIN_EXAGGERATION],
                [fix.longitude, fix.latitude, fix.gnssAltitude * TERRAIN_EXAGGERATION + 50],
              ],
              color,
              width: 8,
              opacity: 1,
            });
            tb.add(marker);
            multiTrackMarkerObjects.push(marker);
          }
        }
      }

      function createCompass(): void {
        if (compassElement) return;
        const wrapper = document.createElement('div');
        Object.assign(wrapper.style, {
          position: 'absolute',
          bottom: 'calc(15% + 8px)',
          right: '8px',
          width: '160px',
          height: '160px',
          pointerEvents: 'auto',
          perspective: '300px',
          zIndex: '10',
          cursor: 'grab',
          touchAction: 'none',
        });
        const img = document.createElement('img');
        img.src = '/compass.svg';
        img.draggable = false;
        Object.assign(img.style, {
          width: '100%',
          height: '100%',
          transformOrigin: 'center center',
        });
        wrapper.appendChild(img);
        map.getContainer().appendChild(wrapper);
        compassElement = wrapper;
        updateCompassTransform();

        // Drag support
        let dragging = false;
        let offsetX = 0;
        let offsetY = 0;

        function onPointerDown(e: PointerEvent) {
          dragging = true;
          offsetX = e.clientX - wrapper.getBoundingClientRect().left;
          offsetY = e.clientY - wrapper.getBoundingClientRect().top;
          wrapper.setPointerCapture(e.pointerId);
          wrapper.style.cursor = 'grabbing';
          // Clear anchored positioning so left/top take effect
          wrapper.style.right = '';
          wrapper.style.bottom = '';
          const rect = wrapper.getBoundingClientRect();
          const containerRect = map.getContainer().getBoundingClientRect();
          wrapper.style.left = `${rect.left - containerRect.left}px`;
          wrapper.style.top = `${rect.top - containerRect.top}px`;
          e.preventDefault();
          e.stopPropagation();
        }

        function onPointerMove(e: PointerEvent) {
          if (!dragging) return;
          const containerRect = map.getContainer().getBoundingClientRect();
          let newLeft = e.clientX - containerRect.left - offsetX;
          let newTop = e.clientY - containerRect.top - offsetY;
          // Clamp within container
          newLeft = Math.max(0, Math.min(newLeft, containerRect.width - wrapper.offsetWidth));
          newTop = Math.max(0, Math.min(newTop, containerRect.height - wrapper.offsetHeight));
          wrapper.style.left = `${newLeft}px`;
          wrapper.style.top = `${newTop}px`;
          e.preventDefault();
          e.stopPropagation();
        }

        function onPointerUp(e: PointerEvent) {
          if (!dragging) return;
          dragging = false;
          wrapper.releasePointerCapture(e.pointerId);
          wrapper.style.cursor = 'grab';
          e.stopPropagation();
        }

        wrapper.addEventListener('pointerdown', onPointerDown);
        wrapper.addEventListener('pointermove', onPointerMove);
        wrapper.addEventListener('pointerup', onPointerUp);
      }

      function updateCompassTransform(): void {
        if (!compassElement) return;
        const img = compassElement.querySelector('img') as HTMLImageElement;
        if (!img) return;
        const bearing = map.getBearing();
        const pitch = map.getPitch();
        img.style.transform = `rotateX(${pitch * 0.8}deg) rotateZ(${-bearing}deg)`;
      }

      function removeCompass(): void {
        if (compassElement) {
          compassElement.remove();
          compassElement = null;
        }
      }

      // Altitude color functions and gradient calculation are imported from map-provider-shared


      /**
       * Update track rendering based on current mode
       */
      function updateTrackRendering(): void {
        if (is3DMode) {
          // Hide all 2D track layers
          if (map.getLayer('track-line')) {
            map.setLayoutProperty('track-line', 'visibility', 'none');
          }
          if (map.getLayer('track-line-outline')) {
            map.setLayoutProperty('track-line-outline', 'visibility', 'none');
          }
          // Show 3D track
          render3DTrack(currentFixes);
        } else {
          // Show 2D track layers
          if (map.getLayer('track-line')) {
            map.setLayoutProperty('track-line', 'visibility', 'visible');
          }
          if (map.getLayer('track-line-outline')) {
            map.setLayoutProperty('track-line-outline', 'visibility', 'visible');
          }
          // Hide 3D track
          clear3DTrack();
        }
      }

      const renderer: MapProvider = {
        supports3D: true,
        supportsSpeedOverlay: true,

        setSpeedOverlay(enabled: boolean) {
          isSpeedOverlayActive = enabled;
          if (enabled) {
            clearEventHighlights();
            renderSpeedOverlay();
            showGlideLegend(true);
          } else {
            clearSpeedOverlay();
            showGlideLegend(false);
          }
        },

        set3DMode(enabled: boolean) {
          is3DMode = enabled;
          clearEventHighlights();
          updateTrackRendering();

          if (enabled && currentFixes.length > 0) {
            // Create scrubber and set up drone follow camera
            scrubberElement = createAltitudeScrubber(currentFixes);
            currentFixIndex = 0;
            activeCameraPreset = 'side';
            updateGliderMarker(0);
            updateScrubberHUD(0);

            // Show camera preset control and compass
            cameraPresetControl?.create();
            cameraPresetControl?.updateActive('side');
            createCompass();

            // Fly camera to initial drone position, then start momentum loop
            const cam = computeDroneCamera(0, true);
            map.flyTo({ ...cam, duration: 2000 });
            map.once('moveend', () => {
              if (is3DMode) initCameraFollow();
            });
          } else {
            // Clean up drone follow state
            removeAltitudeScrubber();
            clearGliderMarker();
            cameraPresetControl?.remove();
          }
        },

        setTaskVisibility(visible: boolean) {
          isTaskVisible = visible;
          const visibility = visible ? 'visible' : 'none';
          const taskLayers = [
            'task-line',
            'task-line-arrows',
            'task-cylinders-fill',
            'task-cylinders-stroke',
            'task-exit-arrows',
            'task-goal-line',
            'task-points',
            'task-labels',
            'task-segment-labels',
          ];
          for (const layerId of taskLayers) {
            if (map.getLayer(layerId)) {
              map.setLayoutProperty(layerId, 'visibility', visibility);
            }
          }
        },

        setTrackVisibility(visible: boolean) {
          isTrackVisible = visible;

          if (visible) {
            // Restore track based on current mode
            updateTrackRendering();
          } else {
            // Hide all track layers
            const trackLayers = [
              'track-line',
              'track-line-outline',
              'highlight-segment',
            ];
            for (const layerId of trackLayers) {
              if (map.getLayer(layerId)) {
                map.setLayoutProperty(layerId, 'visibility', 'none');
              }
            }
            // Clear 3D track objects
            clear3DTrack();
          }

          // Toggle event markers visibility
          for (const marker of eventMarkers) {
            const el = marker.getElement();
            if (el) {
              el.style.display = visible ? '' : 'none';
            }
          }

          // The scrub position dot belongs to the track — hide it with it
          if (trackScrubMarker) {
            trackScrubMarker.getElement().style.display = visible ? '' : 'none';
          }

          // Clear any active highlights when hiding
          if (!visible) {
            clearEventHighlights();
          }
        },
        setTrack(fixes: IGCFix[]) {
          clearEventHighlights();
          clearTrackScrub();
          currentFixes = fixes;
          cachedSequenceResult = null;
          cachedOptimizedPath = null;

          if (fixes.length === 0) {
            updateGeoJSONSource(map, 'track', []);
            return;
          }

          // Calculate altitude range for normalization
          const { minAlt, altRange } = calculateAltitudeRange(fixes);

          updateGeoJSONSource(map, 'track', buildTrackFeatures(fixes, altRange, minAlt));

          // Fit map to track bounds. Re-measure first: if the map initialized
          // during iOS layout churn its cached size can be stale, which would
          // misplace the camera until a manual refresh.
          map.resize();
          const bounds = getBoundingBox(fixes);
          const padding = 50;

          map.fitBounds(
            [
              [bounds.minLon, bounds.minLat],
              [bounds.maxLon, bounds.maxLat],
            ],
            { padding, duration: 1000 }
          );

          // Update rendering based on current mode
          if (is3DMode) {
            render3DTrack(fixes);
            cameraPresetControl?.create();
            cameraPresetControl?.updateActive(activeCameraPreset);
            // Recreate drone follow scrubber/marker for the new track
            removeAltitudeScrubber();
            clearGliderMarker();
            scrubberElement = createAltitudeScrubber(fixes);
            currentFixIndex = 0;
            updateGliderMarker(0);
            const cam = computeDroneCamera(0, true);
            map.flyTo({ ...cam, duration: 2000 });
            map.once('moveend', () => {
              if (is3DMode) initCameraFollow();
            });
          }
        },

        clearTrack() {
          clearEventHighlights();
          clearSpeedOverlay();
          clearTrackScrub();
          currentFixes = [];
          cachedSequenceResult = null;
          cachedOptimizedPath = null;
          updateGeoJSONSource(map, 'track', []);
          // Clear 3D track and drone follow state if present
          clear3DTrack();
          cameraPresetControl?.remove();
          removeAltitudeScrubber();
          removeCompass();
          clearGliderMarker();
        },

        setTrackScrub(index: number | null) {
          if (currentFixes.length < 2) return;
          if (index == null) {
            const wasScrubbed = trackScrubIndex != null;
            clearTrackScrub();
            if (wasScrubbed) renderTrackScrubClip(null);
            return;
          }
          trackScrubIndex = Math.max(0, Math.min(currentFixes.length - 1, Math.floor(index)));
          // The marker move is cheap — do it immediately for drag feedback;
          // the geometry rebuild is batched to one per animation frame.
          updateTrackScrubMarker(trackScrubIndex);
          if (trackScrubRaf == null) {
            trackScrubRaf = requestAnimationFrame(() => {
              trackScrubRaf = null;
              renderTrackScrubClip(trackScrubIndex);
            });
          }
        },

        async setTask(task: XCTask, options?: { fit?: boolean }) {
          currentTask = task;
          cachedSequenceResult = null;
          cachedOptimizedPath = null;

          if (!task || task.turnpoints.length === 0) {
            updateGeoJSONSource(map, 'task-line', []);
            updateGeoJSONSource(map, 'task-points', []);
            updateGeoJSONSource(map, 'task-cylinders', []);
            updateGeoJSONSource(map, 'task-exit-arrows', []);
            updateGeoJSONSource(map, 'task-goal-line', []);
            updateGeoJSONSource(map, 'task-segment-labels', []);
            return;
          }

          // Create optimized task line that tags cylinder edges
          const optimizedPath = calculateOptimizedTaskLine(task);
          const lineCoords = optimizedPath.map(p => [p.lon, p.lat]);

          updateGeoJSONSource(map, 'task-line', [{
            type: 'Feature',
            properties: {},
            geometry: {
              type: 'LineString',
              coordinates: lineCoords,
            },
          }]);

          // Create segment distance labels
          const segmentDistances = getOptimizedSegmentDistances(task);
          const segmentLabels = computeSegmentLabels(optimizedPath, segmentDistances);
          const segmentLabelFeatures = segmentLabels.map(label => ({
            type: 'Feature' as const,
            properties: {
              distance: label.text,
              bearing: label.bearing,
            },
            geometry: {
              type: 'Point' as const,
              coordinates: [label.midLon, label.midLat],
            },
          }));

          updateGeoJSONSource(map, 'task-segment-labels', segmentLabelFeatures);

          // Create turnpoint markers
          const pointFeatures = task.turnpoints.map((tp, idx) => ({
            type: 'Feature' as const,
            properties: {
              name: formatTurnpointLabel(tp, idx),
              type: tp.type || '',
              radius: tp.radius,
            },
            geometry: {
              type: 'Point' as const,
              coordinates: [tp.waypoint.lon, tp.waypoint.lat],
            },
          }));

          updateGeoJSONSource(map, 'task-points', pointFeatures);

          // Create cylinder polygons. A LINE goal replaces the last
          // turnpoint's circle with its control semicircle (the half-disc
          // behind the line) and draws the line itself on task-goal-line.
          const goalLine = computeGoalLine(task);
          const cylinderFeatures = task.turnpoints.map((tp, idx) => ({
            type: 'Feature' as const,
            properties: {
              name: tp.waypoint.name || `TP${idx + 1}`,
              type: tp.type || '',
              radius: tp.radius,
            },
            geometry:
              goalLine && idx === task.turnpoints.length - 1
                ? {
                    type: 'Polygon' as const,
                    coordinates: [
                      goalSemicirclePoints(goalLine).map((p) => [p.lon, p.lat]),
                    ],
                  }
                : createCirclePolygon(
                    tp.waypoint.lon,
                    tp.waypoint.lat,
                    tp.radius
                  ),
          }));

          updateGeoJSONSource(map, 'task-cylinders', cylinderFeatures);

          // Outward arrowheads marking exit turnpoints (crossed flying out).
          updateGeoJSONSource(
            map,
            'task-exit-arrows',
            exitTurnpointArrowFeatures(task, optimizedPath) as GeoJSON.Feature<GeoJSON.Geometry>[]
          );

          updateGeoJSONSource(
            map,
            'task-goal-line',
            goalLine
              ? [{
                  type: 'Feature' as const,
                  properties: {},
                  geometry: {
                    type: 'LineString' as const,
                    coordinates: [
                      [goalLine.end1.lon, goalLine.end1.lat],
                      [goalLine.end2.lon, goalLine.end2.lat],
                    ],
                  },
                }]
              : []
          );

          // If no track is loaded, fit to task bounds (re-measure first — see
          // setTrack). Callers editing the task live pass fit:false so picks
          // and coordinate edits don't re-zoom the map out from under them.
          if ((options?.fit ?? true) && currentFixes.length === 0) {
            map.resize();
            const bounds = new mapboxgl.LngLatBounds();
            for (const tp of task.turnpoints) {
              bounds.extend([tp.waypoint.lon, tp.waypoint.lat]);
            }
            map.fitBounds(bounds, { padding: 50, duration: 1000 });
          }
        },

        clearTask() {
          currentTask = null;
          cachedSequenceResult = null;
          cachedOptimizedPath = null;
          updateGeoJSONSource(map, 'task-line', []);
          updateGeoJSONSource(map, 'task-points', []);
          updateGeoJSONSource(map, 'task-cylinders', []);
          updateGeoJSONSource(map, 'task-exit-arrows', []);
          updateGeoJSONSource(map, 'task-goal-line', []);
          updateGeoJSONSource(map, 'task-segment-labels', []);
        },

        setEvents(events: FlightEvent[]) {
          currentEvents = events;

          // Remove old markers
          for (const marker of eventMarkers) {
            marker.remove();
          }
          eventMarkers.length = 0;

          // Add new markers (only for key events to avoid clutter)
          for (const event of events) {
            if (!KEY_EVENT_TYPES.has(event.type)) continue;

            const style = getEventStyle(event.type);

            const el = document.createElement('div');
            el.className = 'event-marker';
            el.style.width = '20px';
            el.style.height = '20px';
            el.style.borderRadius = '50%';
            el.style.backgroundColor = style.color;
            el.style.border = '2px solid white';
            el.style.boxShadow = '0 2px 4px rgba(0,0,0,0.3)';
            el.style.cursor = 'pointer';

            const marker = new mapboxgl.Marker({ element: el })
              .setLngLat([event.longitude, event.latitude])
              .setPopup(
                new mapboxgl.Popup({ offset: 25 }).setHTML(`
                  <strong>${event.description}</strong><br>
                  ${event.time.toLocaleTimeString()}
                `)
              )
              .addTo(map);

            eventMarkers.push(marker);
          }

          // Re-render speed overlay if it was active
          if (isSpeedOverlayActive) {
            renderSpeedOverlay();
          }
        },

        clearEvents() {
          currentEvents = [];
          for (const marker of eventMarkers) {
            marker.remove();
          }
          eventMarkers.length = 0;
          clearEventHighlights();
          clearSpeedOverlay();
        },

        panToEvent(event: FlightEvent, options?: { skipPan?: boolean }) {
          // Close any existing popup, markers, and HUD
          if (activePopup) {
            activePopup.remove();
            activePopup = null;
          }
          for (const marker of activeMarkers) {
            marker.remove();
          }
          activeMarkers = [];
          clearHudCrosshair();
          sharedHideTrackPointHUD(hudElement);

          // Show/hide glide legend based on event type (keep visible if speed overlay is active)
          const isGlideEvent = event.type === 'glide_start' || event.type === 'glide_end';
          showGlideLegend(isGlideEvent || isSpeedOverlayActive);

          // Highlight segment if event has one
          if (event.segment && currentFixes.length > 0) {
            const { startIndex, endIndex } = event.segment;
            const segmentFixes = currentFixes.slice(startIndex, endIndex + 1);

            if (segmentFixes.length > 1) {
              const coordinates = segmentFixes.map(fix => [fix.longitude, fix.latitude, fix.gnssAltitude]);

              updateGeoJSONSource(map, 'highlight-segment', [{
                type: 'Feature',
                properties: {},
                geometry: {
                  type: 'LineString',
                  coordinates,
                },
              }]);

              // For glide events, add direction chevrons every ~1km with speed labels
              if (event.type === 'glide_start' || event.type === 'glide_end') {
                const glideMarkers = calculateGlideMarkers(segmentFixes, getNextTurnpointContext, getSegmentLengthMeters(config.getUnits().distance));

                let highlightLabelIndex = 0;

                for (const marker of glideMarkers) {
                  // Chevron centered on the track point
                  const chevronEl = document.createElement('div');
                  chevronEl.style.cssText = 'display:flex;align-items:center;justify-content:center;';
                  chevronEl.innerHTML = `<svg width="28" height="16" viewBox="0 0 20 12" style="transform:rotate(${marker.bearing}deg);">
                    <path d="M2 10 L10 2 L18 10" fill="none" stroke="#3b82f6" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>`;
                  const chevronMarker = new mapboxgl.Marker({
                    element: chevronEl,
                    rotationAlignment: 'map',
                    pitchAlignment: 'map',
                  })
                    .setLngLat([marker.lon, marker.lat])
                    .addTo(map);
                  activeMarkers.push(chevronMarker);

                  // Label
                  const { speed, detailText, reqText } = formatGlideLabel(marker);
                  const labelEl = document.createElement('div');
                  labelEl.style.cssText = `
                    font-family: ${MAP_FONT_FAMILY};
                    font-size: 20px;
                    font-weight: 600;
                    color: #333;
                    white-space: nowrap;
                    text-shadow: ${GLIDE_LABEL_TEXT_SHADOW};
                    text-align: center;
                    line-height: 1.3;
                  `;
                  labelEl.innerHTML = reqText
                    ? `${speed}<br>${detailText}<br>${reqText}`
                    : `${speed}<br>${detailText}`;
                  labelEl.dataset.glideLabel = 'true';
                  labelEl.dataset.speedLabel = speed;
                  labelEl.dataset.detailLabel = detailText;
                  labelEl.dataset.reqLabel = reqText;
                  labelEl.dataset.labelIndex = String(highlightLabelIndex);
                  highlightLabelIndex++;

                  const labelMarker = new mapboxgl.Marker({ element: labelEl, anchor: 'top', offset: [0, 12] })
                    .setLngLat([marker.lon, marker.lat])
                    .addTo(map);
                  activeMarkers.push(labelMarker);
                }

                updateGlideLabelVisibility();
              }
            }
          } else {
            updateGeoJSONSource(map, 'highlight-segment', []);
          }

          const style = getEventStyle(event.type);

          // Inject throbbing animation keyframes if not already present
          if (!document.getElementById('throb-animation-style')) {
            const styleSheet = document.createElement('style');
            styleSheet.id = 'throb-animation-style';
            styleSheet.textContent = `
              @keyframes throb {
                0%, 100% { box-shadow: 0 0 0 0 currentColor; }
                50% { box-shadow: 0 0 0 20px transparent; }
              }
              .throb-marker {
                animation: throb 0.5s ease-in-out 4;
              }
            `;
            document.head.appendChild(styleSheet);
          }

          // Determine which marker should throb based on event type
          const isStartEvent = event.type === 'thermal_entry' || event.type === 'glide_start';

          // Create markers at segment endpoints or event point
          if (event.segment && currentFixes.length > 0) {
            const startFix = currentFixes[event.segment.startIndex];
            const endFix = currentFixes[event.segment.endIndex];

            // Start marker (ring/outline style)
            const startEl = document.createElement('div');
            startEl.style.width = '14px';
            startEl.style.height = '14px';
            startEl.style.borderRadius = '50%';
            startEl.style.backgroundColor = 'transparent';
            startEl.style.border = `3px solid ${style.color}`;
            startEl.style.boxShadow = '0 2px 6px rgba(0,0,0,0.4)';
            if (isStartEvent) {
              startEl.classList.add('throb-marker');
            }

            const startMarker = new mapboxgl.Marker({ element: startEl })
              .setLngLat([startFix.longitude, startFix.latitude])
              .addTo(map);
            activeMarkers.push(startMarker);

            // End marker (filled style)
            const endEl = document.createElement('div');
            endEl.style.width = '14px';
            endEl.style.height = '14px';
            endEl.style.borderRadius = '50%';
            endEl.style.backgroundColor = style.color;
            endEl.style.border = '3px solid white';
            endEl.style.boxShadow = '0 2px 6px rgba(0,0,0,0.4)';
            if (!isStartEvent) {
              endEl.classList.add('throb-marker');
            }

            const endMarker = new mapboxgl.Marker({ element: endEl })
              .setLngLat([endFix.longitude, endFix.latitude])
              .addTo(map);
            activeMarkers.push(endMarker);
          } else {
            // For point events, show single marker with throb
            const markerEl = document.createElement('div');
            markerEl.style.width = '16px';
            markerEl.style.height = '16px';
            markerEl.style.borderRadius = '50%';
            markerEl.style.backgroundColor = style.color;
            markerEl.style.border = '3px solid white';
            markerEl.style.boxShadow = '0 2px 6px rgba(0,0,0,0.4)';
            markerEl.classList.add('throb-marker');

            const marker = new mapboxgl.Marker({ element: markerEl })
              .setLngLat([event.longitude, event.latitude])
              .addTo(map);
            activeMarkers.push(marker);
          }

          // Pan to the event location (preserve current zoom level) unless skipPan is true
          if (!options?.skipPan) {
            map.flyTo({
              center: [event.longitude, event.latitude],
              zoom: map.getZoom(),
              duration: 1000,
            });
          }
        },

        getBounds() {
          const bounds = map.getBounds();
          if (!bounds) {
            return { north: 90, south: -90, east: 180, west: -180 };
          }
          return {
            north: bounds.getNorth(),
            south: bounds.getSouth(),
            east: bounds.getEast(),
            west: bounds.getWest(),
          };
        },

        onBoundsChange(callback: () => void) {
          boundsChangeCallback = callback;
        },

        destroy() {
          annotationLayer?.destroy();
          for (const marker of eventMarkers) {
            marker.remove();
          }
          map.remove();
        },

        invalidateSize() {
          map.resize();
        },

        onTrackClick(callback: (fixIndex: number) => void) {
          trackClickCallback = callback;
        },

        onTurnpointClick(callback: (turnpointIndex: number) => void) {
          turnpointClickCallback = callback;
        },

        panToTurnpoint(turnpointIndex: number) {
          if (!currentTask || turnpointIndex < 0 || turnpointIndex >= currentTask.turnpoints.length) {
            return;
          }

          const tp = currentTask.turnpoints[turnpointIndex];
          map.flyTo({
            center: [tp.waypoint.lon, tp.waypoint.lat],
            zoom: map.getZoom(), // Keep current zoom level
            duration: 1000,
          });
        },

        panTo(lat: number, lon: number, minZoom = 13) {
          map.flyTo({
            center: [lon, lat],
            zoom: Math.max(map.getZoom(), minZoom),
            duration: 1000,
          });
        },

        showTrackPointHUD(fixIndex: number) {
          const data = buildTrackPointHUDData(currentFixes, currentEvents, fixIndex, getNextTurnpointContext);
          if (!data) return;

          // Clear previous crosshair only (not segment markers)
          clearHudCrosshair();

          // Hide glide legend (same position as HUD)
          showGlideLegend(false);

          // Add crosshair marker on the map
          const crosshairEl = document.createElement('div');
          crosshairEl.innerHTML = CROSSHAIR_MAP_SVG;
          crosshairEl.style.pointerEvents = 'none';
          hudCrosshairMarker = new mapboxgl.Marker({ element: crosshairEl })
            .setLngLat([data.fix.longitude, data.fix.latitude])
            .addTo(map);

          // Show HUD
          if (!hudElement) {
            hudElement = createTrackPointHUD(container);
          }
          updateTrackPointHUD(hudElement, data);
        },

        hideTrackPointHUD() {
          sharedHideTrackPointHUD(hudElement);
        },

        onMenuButtonClick(callback: () => void) {
          menuButtonCallback = callback;
        },

        onPanelToggleClick(callback: () => void) {
          panelToggleCallback = callback;
        },

        highlightPanelToggle() {
          // Animate the ctrl-group container so the whole button shape throbs
          const target = panelToggleBtn?.parentElement ?? panelToggleBtn;
          if (target) {
            target.classList.remove('pulse-attention');
            void target.offsetWidth;
            target.classList.add('pulse-attention');
            target.addEventListener('animationend', () => {
              target.classList.remove('pulse-attention');
            }, { once: true });
          }
        },

        highlightMenuButton() {
          if (menuButtonContainer) {
            menuButtonContainer.classList.remove('pulse-attention');
            void menuButtonContainer.offsetWidth;
            menuButtonContainer.classList.add('pulse-attention');
            menuButtonContainer.addEventListener('animationend', () => {
              menuButtonContainer?.classList.remove('pulse-attention');
            }, { once: true });
          }
        },

        onMapClick(callback: (lat: number, lon: number, details?: MapPickDetails) => void) {
          mapClickCallback = callback;
        },

        setInteractionMode(mode: MapInteractionMode) {
          interactionMode = mode;
          isHoveringInteractive = false;
          syncCursor();
        },

        setWaypoints(waypoints: MapWaypoint[]) {
          waypointsData = waypoints;
          updateGeoJSONSource(
            map,
            'waypoints',
            waypoints.map((w) => ({
              type: 'Feature' as const,
              geometry: { type: 'Point' as const, coordinates: [w.lon, w.lat] },
              properties: { id: w.id, code: w.code, name: w.name },
            })),
          );
        },

        clearWaypoints() {
          waypointsData = [];
          updateGeoJSONSource(map, 'waypoints', []);
        },

        fitToWaypoints() {
          if (waypointsData.length === 0) return;
          map.resize();
          const bounds = new mapboxgl.LngLatBounds();
          for (const w of waypointsData) bounds.extend([w.lon, w.lat]);
          map.fitBounds(bounds, { padding: 40, duration: 800, maxZoom: 12 });
        },

        fitToBounds(bounds: MapBounds, options: { maxZoom?: number } = {}) {
          map.fitBounds(
            [
              [bounds.west, bounds.south],
              [bounds.east, bounds.north],
            ],
            { padding: 40, duration: 1000, maxZoom: options.maxZoom ?? 12 },
          );
        },

        onWaypointClick(callback: (waypoint: MapWaypoint) => void) {
          waypointsClickCallback = callback;
        },

        getAnnotationLayer() {
          return annotationLayer;
        },

        // ── Multi-track methods ──

        setMultiTrack(tracks: LoadedTrack[], pilotScores: PilotScore[]) {
          multiTrackData = tracks;
          multiTrackScores = pilotScores;
          isMultiTrackMode = true;

          // Hide single-track layers
          if (map.getLayer('track-line')) map.setLayoutProperty('track-line', 'visibility', 'none');
          if (map.getLayer('track-line-outline')) map.setLayoutProperty('track-line-outline', 'visibility', 'none');

          // Build GeoJSON features for all tracks, colored by rank
          const features: GeoJSON.Feature[] = [];
          const nameFeatures: GeoJSON.Feature[] = [];
          const allBounds = { minLat: 90, maxLat: -90, minLon: 180, maxLon: -180 };

          for (let ti = 0; ti < tracks.length; ti++) {
            const track = tracks[ti];
            const score = pilotScores.find(ps => ps.pilotName === track.pilotName);
            const rank = score?.rank ?? ti + 1;
            // Color by position in the visible set, not original rank
            const color = getRankColor(ti + 1, tracks.length);

            // Build one LineString per track
            const coordinates: [number, number][] = [];
            for (const fix of track.fixes) {
              coordinates.push([fix.longitude, fix.latitude]);
              if (fix.latitude < allBounds.minLat) allBounds.minLat = fix.latitude;
              if (fix.latitude > allBounds.maxLat) allBounds.maxLat = fix.latitude;
              if (fix.longitude < allBounds.minLon) allBounds.minLon = fix.longitude;
              if (fix.longitude > allBounds.maxLon) allBounds.maxLon = fix.longitude;
            }

            if (coordinates.length > 1) {
              features.push({
                type: 'Feature',
                properties: { color, trackIndex: ti, pilotName: track.pilotName, rank },
                geometry: { type: 'LineString', coordinates },
              });

              // Name the track at its landing point (detected landing event,
              // else the final fix) so tracks are attributable at a glance
              const landing = track.events.find(e => e.type === 'landing');
              const landingDetails = landing?.details as { fixIndex?: number } | undefined;
              const landingFix = track.fixes[landingDetails?.fixIndex ?? track.fixes.length - 1]
                ?? track.fixes[track.fixes.length - 1];
              nameFeatures.push({
                type: 'Feature',
                properties: { name: track.pilotName, color },
                geometry: { type: 'Point', coordinates: [landingFix.longitude, landingFix.latitude] },
              });
            }
          }

          updateGeoJSONSource(map, 'multi-track', features);
          updateGeoJSONSource(map, 'multi-track-names', nameFeatures);

          // Show multi-track layers
          if (map.getLayer('multi-track-line')) map.setLayoutProperty('multi-track-line', 'visibility', 'visible');
          if (map.getLayer('multi-track-outline')) map.setLayoutProperty('multi-track-outline', 'visibility', 'visible');

          // Fit bounds to all tracks (re-measure first — see setTrack)
          if (features.length > 0) {
            map.resize();
            map.fitBounds(
              [[allBounds.minLon, allBounds.minLat], [allBounds.maxLon, allBounds.maxLat]],
              { padding: 50, duration: 1000 },
            );
          }

          // In 3D mode, render all tracks
          if (is3DMode && tb) {
            clearMulti3DTracks();
            renderMulti3DTracks(tracks, pilotScores);
            removeAltitudeScrubber();
            createMultiTrackScrubber(tracks, pilotScores);
          }
        },

        clearMultiTrack() {
          isMultiTrackMode = false;
          multiTrackData = [];
          multiTrackScores = [];
          updateGeoJSONSource(map, 'multi-track', []);
          updateGeoJSONSource(map, 'multi-track-names', []);
          if (map.getLayer('multi-track-line')) map.setLayoutProperty('multi-track-line', 'visibility', 'none');
          if (map.getLayer('multi-track-outline')) map.setLayoutProperty('multi-track-outline', 'visibility', 'none');
          // Restore single-track layers
          if (map.getLayer('track-line')) map.setLayoutProperty('track-line', 'visibility', 'visible');
          if (map.getLayer('track-line-outline')) map.setLayoutProperty('track-line-outline', 'visibility', 'visible');
          clearMulti3DTracks();
        },

        setOpenDistanceLines(lines: OpenDistanceLine[]) {
          openDistanceLineData = lines;
          const features = lines.map((line) => ({
            type: 'Feature' as const,
            properties: {
              pilotName: line.pilotName,
              label: formatDistance(line.distance, { decimals: 1 }).withUnit,
            },
            geometry: {
              type: 'LineString' as const,
              coordinates: [
                [line.origin.lon, line.origin.lat],
                [line.end.lon, line.end.lat],
              ],
            },
          }));
          updateGeoJSONSource(map, 'open-distance-lines', features);

          // With no track loaded (a manual open-distance flight — an
          // open-distance task has a single take-off waypoint, so setTask's
          // task-bounds fit collapsed to that one point and zoomed all the way
          // in). Fit to the scored line so the whole flight is visible, and
          // include the take-off cylinder so its extent isn't cut off.
          if (currentFixes.length === 0 && lines.length > 0) {
            map.resize();
            const bounds = new mapboxgl.LngLatBounds();
            for (const line of lines) {
              bounds.extend([line.origin.lon, line.origin.lat]);
              bounds.extend([line.end.lon, line.end.lat]);
            }
            const takeoff = currentTask?.turnpoints[0];
            if (takeoff) {
              const latD = takeoff.radius / 111_320;
              const lonD =
                takeoff.radius /
                (111_320 * Math.cos((takeoff.waypoint.lat * Math.PI) / 180));
              bounds.extend([takeoff.waypoint.lon - lonD, takeoff.waypoint.lat - latD]);
              bounds.extend([takeoff.waypoint.lon + lonD, takeoff.waypoint.lat + latD]);
            }
            map.fitBounds(bounds, { padding: 50, duration: 1000 });
          }
        },

        clearOpenDistanceLines() {
          openDistanceLineData = [];
          updateGeoJSONSource(map, 'open-distance-lines', []);
        },

        setBestProgressRoute(route: BestProgressRoute) {
          bestProgressRouteData = route;
          if (route.coords.length < 2) {
            updateGeoJSONSource(map, 'best-progress-route', []);
            return;
          }
          const label = `${formatDistance(route.distanceToGoal, { decimals: 1 }).withUnit} short of goal`;
          updateGeoJSONSource(map, 'best-progress-route', [
            {
              type: 'Feature' as const,
              properties: { label },
              geometry: {
                type: 'LineString' as const,
                coordinates: route.coords.map((c) => [c.lon, c.lat]),
              },
            },
          ]);
        },

        clearBestProgressRoute() {
          bestProgressRouteData = null;
          updateGeoJSONSource(map, 'best-progress-route', []);
        },

        onMultiTrackClick(callback: (trackIndex: number, fixIndex: number) => void) {
          multiTrackClickCallback = callback;
        },

        showTrackPointHUDWithName(fixIndex: number, pilotName: string) {
          // For multi-track mode, use the track's fixes directly from multiTrackData
          const track = multiTrackData.find(t => t.pilotName === pilotName);
          const fixes = track?.fixes ?? currentFixes;
          const events = track?.events ?? currentEvents;

          const data = buildTrackPointHUDData(fixes, events, fixIndex, getNextTurnpointContext);
          if (!data) return;
          clearHudCrosshair();
          showGlideLegend(false);
          const crosshairEl = document.createElement('div');
          crosshairEl.innerHTML = CROSSHAIR_MAP_SVG;
          crosshairEl.style.pointerEvents = 'none';
          hudCrosshairMarker = new mapboxgl.Marker({ element: crosshairEl })
            .setLngLat([data.fix.longitude, data.fix.latitude])
            .addTo(map);
          if (!hudElement) {
            hudElement = createTrackPointHUD(container);
          }
          // Add pilot name to HUD
          const summaryEl = hudElement.querySelector('.hud-summary');
          if (summaryEl) {
            summaryEl.innerHTML = `${CROSSHAIR_MAP_SVG}<span style="font-weight:600;color:#ff8c00">${escapeHtml(pilotName)}</span>`;
          }
          updateTrackPointHUD(hudElement, data);
        },
      };

    } catch (err) {
      reject(err);
    }
  });
}

// createCirclePolygon is imported from map-provider-shared
