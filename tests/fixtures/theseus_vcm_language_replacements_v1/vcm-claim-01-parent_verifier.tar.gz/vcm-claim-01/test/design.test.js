import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { CSS, HTML, TOKENS } from "../src/serve/ui.js";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const tokens = async () =>
  JSON.parse(await readFile(path.join(root, "fixtures", "website-design-tokens.json"), "utf8"));
const tokens_ = tokens;

// BRAND PARITY GUARD.
//
// The dashboard is meant to read as part of opensourcesai.com, which means its
// palette is not a design choice made here — it is a copy of the site's, and a
// copy without a guard drifts the moment the site is restyled. The fixture is
// PARSED from the site's own stylesheet by scripts/sync-from-website.mjs, so
// this pins colour-for-colour against the real thing.
//
// If this fails, the site changed. Re-run the sync script in a deliberate
// commit — do not edit the expectations until they pass.
test("dashboard colours match the website's tokens exactly, both modes", async () => {
  const fixture = await tokens();

  const mapping = {
    bg: "color-bg",
    surface: "color-surface",
    surfaceSoft: "color-surface-soft",
    border: "color-border",
    text: "color-text",
    textMuted: "color-text-muted",
    primary: "color-primary",
    primaryHover: "color-primary-hover",
    success: "color-success",
    error: "color-error",
  };

  for (const mode of ["light", "dark"]) {
    for (const [ours, theirs] of Object.entries(mapping)) {
      assert.equal(
        TOKENS[mode][ours],
        fixture[mode][theirs],
        `${mode}.${ours} drifted from the site's --${theirs}`,
      );
    }
  }
});

// THE HUD PALETTE IS PINNED THE SAME WAY THE SITE TOKENS ARE.
//
// The dashboard's chrome follows the social-image style guide so the product
// looks like one product across its surfaces. That palette is a COPY, parsed
// from the guide's own colour table by the sync script — so a restyle there
// fails here rather than drifting.
test("HUD colours match the social-image style guide exactly", async () => {
  const { HUD } = await import("../src/serve/ui.js");
  const fixture = JSON.parse(
    await readFile(path.join(root, "fixtures", "website-social-palette.json"), "utf8"),
  );
  for (const [key, value] of Object.entries(fixture.palette)) {
    assert.equal(HUD[key], value, `HUD.${key} drifted from the style guide`);
  }
  // And the values must actually reach the served stylesheet, not merely exist
  // in an object nobody references.
  for (const value of Object.values(fixture.palette)) {
    assert.ok(CSS.includes(value), `${value} missing from the served CSS`);
  }
});

test("semantic colours still come from the site tokens", async () => {
  // success and error mean the same thing on every surface, so they stay on
  // the site palette even though the chrome moved to the HUD one.
  const tokens = await tokens_();
  assert.ok(CSS.includes(tokens.dark["color-success"]), "success must stay a site token");
  assert.ok(CSS.includes(tokens.dark["color-error"]), "error must stay a site token");
});

test("structural tokens match the website", async () => {
  const fixture = await tokens();
  assert.equal(TOKENS.radiusCard, fixture.structural["radius-card"]);
  assert.equal(TOKENS.radiusFrame, fixture.structural["radius-frame"]);
  assert.equal(TOKENS.content, fixture.structural.content);
});

// The HUD is deliberately dark-only.
//
// This test previously required a light theme to be served. The dashboard's
// chrome now follows the social-image language, which has no light variant —
// a light HUD reads as a mistake rather than a choice. The site's light tokens
// remain PINNED (the parity test above still covers them) and available to any
// future surface; they are simply not what this instrument uses.
test("the HUD is dark-only and says so, rather than half-supporting light", async () => {
  const fixture = await tokens();

  // If a light scheme is declared at all, it must not silently repaint the HUD
  // into a half-working state — it may only pin color-scheme.
  const lightBlock = /@media \(prefers-color-scheme: light\) \{([\s\S]*?)\n\}/.exec(CSS);
  assert.ok(lightBlock, "the light-scheme intent should be stated explicitly, not omitted");
  assert.doesNotMatch(lightBlock[1], /--color-bg|--color-surface|--color-text/, "the HUD must not partially theme for light");

  // The site's light tokens stay pinned by the parity test even though the
  // stylesheet no longer emits them.
  assert.ok(fixture.light["color-primary"], "the light palette must remain pinned for future surfaces");
});

test("the site's typography stack is used, not a generic one", async () => {
  const fixture = await tokens();
  // Referenced by name with the site's own fallbacks. The fonts are NOT
  // fetched — this package makes no external request — so a machine without
  // Inter installed lands on the same fallbacks the site's stack declares.
  assert.match(CSS, /--font-body:\s*Inter/, "body font must lead with Inter");
  assert.match(CSS, /--font-mono:\s*'JetBrains Mono'/, "mono font must lead with JetBrains Mono");
  assert.match(fixture.structural["font-body"], /inter/i, "the site still leads with Inter");
  assert.doesNotMatch(CSS, /@import|fonts\.googleapis|fonts\.gstatic/, "fonts must never be fetched");
});

test("the page is branded as part of the platform", () => {
  const html = HTML("t".repeat(64));
  assert.match(html, /OpenSourcesAI/, "the wordmark must be present");
  assert.match(html, /Command Center/, "the product name must be present");
  assert.match(html, /<title>Command Center — OpenSourcesAI<\/title>/);
  assert.match(html, /src="\/brand-icon\.png"/, "the brand mark must be shown");
  assert.match(html, /rel="icon" href="\/brand-icon\.png"/, "the favicon must be the brand mark");
});

test("the brand mark is served same-origin, never hotlinked or inlined", () => {
  const html = HTML("t".repeat(64));
  // Same-origin only: the CSP is img-src 'self' data:, and hotlinking the live
  // site would be both an external request and a broken image offline.
  assert.doesNotMatch(html, /https?:\/\/[^"']*\.(png|jpg|svg|webp)/i, "no remote image may be referenced");
  assert.doesNotMatch(html, /data:image\/[a-z+]+;base64,[A-Za-z0-9+/]{200,}/, "a 57 KB inline data URI would bloat every page load");
});

// THIS TEST PREVIOUSLY ENFORCED A CLAIM THAT BECAME FALSE.
//
// It asserted the interface says "Read-only". Phase 2 opened load and unload,
// so the badge was still promising something the tool no longer honoured — a
// stale trust claim, kept alive by a passing test. Caught from a screenshot,
// not from the suite, which is the point: a test can only protect a property
// someone remembered to restate when the property changed.
//
// The guarantee that still holds, and the one a user actually cares about, is
// that nothing is downloaded or destroyed. That is what the badge now says.
test("the interface states the CURRENT guarantee, not a stale one", () => {
  const html = HTML("t".repeat(64));
  assert.match(html, /Load \/ unload only/, "the badge must state what the tool actually does");
  assert.match(html, /never pulls, deletes or removes/, "the standing guarantee belongs in the interface");
  assert.doesNotMatch(
    html,
    /">Read-only</,
    "the read-only badge is no longer true — Phase 2 opened load and unload",
  );
});

// THE BROWSER BUNDLE MUST ACTUALLY PARSE.
//
// It is carried as a template literal inside this module, which makes two
// mistakes invisible to `node --check` on the server file: a nested backtick
// closes the outer literal early, and a nested interpolation is evaluated at
// module scope instead of in the browser. Both were hit while adding the
// sidebar — the second one inside a comment that was explaining the first.
// Only the server file is syntax-checked by tooling; this checks the payload.
test("the served JavaScript is syntactically valid", async () => {
  const { JS } = await import("../src/serve/ui.js");
  assert.doesNotThrow(() => new Function(JS), "the browser bundle does not parse");
  assert.ok(JS.length > 1000, "suspiciously small bundle — the template may have closed early");
});

test("the navigation shell is present for the browser bundle to populate", () => {
  const html = HTML("t".repeat(64));
  // The nav and live strip are filled in by script, so the markup only has to
  // provide their mount points — but if these ids drift, navigation silently
  // stops working with no error anywhere.
  assert.match(html, /id="sidenav"/, "the side navigation mount point must exist");
  assert.match(html, /id="livestrip"/, "the persistent live readout mount point must exist");
  assert.match(html, /aria-label="Dashboard sections"/, "navigation must be labelled for screen readers");
});
