"""Capture a reproducible README screenshot from a sanitized diagnosis report."""

from __future__ import annotations

import argparse
import ctypes
import sys
import time
from ctypes import wintypes
from pathlib import Path

from PIL import ImageGrab

from authkit.i18n import locale_label, set_locale
from authkit.models import DiagnosisReport, FailureCase, FixAction, HealthStatus, LayerResult
from authkit.ui.app import AuthKitApp


REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = REPO_ROOT / "docs" / "assets" / "authkit-codex-proxy-result-v1.png"


def build_sanitized_report() -> DiagnosisReport:
    """Return a deterministic Case A report containing no live machine data."""
    return DiagnosisReport(
        tool_version="0.4.0",
        platform="Windows 11 (sanitized sample)",
        client="codex",
        status=HealthStatus.UNHEALTHY,
        case=FailureCase.PROXY_PORT_MISMATCH,
        root_cause="Codex is pinned to stale proxy port 9999 while the reachable Windows proxy uses port 7890.",
        confidence="high",
        browser_explanation=(
            "Browser sign-in can succeed through the Windows proxy while the AI client still fails through its stale environment proxy."
        ),
        layers=[
            LayerResult(
                name="login_status",
                ok=True,
                summary="Local Codex credential markers are present; secret values were not read.",
            ),
            LayerResult(
                name="system_proxy",
                ok=True,
                summary="Windows proxy 127.0.0.1:7890 is reachable.",
            ),
            LayerResult(
                name="env_proxy",
                ok=False,
                summary="HTTPS_PROXY points to stale local port 9999.",
            ),
            LayerResult(
                name="oauth_endpoints",
                ok=False,
                summary="Codex OAuth path fails through the stale environment proxy.",
            ),
            LayerResult(
                name="callback_ports",
                ok=True,
                summary="Local OAuth callback ports are available.",
            ),
            LayerResult(
                name="network_profile",
                ok=True,
                summary="AI endpoint is reachable through the Windows system proxy.",
                details={
                    "key_facts": {
                        "ip": "203.0.113.24",
                        "ip_version": "IPv4",
                        "location": "Sanitized sample",
                        "isp": "Example network",
                        "risk_flags": [],
                        "score": 72,
                        "quality": "good",
                        "probe_path": "system_proxy",
                        "ai_endpoint_ok": True,
                    }
                },
            ),
        ],
        fixes=[
            FixAction(
                fix_id="sync-system-proxy",
                description="Medium risk · no admin · audited · rollback",
                command="authkit fix --apply --client codex",
                risk="medium",
                auto_applicable=True,
                admin_required=False,
                restart_required=False,
                rollback_supported=True,
                audit_required=True,
            )
        ],
        notes=["Reproducible documentation sample. IP and environment values are reserved or synthetic."],
    )


def capture(output: Path, *, overwrite: bool = False) -> Path:
    if sys.platform != "win32":
        raise RuntimeError("README screenshot capture requires Windows")
    if output.exists() and not overwrite:
        raise FileExistsError(f"output already exists: {output}; pass --force to replace it")

    output.parent.mkdir(parents=True, exist_ok=True)
    original_startup_profile = AuthKitApp._start_startup_network_profile
    AuthKitApp._start_startup_network_profile = lambda self: None
    app: AuthKitApp | None = None
    try:
        app = AuthKitApp()
        set_locale("en", persist=False)
        app.locale_var.set(locale_label("en"))
        app._apply_ui_texts()
        app._apply_fonts()
        app.geometry("1600x1000+120+120")
        app._show_report(build_sanitized_report(), refreshed=False)
        app.update_idletasks()
        app.deiconify()
        app.lift()
        app.attributes("-topmost", True)
        app.update()
        app.attributes("-topmost", False)
        time.sleep(0.4)
        app.update()
        if app._middle_paned is not None:
            app._middle_paned.sashpos(0, 900)
            app.update_idletasks()
            app.update()

        rect = wintypes.RECT()
        if not ctypes.windll.user32.GetWindowRect(app.winfo_id(), ctypes.byref(rect)):
            raise OSError("GetWindowRect failed for AuthKit window")
        image = ImageGrab.grab(
            bbox=(rect.left, rect.top, rect.right, rect.bottom),
            all_screens=True,
        )
        image.save(output, format="PNG", optimize=True)
        return output
    finally:
        AuthKitApp._start_startup_network_profile = original_startup_profile
        if app is not None:
            app.destroy()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--force", action="store_true", help="replace an existing output file")
    args = parser.parse_args()
    output = capture(args.out.resolve(), overwrite=args.force)
    print(f"Captured sanitized AuthKit README screenshot: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
