"""Series Collector application package."""

__version__ = "1.6.2"
