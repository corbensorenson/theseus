use crate::common::{InlineTestProject, semantic_graph::SemanticGraph};
use brokk_bifrost::analyzer::dataflow::{
    DataflowRequest, ExternalSummaryCompatibilityKey, SemanticInputStatus, SolverBudget,
    SummaryBehaviorKey, SummaryContextKey, SummarySchemaVersion, SummarySemanticsVersion,
    UnmodeledCallBehavior, WitnessReconstructionLimits, WitnessRetentionLimits,
};
use brokk_bifrost::analyzer::policy::{
    HumanRenderColor, HumanRenderDetail, HumanRenderOptions, PolicyEvaluationDate,
    PolicyEvaluationInput, PolicyEvaluationOptions, PolicyFindingEvidence, PolicyIncompleteReason,
    PolicyRunCompletion, PolicySemanticModelContext, PolicySourceIdentity, SarifToolIdentity,
    evaluate_policy_inputs_with_analyzer, evaluate_policy_inputs_with_analyzer_and_semantic_models,
    write_policy_human, write_policy_json, write_policy_sarif,
};
use brokk_bifrost::analyzer::semantic::{
    ControlContinuation, EvidenceCompleteness, IcfgProvider, OracleCallContext, ProcedureHandle,
    ProcedureKind, ProofStatus, SemanticBudget, SemanticRequest, ValueFlowOracle,
};
use brokk_bifrost::analyzer::semantic_model::{
    CatalogCoordinate, CatalogOptions, CompiledSemanticModelPack, CompilerOptions, DecodeLimits,
    ExactProcedureSummaryBoundary, ExactProcedureSummaryParameter, ExactProcedureSummaryReceiver,
    ExactProcedureSummaryTargetBinding, SemanticModelActivationControl,
    SemanticModelActivationEvidence, SemanticModelActivationRequest, SemanticModelControlAction,
    SemanticModelControlScope, SemanticModelPackSelector, SemanticModelResolutionOutcome,
    SemanticModelRuntimeLimits, SemanticPackCatalog, SessionPackSource, SessionPackSourceKind,
    SourceFormat, bind_compiled_procedure_summaries, compile_source, decode_shard_for_manifest,
    resolve_active_semantic_models,
};
use brokk_bifrost::analyzer::structural::{
    CodeQuery, CodeQueryDiagnosticCode, CodeQueryExecutionLimits, ProtocolRegistrationSet,
    TaintResultRef, TaintResultRegistration, TaintResultRegistrationError,
    TaintResultRegistrationLimits, TaintResultRegistrationOutcome, TaintResultRegistrationSet,
    TaintResultRegistrationSetError, ValueFlowPlanRegistrationSet,
    execute_workspace_request_with_all_analysis_registration_lease, project_taint_finding_report,
};
use brokk_bifrost::analyzer::taint::{
    SourceClassId, SourceEventKey, TaintAnalysisPlan, TaintClassSet, TaintFindingCollectionLimits,
    TaintSinkBinding, TaintSourceBinding, TaintUniverse, collect_taint_findings_with_limits,
    solve_taint_batch_with_witnesses,
};
use brokk_bifrost::analyzer::typestate::ProductionTypestateSummaryRepository;
use brokk_bifrost::analyzer::value_flow::{
    ValueFlowCarrier, ValueFlowEventKey, ValueFlowEventKind, ValueFlowInput,
    ValueFlowObservationPhase, ValueFlowPlan, ValueFlowSinkSpec, ValueFlowSourceSpec,
};
use brokk_bifrost::{AnalyzerConfig, CancellationToken, Language};
use semver::Version;
use std::path::Path;
use std::sync::Arc;

const WORKSPACE_GENERATION: u64 = 71;

const MODEL_ARTIFACT_SHA256: &str =
    "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";

const JAVA_EXTERNAL_SOURCE: &str = r#"
class App {
    static native String attacker();
    static native String clean();
    static native void sensitive(String value);
    native String external(String value, String sibling);

    void run() {
        sensitive(this.external(attacker(), clean()));
    }
}
"#;

const JAVA_BODY_SOURCE: &str = r#"
class App {
    static native String attacker();
    static native String clean();
    static native void sensitive(String value);

    String external(String value, String sibling) {
        return value;
    }

    void run() {
        sensitive(this.external(attacker(), clean()));
    }
}
"#;

const JAVA_DEPENDENCY_SOURCE: &str = r#"
class App {
    static native String attacker();
    static native String clean();
    static native void sensitive(String value);
    native String relay(String value);
    native String external(String value, String sibling);

    void run() {
        this.relay(clean());
        sensitive(this.external(attacker(), clean()));
    }
}
"#;

const SOURCE: &str = r#"
def source_one():
    return "one"

def source_two():
    return "two"

def sink_one(value):
    pass

def sink_two(value):
    pass

def run():
    first = source_one()
    second = source_two()
    sink_one(first)
    sink_two(second)
"#;

const INTERPROCEDURAL_SOURCE: &str = r#"
def source_one():
    return "one"

def sink_one(value):
    pass

def helper():
    return source_one()

def run():
    sink_one(helper())
"#;

const MATCHED_VALUE_SOURCE: &str = r#"
def source_one():
    return "one"

def sink_one(value):
    pass

def run():
    first = source_one()
    sink_one(first)
"#;

const SIBLING_CALLEE_SOURCE: &str = r#"
def source_one():
    return "one"

def sink_one(value):
    pass

def produce():
    return source_one()

def consume(value):
    sink_one(value)

def run():
    produced = produce()
    consume(produced)
"#;

fn policy(id: &str, message: &str, severity: &str) -> String {
    format!(
        r#"(policy
          :schema-version 1
          :id "{id}"
          :name "Production taint adapter"
          :message "{message}"
          :severity {severity}
          :analysis (analysis
            :type taint
            :mode may
            :call-modeling (call-modeling :unmodeled optimistic)
            :sources (endpoint-set :entries [
              (source :id first :display-name "first source" :categories [input.user]
                :selector (rql :schema-version 6
                  (language python (call :callee (name "source_one"))))
                :bind return-value :labels [untrusted])
              (source :id second :display-name "second source" :categories [input.user]
                :selector (rql :schema-version 6
                  (language python (call :callee (name "source_two"))))
                :bind return-value :labels [untrusted])])
            :sinks (endpoint-set :entries [
              (sink :id first-store :display-name "first sink" :categories [data.sensitive]
                :selector (rql :schema-version 6
                  (language python (call :callee (name "sink_one"))))
                :dangerous-operand (argument :index 0) :accepts [untrusted])
              (sink :id second-store :display-name "second sink" :categories [data.sensitive]
                :selector (rql :schema-version 6
                  (language python (call :callee (name "sink_two"))))
                :dangerous-operand (argument :index 0) :accepts [untrusted])]))
          :classification (classification
            :fallback (classification-id :taxonomy "Test" :id "BROAD-TAINT")))"#
    )
}

fn subset_policy(id: &str) -> String {
    format!(
        r#"(policy
          :schema-version 1
          :id "{id}"
          :name "Endpoint-neutral production taint adapter"
          :message "subset presentation"
          :severity note
          :analysis (analysis
            :type taint
            :mode may
            :call-modeling (call-modeling :unmodeled optimistic)
            :sources (endpoint-set :entries [
              (source :id first :display-name "first source" :categories [input.user]
                :selector (rql :schema-version 6
                  (language python (call :callee (name "source_one"))))
                :bind return-value :labels [untrusted])])
            :sinks (endpoint-set :entries [
              (sink :id first-store :display-name "first sink" :categories [data.sensitive]
                :selector (rql :schema-version 6
                  (language python (call :callee (name "sink_one"))))
                :dangerous-operand (argument :index 0) :accepts [untrusted])]))
          :classification (classification
            :fallback (classification-id :taxonomy "Test" :id "BROAD-TAINT")))"#
    )
}

fn single_policy(id: &str, source_selector: &str, source_binding: &str) -> String {
    format!(
        r#"(policy
          :schema-version 1
          :id "{id}"
          :name "Production taint adapter boundary"
          :message "taint boundary"
          :severity warning
          :analysis (analysis
            :type taint
            :mode may
            :call-modeling (call-modeling :unmodeled optimistic)
            :sources (endpoint-set :entries [
              (source :id first :display-name "first source" :categories [input.user]
                :selector (rql :schema-version 6 {source_selector})
                :bind {source_binding} :labels [untrusted])])
            :sinks (endpoint-set :entries [
              (sink :id first-store :display-name "first sink" :categories [data.sensitive]
                :selector (rql :schema-version 6
                  (language python (call :callee (name "sink_one"))))
                :dangerous-operand (argument :index 0) :accepts [untrusted])]))
          :classification (classification
            :fallback (classification-id :taxonomy "Test" :id "BROAD-TAINT")))"#
    )
}

fn java_summary_policy(id: &str, message: &str) -> String {
    format!(
        r#"(policy
          :schema-version 1
          :id "{id}"
          :name "Semantic-pack taint summary"
          :message "{message}"
          :severity warning
          :analysis (analysis
            :type taint
            :mode may
            :call-modeling (call-modeling :unmodeled require-model)
            :sources (endpoint-set :entries [
              (source :id attacker :display-name "attacker input" :categories [input.user]
                :selector (rql :schema-version 6
                  (language java (call :callee (name "attacker"))))
                :bind return-value :labels [untrusted])
              (source :id clean :display-name "clean sibling" :categories [input.user]
                :selector (rql :schema-version 6
                  (language java (call :callee (name "clean"))))
                :bind return-value :labels [untrusted])])
            :sinks (endpoint-set :entries [
              (sink :id sensitive :display-name "sensitive sink" :categories [data.sensitive]
                :selector (rql :schema-version 6
                  (language java (call :callee (name "sensitive"))))
                :dangerous-operand (argument :index 0) :accepts [untrusted])]))
          :classification (classification
            :fallback (classification-id :taxonomy "Test" :id "BROAD-TAINT")))"#
    )
}

fn procedure_summary_pack(
    pack_id: &str,
    model_effect: Option<&str>,
    include_unrelated: bool,
) -> CompiledSemanticModelPack {
    procedure_summary_pack_with_dependency(pack_id, model_effect, include_unrelated, false)
}

fn procedure_summary_dependency_pack(pack_id: &str) -> CompiledSemanticModelPack {
    procedure_summary_pack_with_dependency(pack_id, None, false, true)
}

fn procedure_summary_pack_with_dependency(
    pack_id: &str,
    model_effect: Option<&str>,
    include_unrelated: bool,
    include_dependency: bool,
) -> CompiledSemanticModelPack {
    let mut effects = model_effect
        .into_iter()
        .map(|event| {
            serde_json::json!({
                "kind": "unknown_call_boundary",
                "event": event
            })
        })
        .collect::<Vec<_>>();
    if include_dependency {
        effects.push(serde_json::json!({
            "kind": "call",
            "event": "event.external.relay",
            "callee": "summary.relay"
        }));
    }
    let mut summaries = vec![serde_json::json!({
        "id": "summary.external",
        "target": {
            "path": "app.java",
            "symbol": "external(String, String)",
            "has_receiver": true,
            "parameter_count": 2
        },
        "completeness": "complete",
        "transfers": [{
            "input": { "kind": "parameter", "ordinal": 0 },
            "exit_kind": "normal",
            "output": { "kind": "normal_return" }
        }],
        "effects": effects
    })];
    if include_dependency {
        summaries.push(serde_json::json!({
            "id": "summary.relay",
            "target": {
                "path": "app.java",
                "symbol": "relay(String)",
                "has_receiver": true,
                "parameter_count": 1
            },
            "completeness": "complete",
            "transfers": [{
                "input": { "kind": "parameter", "ordinal": 0 },
                "exit_kind": "normal",
                "output": { "kind": "normal_return" }
            }],
            "effects": []
        }));
    }
    if include_unrelated {
        summaries.push(serde_json::json!({
            "id": "summary.unrelated",
            "target": {
                "path": "other.java",
                "symbol": "unrelated(String)",
                "has_receiver": false,
                "parameter_count": 1
            },
            "completeness": "complete",
            "transfers": [{
                "input": { "kind": "parameter", "ordinal": 0 },
                "exit_kind": "normal",
                "output": { "kind": "normal_return" }
            }],
            "effects": []
        }));
    }
    let source = serde_json::to_vec(&serde_json::json!({
        "schema_version": 1,
        "pack_id": pack_id,
        "version": "1.0.0",
        "producer": { "name": "taint-summary-test", "version": "1.0.0" },
        "language": "java",
        "ecosystem": "maven",
        "compatibility": {
            "bifrost": ">=0.8.0, <1.0.0",
            "toolchains": [{ "name": "jdk", "requirement": ">=17.0.0" }]
        },
        "provenance": { "source": "test:semantic-pack", "revision": "reviewed" },
        "license": "Apache-2.0",
        "completeness": "complete",
        "safety": { "generated_code_only": false, "review_required": false },
        "shards": [{
            "id": "summaries.external",
            "activation": [{
                "package": { "name": "com.acme:external", "version": ">=1.0.0, <2.0.0" },
                "targets": ["jvm"],
                "configurations": ["release"],
                "artifact_sha256": MODEL_ARTIFACT_SHA256
            }],
            "payload": { "kind": "procedure_summaries", "summaries": summaries }
        }]
    }))
    .expect("semantic-pack source serialization");
    compile_source(SourceFormat::Json, &source, &CompilerOptions::default())
        .unwrap_or_else(|diagnostics| panic!("procedure-summary pack failed: {diagnostics:#?}"))
}

fn procedure_named(graph: &SemanticGraph, name: &str) -> ProcedureHandle {
    let procedure = graph
        .artifact()
        .procedures()
        .iter()
        .find(|procedure| {
            procedure.kind() == ProcedureKind::Method
                && procedure
                    .locator()
                    .declaration()
                    .segments()
                    .last()
                    .and_then(|segment| segment.name())
                    == Some(name)
        })
        .unwrap_or_else(|| panic!("missing Java method {name}"));
    graph.artifact().procedure_handle(procedure.id()).unwrap()
}

fn direct_model_backed_findings(
    project: &crate::common::BuiltInlineTestProject,
    workspace: &brokk_bifrost::analyzer::WorkspaceAnalyzer,
    pack: &CompiledSemanticModelPack,
) -> Vec<brokk_bifrost::analyzer::structural::CodeQueryTaintFinding> {
    let graph = SemanticGraph::materialize(project, workspace, "app.java");
    let root = procedure_named(&graph, "run");
    let cancellation = CancellationToken::default();
    let calls_named = |symbol: &str| {
        root.semantics()
            .call_sites()
            .iter()
            .filter(|call| {
                let mut budget = SemanticBudget::default();
                workspace
                    .icfg_provider()
                    .call_transfers(
                        &root,
                        call.id,
                        &mut SemanticRequest::new(&mut budget, &cancellation),
                    )
                    .ok()
                    .and_then(|outcome| outcome.available_value().cloned())
                    .is_some_and(|transfers| {
                        transfers.boundaries.iter().any(|boundary| {
                            boundary
                                .dispatch
                                .exact_external_target()
                                .is_some_and(|target| target.symbol() == symbol)
                        })
                    })
            })
            .cloned()
            .collect::<Vec<_>>()
    };
    let call_named = |symbol: &str| {
        let calls = calls_named(symbol);
        let [call] = calls.as_slice() else {
            panic!("expected one Java call {symbol}, got {}", calls.len());
        };
        call.clone()
    };
    let attacker = call_named("attacker()");
    call_named("external(String, String)");
    let sensitive = call_named("sensitive(String)");
    let attacker_point = match attacker.normal_continuation {
        ControlContinuation::Target(point) => root.point_handle(point).unwrap(),
        ref other => panic!("attacker call lacks a normal continuation: {other:?}"),
    };
    let attacker_value = root.value_handle(attacker.result.unwrap()).unwrap();
    let sensitive_point = root.point_handle(sensitive.point).unwrap();
    let sensitive_value = root
        .value_handle(sensitive.arguments[0].value)
        .expect("sensitive argument value");
    let mut source_endpoints = vec![(attacker_point, ValueFlowCarrier::Value(attacker_value))];
    for clean in calls_named("clean()") {
        let point = match clean.normal_continuation {
            ControlContinuation::Target(point) => root.point_handle(point).unwrap(),
            ref other => panic!("clean call lacks a normal continuation: {other:?}"),
        };
        let value = root.value_handle(clean.result.unwrap()).unwrap();
        source_endpoints.push((point, ValueFlowCarrier::Value(value)));
    }
    source_endpoints.sort_by_key(|(point, _)| point.id());
    let sources = source_endpoints
        .into_iter()
        .enumerate()
        .map(|(index, (point, carrier))| {
            ValueFlowSourceSpec::new(
                ValueFlowEventKey::at_point(
                    &point,
                    u32::try_from(index).unwrap(),
                    ValueFlowEventKind::Source,
                )
                .unwrap(),
                point,
                ValueFlowObservationPhase::BeforeEffects,
                carrier,
                ProofStatus::Proven,
                EvidenceCompleteness::Complete,
            )
        })
        .collect();
    let sink = ValueFlowSinkSpec::new(
        ValueFlowEventKey::at_point(&sensitive_point, 0, ValueFlowEventKind::Sink).unwrap(),
        sensitive_point,
        ValueFlowObservationPhase::BeforeEffects,
        ValueFlowCarrier::Value(sensitive_value),
        ProofStatus::Proven,
        EvidenceCompleteness::Complete,
    );
    let mut semantic_budget = SemanticBudget::default();
    let snapshot = workspace
        .semantic_oracle_provider()
        .procedure_relations(
            &root,
            &OracleCallContext::empty(),
            &mut SemanticRequest::new(&mut semantic_budget, &cancellation),
        )
        .expect("direct oracle value-flow snapshot");
    let status = SemanticInputStatus::from_outcome(&snapshot);
    let snapshot = snapshot.available_value().unwrap().clone();
    let exact_targets = root
        .semantics()
        .call_sites()
        .iter()
        .flat_map(|call| {
            let mut budget = SemanticBudget::default();
            workspace
                .icfg_provider()
                .call_transfers(
                    &root,
                    call.id,
                    &mut SemanticRequest::new(&mut budget, &cancellation),
                )
                .ok()
                .and_then(|outcome| outcome.available_value().cloned())
                .into_iter()
                .flat_map(|transfers| {
                    transfers
                        .boundaries
                        .iter()
                        .filter_map(|boundary| boundary.dispatch.exact_external_target().cloned())
                        .collect::<Vec<_>>()
                })
        })
        .collect::<Vec<_>>();
    let shard = decode_shard_for_manifest(
        &pack.manifest,
        &pack.shards[0].descriptor,
        &pack.shards[0].bytes,
        &DecodeLimits::default(),
    )
    .expect("decode direct-oracle procedure summaries");
    let summaries = shard
        .payload()
        .procedure_summaries()
        .expect("procedure-summary payload");
    let compatibility = ExternalSummaryCompatibilityKey::new(
        SummarySchemaVersion::CURRENT,
        SummarySemanticsVersion::hash_bytes(b"bifrost.production-value-flow.semantic-pack.v1"),
        SummaryContextKey::hash_bytes(b"bifrost.production-value-flow.empty-call-context.v1"),
        SummaryBehaviorKey::hash_bytes(b"bifrost.production-value-flow.external-boundary.v1")
            .with_unmodeled_call_behavior(UnmodeledCallBehavior::RequireModel),
        root.artifact().key().dependencies(),
        UnmodeledCallBehavior::RequireModel,
    );
    let bindings = summaries
        .iter()
        .map(|summary| {
            let target = exact_targets
                .iter()
                .find(|target| {
                    target.artifact().path().as_str() == summary.target.path
                        && target.symbol() == summary.target.symbol
                        && target.has_receiver() == summary.target.has_receiver
                        && target.parameter_count() == summary.target.parameter_count
                })
                .unwrap_or_else(|| panic!("missing exact target for {}", summary.id));
            let boundary = ExactProcedureSummaryBoundary::new(
                summary
                    .target
                    .has_receiver
                    .then_some(ExactProcedureSummaryReceiver),
                (0..summary.target.parameter_count)
                    .map(ExactProcedureSummaryParameter::new)
                    .collect(),
            );
            ExactProcedureSummaryTargetBinding::new(
                summary.id.clone(),
                summary.target.clone(),
                target.artifact().clone(),
                target.procedure().clone(),
                boundary,
            )
        })
        .collect();
    let external_summaries = bind_compiled_procedure_summaries(summaries, bindings, compatibility)
        .expect("independent direct summary binding");
    let value_flow = ValueFlowPlan::with_call_behavior(
        root.clone(),
        vec![ValueFlowInput::new(snapshot, status)],
        Vec::new(),
        sources,
        vec![sink],
        UnmodeledCallBehavior::RequireModel,
    )
    .unwrap()
    .with_external_summaries(external_summaries)
    .expect("direct model-backed value-flow plan");
    let universe = TaintUniverse::new(vec![SourceClassId::new("untrusted").unwrap()]).unwrap();
    let classes: TaintClassSet = universe.class_set(universe.classes()).unwrap();
    let sources = value_flow
        .sources()
        .map(|(id, spec)| {
            TaintSourceBinding::new(id, classes.clone(), SourceEventKey::new(spec.key().clone()))
        })
        .collect();
    let sinks = value_flow
        .sinks()
        .map(|(id, _)| TaintSinkBinding::new(id, classes.clone()))
        .collect();
    let plan = TaintAnalysisPlan::new(value_flow, universe, sources, sinks, Vec::new(), Vec::new())
        .expect("direct taint plan");
    let mut solver_budget = SolverBudget::default();
    let result = solve_taint_batch_with_witnesses(
        &root,
        &workspace.icfg_provider(),
        &plan,
        WitnessRetentionLimits::new(8).unwrap(),
        &mut semantic_budget,
        &mut DataflowRequest::new(&mut solver_budget, &cancellation),
    )
    .expect("direct model-backed taint solve");
    let report = collect_taint_findings_with_limits(
        &plan,
        result,
        8,
        WitnessReconstructionLimits::default(),
        TaintFindingCollectionLimits::new(64, 64, 16_384, 16_384, 16 * 1024 * 1024).unwrap(),
    )
    .expect("direct model-backed taint findings");
    project_taint_finding_report(
        workspace,
        &plan,
        &report,
        "direct-model-backed-oracle",
        brokk_bifrost::analyzer::structural::CodeQueryTaintProjectionLimits::new(
            usize::MAX,
            usize::MAX,
            usize::MAX,
            usize::MAX,
        ),
    )
    .expect("direct public taint projection")
}

fn semantic_model_request(version: &str, artifact_sha256: &str) -> SemanticModelActivationRequest {
    SemanticModelActivationRequest {
        bifrost_version: Version::parse("0.8.17").unwrap(),
        evidence: vec![SemanticModelActivationEvidence {
            language: "java".to_owned(),
            ecosystem: "maven".to_owned(),
            package: Some(CatalogCoordinate {
                name: "com.acme:external".to_owned(),
                version: Some(Version::parse(version).unwrap()),
            }),
            module: None,
            toolchain: Some(CatalogCoordinate {
                name: "jdk".to_owned(),
                version: Some(Version::parse("17.0.1").unwrap()),
            }),
            target: Some("jvm".to_owned()),
            configuration: Some("release".to_owned()),
            artifact_sha256: Some(artifact_sha256.to_owned()),
        }],
        controls: Vec::new(),
        limits: SemanticModelRuntimeLimits::default(),
    }
}

fn semantic_model_request_with_cache_key(cache_key: &str) -> SemanticModelActivationRequest {
    let mut request = semantic_model_request("1.5.0", MODEL_ARTIFACT_SHA256);
    request.controls.push(SemanticModelActivationControl {
        scope: SemanticModelControlScope::User,
        action: SemanticModelControlAction::Disable,
        selector: SemanticModelPackSelector {
            pack_id: format!("test.unused-{cache_key}"),
            version: None,
            manifest_digest: None,
        },
    });
    request
}

fn register_pack(catalog: &SemanticPackCatalog, pack: &CompiledSemanticModelPack, source_id: &str) {
    catalog
        .register_session_pack(
            pack,
            &SessionPackSource {
                kind: SessionPackSourceKind::Embedded,
                source_id: source_id.to_owned(),
            },
        )
        .expect("register procedure-summary pack");
}

fn evaluate_java_with_models(
    source: &str,
    policies: &[(&str, &str)],
    catalog: &SemanticPackCatalog,
    request: &SemanticModelActivationRequest,
) -> brokk_bifrost::analyzer::policy::PolicyBatchOutcome {
    let project = InlineTestProject::with_language(Language::Java)
        .file("app.java", source)
        .build();
    let workspace = project.workspace_analyzer(AnalyzerConfig::default());
    evaluate_java_workspace_with_models(project.root(), &workspace, policies, catalog, request)
}

fn evaluate_java_workspace_with_models(
    root: &Path,
    workspace: &brokk_bifrost::analyzer::WorkspaceAnalyzer,
    policies: &[(&str, &str)],
    catalog: &SemanticPackCatalog,
    request: &SemanticModelActivationRequest,
) -> brokk_bifrost::analyzer::policy::PolicyBatchOutcome {
    let policy_sources = policies
        .iter()
        .map(|(id, message)| java_summary_policy(id, message))
        .collect::<Vec<_>>();
    let inputs = policy_sources
        .iter()
        .enumerate()
        .map(|(index, source)| {
            PolicyEvaluationInput::embedded(
                PolicySourceIdentity::new(format!("test:semantic-summary-{index}.rqlp")),
                source,
            )
        })
        .collect::<Vec<_>>();
    let options = PolicyEvaluationOptions::new(
        PolicyEvaluationDate::from_ymd(2026, 7, 31).expect("fixed evaluation date"),
    );
    evaluate_policy_inputs_with_analyzer_and_semantic_models(
        root,
        &inputs,
        workspace,
        &options,
        PolicySemanticModelContext {
            catalog,
            request,
            persistence: None,
        },
        None,
    )
    .expect("production taint evaluation with semantic models")
}

fn propagation_identity(outcome: &brokk_bifrost::analyzer::policy::PolicyBatchOutcome) -> &str {
    let [analysis] = outcome.taint_analysis_results() else {
        panic!(
            "expected one retained production analysis, got {}",
            outcome.taint_analysis_results().len()
        )
    };
    analysis.compatibility().propagation_semantics()
}

fn active_shard_count(
    catalog: &SemanticPackCatalog,
    request: &SemanticModelActivationRequest,
) -> usize {
    match resolve_active_semantic_models(catalog, request, &CancellationToken::default()) {
        SemanticModelResolutionOutcome::Ready(active) => active.shards().len(),
        other => panic!("expected complete activation result, got {other:#?}"),
    }
}

fn evaluate_one(
    source: &str,
    policy_source: &str,
) -> brokk_bifrost::analyzer::policy::PolicyBatchOutcome {
    let project = InlineTestProject::with_language(Language::Python)
        .file("app.py", source)
        .build();
    let workspace = project.workspace_analyzer(AnalyzerConfig::default());
    let input = [PolicyEvaluationInput::embedded(
        PolicySourceIdentity::new("test:boundary.rqlp"),
        policy_source,
    )];
    let options = PolicyEvaluationOptions::new(
        PolicyEvaluationDate::from_ymd(2026, 7, 29).expect("fixed evaluation date"),
    );
    evaluate_policy_inputs_with_analyzer(project.root(), &input, &workspace, &options, None)
        .expect("production taint boundary evaluation")
}

/// Exercises every public consumer of one already-solved production result.
///
/// The policy run is the only authority allowed to compile and solve the
/// taint analysis. JSON and RQL deliberately receive the same retained result
/// through two aliases, so this catches a projection that accidentally grows a
/// second analysis path.
fn assert_retained_taint_projection_matrix(
    outcome: &brokk_bifrost::analyzer::policy::PolicyBatchOutcome,
    workspace: &brokk_bifrost::analyzer::WorkspaceAnalyzer,
) {
    let [retained] = outcome.taint_analysis_results() else {
        panic!(
            "expected one retained production analysis, got {}",
            outcome.taint_analysis_results().len()
        );
    };
    assert!(retained.plan_report_match());
    let expected = retained
        .project_findings(workspace, retained.projection_limits())
        .expect("retained production projection");
    assert_eq!(expected, outcome.taint_findings());

    let primary = TaintResultRef::new("production", "primary").expect("taint ref");
    let alias = TaintResultRef::new("production", "alias").expect("taint ref");
    let mut registrations = TaintResultRegistrationSet::default();
    for reference in [&primary, &alias] {
        registrations
            .register(
                reference.clone(),
                TaintResultRegistration::new(WORKSPACE_GENERATION, vec![Arc::clone(retained)])
                    .expect("retained result registration"),
            )
            .expect("register retained result");
    }
    assert_eq!(registrations.registration_count(), 1);

    let json_query = CodeQuery::from_json(&serde_json::json!({
        "schema_version": 7,
        "match": { "kind": "method", "name": "run" },
        "steps": [
            { "op": "procedure_of" },
            { "op": "taint", "taint_ref": "production:primary" }
        ]
    }))
    .expect("schema-v7 taint JSON query");
    let rql_query = CodeQuery::from_sexp(
        r#"(taint :taint-ref production:alias (procedure-of (method :name "run")))"#,
    )
    .expect("schema-v7 taint RQL query");
    let execute = |query: &CodeQuery| {
        let summaries = Arc::new(ProductionTypestateSummaryRepository::new());
        execute_workspace_request_with_all_analysis_registration_lease(
            workspace,
            WORKSPACE_GENERATION,
            &ProtocolRegistrationSet::default(),
            &ValueFlowPlanRegistrationSet::default(),
            &registrations,
            query,
            CodeQueryExecutionLimits::default(),
            None,
            summaries
                .lease(WORKSPACE_GENERATION)
                .expect("generation-scoped summary lease"),
        )
    };
    let json_response = execute(&json_query);
    let json = json_response.result().expect("JSON taint result");
    let rql_response = execute(&rql_query);
    let rql = rql_response.result().expect("RQL taint result");
    assert!(json.diagnostics.is_empty(), "{:?}", json.diagnostics);
    assert!(rql.diagnostics.is_empty(), "{:?}", rql.diagnostics);
    let expected = serde_json::to_value(&expected).expect("canonical retained findings");
    let json_findings = serde_json::to_value(&json.results).expect("canonical JSON findings");
    let rql_findings = serde_json::to_value(&rql.results).expect("canonical RQL findings");
    assert_eq!(
        json_findings, rql_findings,
        "JSON and RQL must project identical retained taint evidence"
    );
    assert_eq!(canonical_retained_taint_findings(json_findings), expected);
}

fn canonical_retained_taint_findings(mut findings: serde_json::Value) -> serde_json::Value {
    let serde_json::Value::Array(rows) = &mut findings else {
        panic!("taint query results must be an array: {findings}");
    };
    for finding in rows {
        let serde_json::Value::Object(finding) = finding else {
            panic!("taint query result must be an object: {finding}");
        };
        assert_eq!(
            finding.remove("result_type"),
            Some(serde_json::json!("taint_finding"))
        );
        assert!(
            finding.remove("provenance").is_some(),
            "public query result must retain its query provenance"
        );
    }
    findings
}

fn canonical_taint_evidence(mut value: serde_json::Value) -> serde_json::Value {
    fn strip_run_identity(value: &mut serde_json::Value) {
        match value {
            serde_json::Value::Array(values) => {
                for value in values {
                    strip_run_identity(value);
                }
            }
            serde_json::Value::Object(fields) => {
                for field in [
                    "id",
                    "event_id",
                    "sink_event_id",
                    "finding_id",
                    "retained_bytes",
                ] {
                    fields.remove(field);
                }
                for value in fields.values_mut() {
                    strip_run_identity(value);
                }
            }
            _ => {}
        }
    }
    strip_run_identity(&mut value);
    value
}

fn assert_model_backed_renderers(outcome: &brokk_bifrost::analyzer::policy::PolicyBatchOutcome) {
    let finding_id = outcome.report().runs()[0].findings()[0].id().to_string();
    let mut human = Vec::new();
    write_policy_human(
        outcome.report(),
        &HumanRenderOptions::new(HumanRenderDetail::Verbose, HumanRenderColor::Plain),
        &mut human,
        usize::MAX,
    )
    .expect("model-backed human rendering");
    let mut json = Vec::new();
    write_policy_json(outcome.report(), &mut json, usize::MAX)
        .expect("model-backed JSON rendering");
    let mut sarif = Vec::new();
    write_policy_sarif(
        outcome.report(),
        &SarifToolIdentity::default(),
        &mut sarif,
        usize::MAX,
    )
    .expect("model-backed SARIF rendering");
    for rendered in [human, json, sarif] {
        let rendered = String::from_utf8(rendered).expect("UTF-8 policy output");
        assert!(rendered.contains(&finding_id));
        assert!(rendered.contains("BROAD-TAINT"));
        assert!(rendered.contains("untrusted"));
        assert!(rendered.contains("app.java"));
    }
}

#[test]
fn activated_java_parameter_to_return_summary_reaches_sensitive_sink_under_require_model() {
    let catalog = SemanticPackCatalog::open_ephemeral(CatalogOptions::default()).unwrap();
    let pack = procedure_summary_pack("test.external-flow", None, false);
    register_pack(&catalog, &pack, "external-flow");
    let request = semantic_model_request("1.5.0", MODEL_ARTIFACT_SHA256);
    let project = InlineTestProject::with_language(Language::Java)
        .file("app.java", JAVA_EXTERNAL_SOURCE)
        .build();
    let workspace = project.workspace_analyzer(AnalyzerConfig::default());
    let direct = direct_model_backed_findings(&project, &workspace, &pack);
    let outcome = evaluate_java_workspace_with_models(
        project.root(),
        &workspace,
        &[("test.semantic-summary-flow", "modeled external flow")],
        &catalog,
        &request,
    );

    assert_eq!(
        outcome.report().runs().len(),
        1,
        "{:?}",
        outcome.report().diagnostics()
    );
    let run = &outcome.report().runs()[0];
    assert_eq!(
        run.findings().len(),
        1,
        "completion={:?} diagnostics={:?} work={:?} public={:?}",
        run.completion(),
        run.diagnostics(),
        run.work(),
        outcome.taint_findings()
    );
    assert_eq!(
        outcome.taint_findings().len(),
        1,
        "policy projection must retain the flow"
    );
    let finding = &run.findings()[0];
    assert_eq!(
        finding
            .classification()
            .broad()
            .expect("broad fallback classification")
            .identifier(),
        "BROAD-TAINT"
    );
    assert!(
        finding
            .witnesses()
            .iter()
            .any(|witness| witness.steps().len() > 2),
        "modeled external flow must retain a propagation witness: {:?}",
        finding.witnesses()
    );
    let PolicyFindingEvidence::Taint { evidence } = finding.evidence() else {
        panic!("expected taint policy projection")
    };
    assert_eq!(evidence.origins().len(), 1);
    assert_eq!(
        canonical_taint_evidence(serde_json::to_value(&direct).unwrap()),
        canonical_taint_evidence(serde_json::to_value(outcome.taint_findings()).unwrap()),
        "production compilation must agree with the independent direct-flow oracle"
    );
    assert_retained_taint_projection_matrix(&outcome, &workspace);
    assert_model_backed_renderers(&outcome);
    let projected =
        serde_json::to_value(outcome.taint_findings()).expect("stable public taint serialization");
    assert_eq!(projected[0]["origins"].as_array().map(Vec::len), Some(1));
    assert_eq!(
        projected[0]["reached_labels"],
        serde_json::json!(["untrusted"])
    );
    assert_eq!(projected[0]["evidence"]["proof"], "unproven");
    assert_eq!(projected[0]["evidence"]["completeness"], "partial");
    assert_eq!(projected[0]["ambiguous"], true);
    assert!(projected[0].get("origins_truncated").is_none());
    assert!(projected[0].get("witnesses_truncated").is_none());
    assert_eq!(
        projected[0]["origins"][0]["site"],
        serde_json::json!({
            "path": "app.java",
            "range": {"start_line": 9, "start_column": 33, "end_line": 9, "end_column": 43}
        })
    );
    assert_eq!(
        projected[0]["sink"],
        serde_json::json!({
            "path": "app.java",
            "range": {"start_line": 9, "start_column": 9, "end_line": 9, "end_column": 54}
        })
    );
    let witnesses = projected[0]["witnesses"]
        .as_array()
        .expect("ordered retained witnesses");
    assert_eq!(witnesses.len(), 2);
    let step_signature = |step: &serde_json::Value| {
        serde_json::json!({
            "kind": step["kind"],
            "boundary": step.get("boundary"),
            "source": step["source"]["range"],
            "target": step.get("target").and_then(|target| target.get("range")),
            "origin": step.get("origin").and_then(|origin| origin.get("range")),
            "input": step["input"]["kind"],
            "output": step["output"]["kind"],
        })
    };
    let signatures = witnesses
        .iter()
        .map(|witness| {
            witness["steps"]
                .as_array()
                .unwrap()
                .iter()
                .map(step_signature)
                .collect::<Vec<_>>()
        })
        .collect::<Vec<_>>();
    let expected_prefix = serde_json::json!([
        {"kind":{"type":"seed"},"boundary":null,"source":{"start_line":8,"start_column":5,"end_line":10,"end_column":6},"target":null,"origin":null,"input":"zero","output":"zero"},
        {"kind":{"type":"edge","edge_kind":"normal"},"boundary":null,"source":{"start_line":8,"start_column":5,"end_line":10,"end_column":6},"target":{"start_line":8,"start_column":16,"end_line":10,"end_column":6},"origin":null,"input":"zero","output":"zero"},
        {"kind":{"type":"edge","edge_kind":"normal"},"boundary":null,"source":{"start_line":8,"start_column":16,"end_line":10,"end_column":6},"target":{"start_line":9,"start_column":9,"end_line":9,"end_column":55},"origin":null,"input":"zero","output":"zero"},
        {"kind":{"type":"edge","edge_kind":"normal"},"boundary":null,"source":{"start_line":9,"start_column":9,"end_line":9,"end_column":55},"target":{"start_line":9,"start_column":19,"end_line":9,"end_column":53},"origin":null,"input":"zero","output":"zero"},
        {"kind":{"type":"edge","edge_kind":"normal"},"boundary":null,"source":{"start_line":9,"start_column":19,"end_line":9,"end_column":53},"target":{"start_line":9,"start_column":19,"end_line":9,"end_column":23},"origin":null,"input":"zero","output":"zero"},
        {"kind":{"type":"edge","edge_kind":"normal"},"boundary":null,"source":{"start_line":9,"start_column":19,"end_line":9,"end_column":23},"target":{"start_line":9,"start_column":33,"end_line":9,"end_column":43},"origin":null,"input":"zero","output":"zero"},
        {"kind":{"type":"edge","edge_kind":"normal"},"boundary":null,"source":{"start_line":9,"start_column":33,"end_line":9,"end_column":43},"target":{"start_line":9,"start_column":33,"end_line":9,"end_column":43},"origin":null,"input":"zero","output":"zero"},
        {"kind":{"type":"edge","edge_kind":"call_to_normal_continuation"},"boundary":"unmaterialized","source":{"start_line":9,"start_column":33,"end_line":9,"end_column":43},"target":{"start_line":9,"start_column":33,"end_line":9,"end_column":43},"origin":{"start_line":9,"start_column":33,"end_line":9,"end_column":43},"input":"zero","output":"zero"},
        {"kind":{"type":"edge","edge_kind":"normal"},"boundary":null,"source":{"start_line":9,"start_column":33,"end_line":9,"end_column":43},"target":{"start_line":9,"start_column":45,"end_line":9,"end_column":52},"origin":null,"input":"zero","output":"carrier"},
        {"kind":{"type":"edge","edge_kind":"normal"},"boundary":null,"source":{"start_line":9,"start_column":45,"end_line":9,"end_column":52},"target":{"start_line":9,"start_column":45,"end_line":9,"end_column":52},"origin":null,"input":"carrier","output":"carrier"},
        {"kind":{"type":"edge","edge_kind":"call_to_normal_continuation"},"boundary":"unmaterialized","source":{"start_line":9,"start_column":45,"end_line":9,"end_column":52},"target":{"start_line":9,"start_column":45,"end_line":9,"end_column":52},"origin":{"start_line":9,"start_column":45,"end_line":9,"end_column":52},"input":"carrier","output":"carrier"},
        {"kind":{"type":"edge","edge_kind":"normal"},"boundary":null,"source":{"start_line":9,"start_column":45,"end_line":9,"end_column":52},"target":{"start_line":9,"start_column":19,"end_line":9,"end_column":53},"origin":null,"input":"carrier","output":"carrier"},
        {"kind":{"type":"edge","edge_kind":"call_to_normal_continuation"},"boundary":"unmaterialized","source":{"start_line":9,"start_column":19,"end_line":9,"end_column":53},"target":{"start_line":9,"start_column":19,"end_line":9,"end_column":53},"origin":{"start_line":9,"start_column":19,"end_line":9,"end_column":53},"input":"carrier","output":"carrier"},
        {"kind":{"type":"edge","edge_kind":"normal"},"boundary":null,"source":{"start_line":9,"start_column":19,"end_line":9,"end_column":53},"target":{"start_line":9,"start_column":9,"end_line":9,"end_column":54},"origin":null,"input":"carrier","output":"carrier"}
    ]);
    assert_eq!(signatures[0][..14], expected_prefix.as_array().unwrap()[..]);
    assert_eq!(signatures[1][..14], expected_prefix.as_array().unwrap()[..]);
    assert_eq!(
        signatures[0][14],
        serde_json::json!({"kind":{"type":"edge","edge_kind":"call_to_normal_continuation"},"boundary":"unmaterialized","source":{"start_line":9,"start_column":9,"end_line":9,"end_column":54},"target":{"start_line":9,"start_column":9,"end_line":9,"end_column":54},"origin":{"start_line":9,"start_column":9,"end_line":9,"end_column":54},"input":"carrier","output":"meeting"})
    );
    assert_eq!(
        signatures[1][14],
        serde_json::json!({"kind":{"type":"edge","edge_kind":"call_to_exceptional_continuation"},"boundary":"unmaterialized","source":{"start_line":9,"start_column":9,"end_line":9,"end_column":54},"target":{"start_line":9,"start_column":9,"end_line":9,"end_column":54},"origin":{"start_line":9,"start_column":9,"end_line":9,"end_column":54},"input":"carrier","output":"meeting"})
    );
    for witness in witnesses {
        assert_eq!(witness["omitted_steps_lower_bound"], 0);
        assert!(witness.get("truncated").is_none());
        assert!(witness.get("alternatives_truncated").is_none());
        assert!(witness.get("retention_truncated").is_none());
        for step in witness["steps"].as_array().unwrap() {
            assert!(step.get("source_symbol").is_some());
            assert!(step.get("input").is_some());
            assert!(step.get("output").is_some());
            if step.get("origin").is_some() {
                assert!(step.get("origin_symbol").is_some());
            }
        }
    }
    let projected = projected.to_string();
    assert!(
        !projected.contains("clean"),
        "the unrelated external-call argument must not contribute taint: {projected}"
    );
    assert!(
        !projected.contains(project.root().to_string_lossy().as_ref()),
        "public taint evidence must stay workspace-relative: {projected}"
    );
    assert_eq!(
        run.work()
            .metrics()
            .iter()
            .find(|metric| metric.name() == "taint.propagation_solves")
            .map(|metric| metric.value()),
        Some(1)
    );
}

#[test]
fn activated_java_summary_dependency_closure_matches_the_direct_oracle() {
    let catalog = SemanticPackCatalog::open_ephemeral(CatalogOptions::default()).unwrap();
    let pack = procedure_summary_dependency_pack("test.external-dependency");
    register_pack(&catalog, &pack, "external-dependency");
    let project = InlineTestProject::with_language(Language::Java)
        .file("app.java", JAVA_DEPENDENCY_SOURCE)
        .build();
    let workspace = project.workspace_analyzer(AnalyzerConfig::default());
    let direct = direct_model_backed_findings(&project, &workspace, &pack);
    let outcome = evaluate_java_workspace_with_models(
        project.root(),
        &workspace,
        &[("test.semantic-summary-dependency", "dependency closure")],
        &catalog,
        &semantic_model_request("1.5.0", MODEL_ARTIFACT_SHA256),
    );
    let run = &outcome.report().runs()[0];
    assert_eq!(run.findings().len(), 1, "{:?}", run.diagnostics());
    assert_eq!(outcome.taint_analysis_results().len(), 1);
    assert_eq!(
        canonical_taint_evidence(serde_json::to_value(direct).unwrap()),
        canonical_taint_evidence(serde_json::to_value(outcome.taint_findings()).unwrap()),
        "the selected two-summary closure must preserve exact direct-flow evidence"
    );
    assert_eq!(
        run.work()
            .metrics()
            .iter()
            .find(|metric| metric.name() == "taint.propagation_solves")
            .map(|metric| metric.value()),
        Some(1)
    );
}

#[test]
fn wrong_semantic_pack_artifact_or_version_never_activates_the_external_flow() {
    let catalog = SemanticPackCatalog::open_ephemeral(CatalogOptions::default()).unwrap();
    register_pack(
        &catalog,
        &procedure_summary_pack("test.external-near-miss", None, false),
        "external-near-miss",
    );
    for request in [
        semantic_model_request("2.5.0", MODEL_ARTIFACT_SHA256),
        semantic_model_request(
            "1.5.0",
            "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
        ),
    ] {
        assert_eq!(active_shard_count(&catalog, &request), 0);
        let outcome = evaluate_java_with_models(
            JAVA_EXTERNAL_SOURCE,
            &[("test.semantic-summary-near-miss", "inactive external flow")],
            &catalog,
            &request,
        );
        let run = &outcome.report().runs()[0];
        assert!(matches!(
            run.completion(),
            PolicyRunCompletion::Inconclusive { reasons }
                if reasons.contains(&PolicyIncompleteReason::PartialDiscovery)
        ));
        assert!(run.findings().is_empty());
        assert!(outcome.taint_findings().is_empty());
    }
}

#[test]
fn conflicting_external_summary_targets_fail_closed() {
    let catalog = SemanticPackCatalog::open_ephemeral(CatalogOptions::default()).unwrap();
    register_pack(
        &catalog,
        &procedure_summary_pack("test.external-conflict-a", None, false),
        "external-conflict-a",
    );
    register_pack(
        &catalog,
        &procedure_summary_pack(
            "test.external-conflict-b",
            Some("event.conflicting-model"),
            false,
        ),
        "external-conflict-b",
    );
    let outcome = evaluate_java_with_models(
        JAVA_EXTERNAL_SOURCE,
        &[(
            "test.semantic-summary-conflict",
            "conflicting external flow",
        )],
        &catalog,
        &semantic_model_request("1.5.0", MODEL_ARTIFACT_SHA256),
    );
    let run = &outcome.report().runs()[0];
    assert!(matches!(
        run.completion(),
        PolicyRunCompletion::Failed { .. }
    ));
    assert!(run.findings().is_empty());
    assert!(outcome.taint_findings().is_empty());
    assert!(outcome.taint_analysis_results().is_empty());
    assert!(run.diagnostics().iter().any(|diagnostic| {
        diagnostic
            .message()
            .contains("conflicting activated procedure summaries")
    }));
}

#[test]
fn only_relevant_external_summaries_change_propagation_identity() {
    let project = InlineTestProject::with_language(Language::Java)
        .file("app.java", JAVA_EXTERNAL_SOURCE)
        .build();
    let workspace = project.workspace_analyzer(AnalyzerConfig::default());
    let baseline_catalog = SemanticPackCatalog::open_ephemeral(CatalogOptions::default()).unwrap();
    register_pack(
        &baseline_catalog,
        &procedure_summary_pack("test.external-identity", None, false),
        "identity-baseline",
    );
    let baseline = evaluate_java_workspace_with_models(
        project.root(),
        &workspace,
        &[("test.semantic-summary-identity", "baseline")],
        &baseline_catalog,
        &semantic_model_request_with_cache_key("baseline"),
    );

    let changed_catalog = SemanticPackCatalog::open_ephemeral(CatalogOptions::default()).unwrap();
    register_pack(
        &changed_catalog,
        &procedure_summary_pack(
            "test.external-identity",
            Some("event.relevant-change"),
            false,
        ),
        "identity-changed",
    );
    let changed = evaluate_java_workspace_with_models(
        project.root(),
        &workspace,
        &[("test.semantic-summary-identity", "changed")],
        &changed_catalog,
        &semantic_model_request_with_cache_key("changed"),
    );
    assert_ne!(
        propagation_identity(&baseline),
        propagation_identity(&changed)
    );

    let unrelated_catalog = SemanticPackCatalog::open_ephemeral(CatalogOptions::default()).unwrap();
    register_pack(
        &unrelated_catalog,
        &procedure_summary_pack("test.external-identity", None, true),
        "identity-unrelated",
    );
    let unrelated = evaluate_java_workspace_with_models(
        project.root(),
        &workspace,
        &[("test.semantic-summary-identity", "unrelated")],
        &unrelated_catalog,
        &semantic_model_request_with_cache_key("unrelated"),
    );
    assert_eq!(
        propagation_identity(&baseline),
        propagation_identity(&unrelated),
        "an unrelated activated record must not enter the plan identity"
    );
}

#[test]
fn materialized_java_body_overrides_activated_external_summary() {
    let project = InlineTestProject::with_language(Language::Java)
        .file("app.java", JAVA_BODY_SOURCE)
        .build();
    let workspace = project.workspace_analyzer(AnalyzerConfig::default());
    let first_catalog = SemanticPackCatalog::open_ephemeral(CatalogOptions::default()).unwrap();
    register_pack(
        &first_catalog,
        &procedure_summary_pack("test.body-precedence", None, false),
        "body-precedence-a",
    );
    let first = evaluate_java_workspace_with_models(
        project.root(),
        &workspace,
        &[("test.body-precedence", "body precedence")],
        &first_catalog,
        &semantic_model_request_with_cache_key("body-a"),
    );
    assert_eq!(first.report().runs()[0].findings().len(), 1);

    let second_catalog = SemanticPackCatalog::open_ephemeral(CatalogOptions::default()).unwrap();
    register_pack(
        &second_catalog,
        &procedure_summary_pack(
            "test.body-precedence",
            Some("event.model-change-hidden-by-body"),
            false,
        ),
        "body-precedence-b",
    );
    let second = evaluate_java_workspace_with_models(
        project.root(),
        &workspace,
        &[("test.body-precedence", "body precedence")],
        &second_catalog,
        &semantic_model_request_with_cache_key("body-b"),
    );
    assert_eq!(second.report().runs()[0].findings().len(), 1);
    assert_eq!(
        canonical_taint_evidence(serde_json::to_value(first.taint_findings()).unwrap()),
        canonical_taint_evidence(serde_json::to_value(second.taint_findings()).unwrap()),
        "external model changes must not alter exact public evidence for an inspectable body"
    );
    assert_model_backed_renderers(&first);
    assert_model_backed_renderers(&second);
    assert_eq!(
        propagation_identity(&first),
        propagation_identity(&second),
        "a model for a materialized body must not affect propagation identity"
    );
}

#[test]
fn compatible_semantic_summary_policies_share_one_solve() {
    let catalog = SemanticPackCatalog::open_ephemeral(CatalogOptions::default()).unwrap();
    register_pack(
        &catalog,
        &procedure_summary_pack("test.external-batch", None, false),
        "external-batch",
    );
    let outcome = evaluate_java_with_models(
        JAVA_EXTERNAL_SOURCE,
        &[
            ("test.semantic-summary-batch-a", "first presentation"),
            ("test.semantic-summary-batch-b", "second presentation"),
        ],
        &catalog,
        &semantic_model_request("1.5.0", MODEL_ARTIFACT_SHA256),
    );
    assert_eq!(outcome.report().runs().len(), 2);
    assert_eq!(outcome.taint_analysis_results().len(), 1);
    for run in outcome.report().runs() {
        assert_eq!(run.findings().len(), 1, "{:?}", run.diagnostics());
        assert_eq!(
            run.work()
                .metrics()
                .iter()
                .find(|metric| metric.name() == "taint.propagation_solves")
                .map(|metric| metric.value()),
            Some(1)
        );
        assert_eq!(
            run.work()
                .metrics()
                .iter()
                .find(|metric| metric.name() == "taint.propagation_shared_memberships")
                .map(|metric| metric.value()),
            Some(1)
        );
    }
}

#[test]
fn warm_semantic_summary_execution_performs_no_per_call_catalog_lookup() {
    let catalog = SemanticPackCatalog::open_ephemeral(CatalogOptions::default()).unwrap();
    register_pack(
        &catalog,
        &procedure_summary_pack("test.external-warm", None, false),
        "external-warm",
    );
    let project = InlineTestProject::with_language(Language::Java)
        .file("app.java", JAVA_EXTERNAL_SOURCE)
        .build();
    let workspace = project.workspace_analyzer(AnalyzerConfig::default());
    let policy = java_summary_policy("test.semantic-summary-warm", "warm execution");
    let inputs = [PolicyEvaluationInput::embedded(
        PolicySourceIdentity::new("test:semantic-summary-warm.rqlp"),
        &policy,
    )];
    let options = PolicyEvaluationOptions::new(
        PolicyEvaluationDate::from_ymd(2026, 7, 31).expect("fixed evaluation date"),
    );
    let request = semantic_model_request("1.5.0", MODEL_ARTIFACT_SHA256);
    let evaluate = || {
        evaluate_policy_inputs_with_analyzer_and_semantic_models(
            project.root(),
            &inputs,
            &workspace,
            &options,
            PolicySemanticModelContext {
                catalog: &catalog,
                request: &request,
                persistence: None,
            },
            None,
        )
        .expect("warm semantic-summary evaluation")
    };

    let first = evaluate();
    assert_eq!(first.report().runs()[0].findings().len(), 1);
    let after_first = catalog.accounting().unwrap();
    let first_lookup_counts = (after_first.lookup_hits, after_first.lookup_misses);
    assert_eq!(first_lookup_counts, (1, 0));

    let second = evaluate();
    assert_eq!(second.report().runs()[0].findings().len(), 1);
    let after_second = catalog.accounting().unwrap();
    assert_eq!(
        (after_second.lookup_hits, after_second.lookup_misses),
        first_lookup_counts,
        "cached acquisition and every per-call target lookup must stay in memory"
    );
}

#[test]
fn production_taint_keeps_caller_and_callee_endpoints_in_one_call_region() {
    let policy = single_policy(
        "test.interprocedural-taint",
        "(language python (call :callee (name \"source_one\")))",
        "return-value",
    );
    let outcome = evaluate_one(INTERPROCEDURAL_SOURCE, &policy);
    assert_eq!(
        outcome.report().runs().len(),
        1,
        "{:?}",
        outcome.report().diagnostics()
    );
    assert_eq!(outcome.report().runs()[0].findings().len(), 1);
    assert_eq!(outcome.taint_findings().len(), 1);
}

#[test]
fn production_taint_discovers_an_unselected_common_caller_for_sibling_callees() {
    let policy = single_policy(
        "test.sibling-callee-taint",
        "(language python (call :callee (name \"source_one\")))",
        "return-value",
    );
    let outcome = evaluate_one(SIBLING_CALLEE_SOURCE, &policy);
    assert_eq!(
        outcome.report().runs().len(),
        1,
        "{:?}",
        outcome.report().diagnostics()
    );
    let run = &outcome.report().runs()[0];
    assert!(matches!(
        run.completion(),
        PolicyRunCompletion::Inconclusive { reasons }
            if reasons.contains(&PolicyIncompleteReason::PartialDiscovery)
    ));
    assert!(run.findings().is_empty());
    assert_eq!(outcome.taint_findings().len(), 1);
    assert_eq!(
        run.work()
            .metrics()
            .iter()
            .find(|metric| metric.name() == "taint.propagation_solves")
            .map(|metric| metric.value()),
        Some(1)
    );
}

#[test]
fn production_taint_matched_value_uses_the_direct_source_observation() {
    let policy = single_policy(
        "test.matched-value-taint",
        "(language python (name \"first\"))",
        "matched-value",
    );
    let outcome = evaluate_one(MATCHED_VALUE_SOURCE, &policy);
    assert_eq!(
        outcome.report().runs().len(),
        1,
        "{:?}",
        outcome.report().diagnostics()
    );
    let run = &outcome.report().runs()[0];
    assert!(
        run.diagnostics()
            .iter()
            .all(|diagnostic| !diagnostic.message().contains("semantic call site")),
        "{:?}",
        run.diagnostics()
    );
    assert_eq!(run.findings().len(), 1, "{:?}", run.diagnostics());
    assert_eq!(outcome.taint_findings().len(), 1);
}

#[test]
fn production_taint_complete_zero_match_is_clean_without_propagation() {
    let policy = single_policy(
        "test.zero-match-taint",
        "(language python (call :callee (name \"source_one\")))",
        "return-value",
    );
    let outcome = evaluate_one(
        r#"
def sink_one(value):
    pass

def run():
    sink_one("constant")
"#,
        &policy,
    );
    let run = &outcome.report().runs()[0];
    assert!(matches!(run.completion(), PolicyRunCompletion::Complete));
    assert!(run.findings().is_empty());
    assert!(run.diagnostics().is_empty());
    assert!(outcome.taint_findings().is_empty());
    assert!(
        run.work()
            .metrics()
            .iter()
            .all(|metric| metric.name() != "taint.propagation_solves")
    );
}

#[test]
fn production_taint_policies_share_a_batch_and_all_renderers_keep_the_same_evidence() {
    let project = InlineTestProject::with_language(Language::Python)
        .file("app.py", SOURCE)
        .build();
    let workspace = project.workspace_analyzer(AnalyzerConfig::default());
    let first = policy("test.taint-first", "first presentation", "warning");
    let second = subset_policy("test.taint-second");
    let inputs = [
        PolicyEvaluationInput::embedded(PolicySourceIdentity::new("test:first.rqlp"), &first),
        PolicyEvaluationInput::embedded(PolicySourceIdentity::new("test:second.rqlp"), &second),
    ];
    let options = PolicyEvaluationOptions::new(
        PolicyEvaluationDate::from_ymd(2026, 7, 29).expect("fixed evaluation date"),
    );
    let outcome =
        evaluate_policy_inputs_with_analyzer(project.root(), &inputs, &workspace, &options, None)
            .expect("production taint evaluation");

    assert_eq!(
        outcome.report().runs().len(),
        2,
        "report diagnostics: {:?}",
        outcome.report().diagnostics()
    );
    for run in outcome.report().runs() {
        assert!(
            matches!(
                run.completion(),
                PolicyRunCompletion::Complete | PolicyRunCompletion::Inconclusive { .. }
            ),
            "{:?}: {:?}",
            run.completion(),
            run.diagnostics()
        );
        let expected_findings = if run.policy_id().as_str() == "test.taint-first" {
            2
        } else {
            1
        };
        assert_eq!(run.findings().len(), expected_findings);
        assert_eq!(
            run.work()
                .metrics()
                .iter()
                .find(|metric| metric.name() == "taint.propagation_solves")
                .expect("taint solve metric")
                .value(),
            1
        );
        assert_eq!(
            run.work()
                .metrics()
                .iter()
                .find(|metric| metric.name() == "taint.propagation_shared_memberships")
                .expect("shared batch metric")
                .value(),
            1
        );
        for finding in run.findings() {
            assert_eq!(
                finding
                    .classification()
                    .broad()
                    .expect("broad fallback classification")
                    .identifier(),
                "BROAD-TAINT"
            );
            let PolicyFindingEvidence::Taint { evidence } = finding.evidence() else {
                panic!("expected taint evidence");
            };
            assert_eq!(evidence.reached_source_labels().len(), 1);
            assert_eq!(evidence.origins().len(), 1);
            assert!(!finding.witnesses().is_empty());
            assert_eq!(
                finding.completeness().is_complete(),
                matches!(run.completion(), PolicyRunCompletion::Complete)
            );
        }
    }

    assert_eq!(outcome.taint_findings().len(), 2);
    assert_eq!(outcome.taint_analysis_results().len(), 1);
    let retained = &outcome.taint_analysis_results()[0];
    assert!(retained.plan_report_match());
    assert!(retained.retained_plan_bytes() > 0);
    assert!(retained.retained_report_bytes() > 0);
    assert!(!retained.artifact_keys().is_empty());
    assert!(retained.retained_artifact_bytes() > 0);
    assert_eq!(
        retained
            .project_findings(&workspace, retained.projection_limits())
            .expect("retained production taint projection"),
        outcome.taint_findings()
    );
    assert_eq!(
        retained
            .project_findings(
                &workspace,
                brokk_bifrost::analyzer::structural::CodeQueryTaintProjectionLimits::new(
                    usize::MAX,
                    usize::MAX,
                    usize::MAX,
                    usize::MAX,
                ),
            )
            .expect("projection cannot exceed retained production authority"),
        outcome.taint_findings()
    );
    let first_ref = TaintResultRef::new("request", "primary").expect("bounded taint ref");
    let alias_ref = TaintResultRef::new("request", "alias").expect("bounded taint ref");
    let registration = TaintResultRegistration::new(7, vec![Arc::clone(retained)])
        .expect("valid retained taint registration");
    let mut registrations = TaintResultRegistrationSet::default();
    assert_eq!(
        registrations
            .register(first_ref.clone(), registration)
            .expect("insert retained taint result"),
        TaintResultRegistrationOutcome::Inserted
    );
    assert_eq!(
        registrations
            .register(
                alias_ref.clone(),
                TaintResultRegistration::new(7, vec![Arc::clone(retained)])
                    .expect("valid taint alias"),
            )
            .expect("alias retained taint result"),
        TaintResultRegistrationOutcome::Aliased
    );
    assert!(matches!(
        registrations.register(
            first_ref.clone(),
            TaintResultRegistration::new(8, vec![Arc::clone(retained)])
                .expect("different-generation registration"),
        ),
        Err(TaintResultRegistrationSetError::ReferenceConflict { .. })
    ));
    assert_eq!(registrations.reference_count(), 2);
    assert_eq!(registrations.registration_count(), 1);

    let json_query = CodeQuery::from_json(&serde_json::json!({
        "schema_version": 7,
        "match": { "kind": "function", "name": "run" },
        "steps": [
            { "op": "procedure_of" },
            { "op": "taint", "taint_ref": "request:primary" }
        ]
    }))
    .expect("schema-v7 taint JSON query");
    let rql_query = CodeQuery::from_sexp(
        r#"(taint :taint-ref request:alias (procedure-of (function :name "run")))"#,
    )
    .expect("schema-v7 taint RQL query");
    let execute = |query: &CodeQuery,
                   generation: u64,
                   taint_registrations: &TaintResultRegistrationSet,
                   limits: CodeQueryExecutionLimits| {
        let summaries = Arc::new(ProductionTypestateSummaryRepository::new());
        let lease = summaries
            .lease(generation)
            .expect("generation-scoped summary lease");
        execute_workspace_request_with_all_analysis_registration_lease(
            &workspace,
            generation,
            &ProtocolRegistrationSet::default(),
            &ValueFlowPlanRegistrationSet::default(),
            taint_registrations,
            query,
            limits,
            None,
            lease,
        )
    };
    let json_response = execute(
        &json_query,
        7,
        &registrations,
        CodeQueryExecutionLimits::default(),
    );
    let rql_response = execute(
        &rql_query,
        7,
        &registrations,
        CodeQueryExecutionLimits::default(),
    );
    let json_result = json_response.result().expect("executed JSON result");
    let rql_result = rql_response.result().expect("executed RQL result");
    assert!(
        json_result.diagnostics.is_empty(),
        "{:?}",
        json_result.diagnostics
    );
    assert!(
        rql_result.diagnostics.is_empty(),
        "{:?}",
        rql_result.diagnostics
    );
    assert_eq!(
        serde_json::to_value(&json_result.results).expect("JSON result serialization"),
        serde_json::to_value(&rql_result.results).expect("RQL result serialization")
    );
    assert_eq!(json_result.results.len(), outcome.taint_findings().len());

    let mut row_limited = CodeQueryExecutionLimits::default();
    row_limited.taint.max_findings = 1;
    let row_limited = execute(&json_query, 7, &registrations, row_limited);
    let row_limited = row_limited.result().expect("row-limited taint result");
    assert_eq!(row_limited.results.len(), 1);
    assert!(
        row_limited.diagnostics.iter().any(|diagnostic| {
            diagnostic.code == CodeQueryDiagnosticCode::TaintFindingTruncated
        })
    );

    let mut byte_limited = CodeQueryExecutionLimits::default();
    byte_limited.taint.max_projected_bytes = 1;
    let byte_limited = execute(&json_query, 7, &registrations, byte_limited);
    let byte_limited = byte_limited.result().expect("byte-limited taint result");
    assert!(byte_limited.results.is_empty());
    assert!(
        byte_limited.diagnostics.iter().any(|diagnostic| {
            diagnostic.code == CodeQueryDiagnosticCode::TaintFindingTruncated
        })
    );

    let missing_query = CodeQuery::from_json(&serde_json::json!({
        "schema_version": 7,
        "match": { "kind": "function", "name": "run" },
        "steps": [
            { "op": "procedure_of" },
            { "op": "taint", "taint_ref": "request:missing" }
        ]
    }))
    .expect("missing-ref taint query");
    let missing = execute(
        &missing_query,
        7,
        &registrations,
        CodeQueryExecutionLimits::default(),
    );
    assert!(
        missing
            .result()
            .expect("missing-ref result")
            .diagnostics
            .iter()
            .any(|diagnostic| diagnostic.code
                == CodeQueryDiagnosticCode::UnresolvedTaintResultReference)
    );

    let wrong_root_query = CodeQuery::from_json(&serde_json::json!({
        "schema_version": 7,
        "match": { "kind": "function", "name": "source_one" },
        "steps": [
            { "op": "procedure_of" },
            { "op": "taint", "taint_ref": "request:primary" }
        ]
    }))
    .expect("wrong-root taint query");
    let wrong_root = execute(
        &wrong_root_query,
        7,
        &registrations,
        CodeQueryExecutionLimits::default(),
    );
    assert!(
        wrong_root
            .result()
            .expect("wrong-root result")
            .diagnostics
            .iter()
            .any(|diagnostic| diagnostic.code == CodeQueryDiagnosticCode::TaintRootMismatch)
    );

    let stale = execute(
        &json_query,
        8,
        &registrations,
        CodeQueryExecutionLimits::default(),
    );
    assert!(
        stale
            .result()
            .expect("stale result")
            .diagnostics
            .iter()
            .any(|diagnostic| diagnostic.code == CodeQueryDiagnosticCode::TaintRegistrationStale)
    );

    assert!(registrations.unregister(&first_ref));
    assert_eq!(registrations.reference_count(), 1);
    assert_eq!(registrations.registration_count(), 1);
    assert!(registrations.unregister(&alias_ref));
    assert_eq!(registrations.registration_count(), 0);

    assert!(matches!(
        TaintResultRegistration::new(7, vec![Arc::clone(retained), Arc::clone(retained)]),
        Err(TaintResultRegistrationError::DuplicateRoot)
    ));
    let mut bounded = TaintResultRegistrationSet::with_limits(
        TaintResultRegistrationLimits::bounded(1, 1, 0, usize::MAX, usize::MAX),
    );
    assert!(matches!(
        bounded.register(
            first_ref,
            TaintResultRegistration::new(7, vec![Arc::clone(retained)])
                .expect("valid bounded registration"),
        ),
        Err(TaintResultRegistrationSetError::RetainedPlanBytes(0))
    ));
    assert_eq!(bounded.reference_count(), 0);
    assert_eq!(bounded.registration_count(), 0);
    assert_eq!(outcome.taint_query_results().len(), 2);
    for result in outcome.taint_query_results() {
        let value = serde_json::to_value(result).expect("public taint query serialization");
        assert_eq!(value["result_type"], "taint_finding");
        assert!(value.get("plan_ref").is_none());
        assert!(
            value["witnesses"]
                .as_array()
                .expect("taint witness array")
                .iter()
                .all(|witness| witness.get("plan_ref").is_none()
                    && witness.get("finding_id").is_some())
        );
    }
    assert!(outcome.taint_findings().iter().all(|finding| {
        finding.reached_labels == ["untrusted"]
            && finding.origins.len() == 1
            && !finding.witnesses.is_empty()
            && finding
                .witnesses
                .iter()
                .all(|witness| witness.finding_id == finding.id)
    }));

    let finding_ids = outcome
        .report()
        .runs()
        .iter()
        .flat_map(|run| run.findings())
        .map(|finding| finding.id().to_string())
        .collect::<Vec<_>>();
    let mut human = Vec::new();
    write_policy_human(
        outcome.report(),
        &HumanRenderOptions::new(HumanRenderDetail::Verbose, HumanRenderColor::Plain),
        &mut human,
        usize::MAX,
    )
    .expect("human rendering");
    let mut json = Vec::new();
    write_policy_json(outcome.report(), &mut json, usize::MAX).expect("JSON rendering");
    let mut sarif = Vec::new();
    write_policy_sarif(
        outcome.report(),
        &SarifToolIdentity::default(),
        &mut sarif,
        usize::MAX,
    )
    .expect("SARIF rendering");
    let human = String::from_utf8(human).expect("human UTF-8");
    let json = String::from_utf8(json).expect("JSON UTF-8");
    let sarif = String::from_utf8(sarif).expect("SARIF UTF-8");
    for finding_id in finding_ids {
        assert!(human.contains(&finding_id));
        assert!(json.contains(&finding_id));
        assert!(sarif.contains(&finding_id));
    }
    for rendered in [&human, &json, &sarif] {
        assert!(rendered.contains("BROAD-TAINT"));
        assert!(rendered.contains("untrusted"));
    }
}
