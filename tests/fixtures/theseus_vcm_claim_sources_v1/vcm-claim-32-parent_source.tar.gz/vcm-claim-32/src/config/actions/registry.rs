//! Purpose: declare the checked shortcut action inventory in one reviewable table.
//! Owns: stable names, help text, scopes, default chords, and keyboard/mouse classification.
//! Must not: contain parsing, dispatch, rendering, configuration IO, or tests.
//! Invariants: same-scope defaults do not collide after normalization.
//! Size: this is declarative inventory data; keeping the complete entry set flat makes order and
//!   collisions reviewable without adding runtime concatenation or duplicated lookup paths.

use super::{Descriptor, InputKind::*, Scope::*};

const E: &[super::Scope] = &[Editor];
const G: &[super::Scope] = &[Global];
const P: &[super::Scope] = &[Prompt];
const S: &[super::Scope] = &[Search];
const C: &[super::Scope] = &[Completion];
const V: &[super::Scope] = &[Preview];
const H: &[super::Scope] = &[Help];
const EH: &[super::Scope] = &[Editor, Help];
const EV: &[super::Scope] = &[Editor, Preview];
const NAV: &[super::Scope] = &[Editor, Preview, Help];
const PS: &[super::Scope] = &[Prompt, Search];

macro_rules! key {
    ($action:ident, $name:literal, $help:literal, $scopes:expr, [$($default:literal),+]) => {
        Descriptor { action: super::Action::$action, name: $name, help: $help, scopes: $scopes,
            defaults: &[$($default),+], input: Keyboard }
    };
}
macro_rules! mouse {
    ($action:ident, $name:literal, $help:literal, [$($default:literal),+]) => {
        Descriptor { action: super::Action::$action, name: $name, help: $help, scopes: E,
            defaults: &[$($default),+], input: MouseButton }
    };
}
macro_rules! wheel {
    ($action:ident, $name:literal, $help:literal, $default:literal) => {
        Descriptor {
            action: super::Action::$action,
            name: $name,
            help: $help,
            scopes: NAV,
            defaults: &[$default],
            input: MouseWheel,
        }
    };
}

pub(crate) const REGISTRY: &[Descriptor] = &[
    key!(Help, "help", "Toggle shortcut help", G, ["ctrl+h", "f1"]),
    key!(
        Quit,
        "quit",
        "Quit when all buffers are clean; a second request discards all dirty buffers.",
        G,
        ["ctrl+q"]
    ),
    key!(
        Interrupt,
        "interrupt",
        "Exit immediately through terminal teardown without saving.",
        G,
        ["ctrl+shift+c"]
    ),
    key!(
        Save,
        "save",
        "Save the active buffer; a repeated save confirms only the same observed disk conflict.",
        E,
        ["ctrl+s"]
    ),
    key!(
        SaveAs,
        "save-as",
        "Choose a new path for the active buffer.",
        E,
        ["ctrl+shift+s"]
    ),
    key!(
        Open,
        "open",
        "Open a path in another buffer.",
        E,
        ["ctrl+o"]
    ),
    key!(New, "new", "Create an untitled buffer.", E, ["ctrl+n"]),
    key!(
        Close,
        "close",
        "Close the active clean buffer; use the `close!` command only to discard it.",
        E,
        ["ctrl+w"]
    ),
    key!(
        Reload,
        "reload",
        "Check disk state; repeat only to confirm reloading the same observed revision.",
        E,
        ["ctrl+r"]
    ),
    key!(
        Lint,
        "lint",
        "Run the configured linter for the saved active file; Esc cancels.",
        E,
        ["f4"]
    ),
    key!(
        Search,
        "search",
        "Search incrementally; `Enter` or `Down` moves forward and `Up` moves backward.",
        EH,
        ["ctrl+f"]
    ),
    key!(
        Replace,
        "replace",
        "Open the two-stage Replace Next prompt.",
        E,
        ["ctrl+shift+f"]
    ),
    key!(
        GotoLine,
        "goto-line",
        "Jump to a 1-based line number.",
        E,
        ["ctrl+g"]
    ),
    key!(
        CommandPrompt,
        "command-prompt",
        "Run commands such as `config`, `recover`, and `close!` without a leading colon.",
        E,
        ["ctrl+shift+p", "f2"]
    ),
    key!(
        Complete,
        "complete",
        "Open local completion",
        E,
        ["ctrl+space"]
    ),
    key!(
        Undo,
        "undo",
        "Undo the last edit transaction.",
        E,
        ["ctrl+z"]
    ),
    key!(
        Redo,
        "redo",
        "Redo the next edit transaction.",
        E,
        ["ctrl+y", "ctrl+shift+z"]
    ),
    key!(MoveLeft, "move-left", "Move left", NAV, ["left"]),
    key!(MoveRight, "move-right", "Move right", NAV, ["right"]),
    key!(MoveUp, "move-up", "Move up", NAV, ["up"]),
    key!(MoveDown, "move-down", "Move down", NAV, ["down"]),
    key!(
        SelectLeft,
        "select-left",
        "Extend selection left",
        E,
        ["shift+left"]
    ),
    key!(
        SelectRight,
        "select-right",
        "Extend selection right",
        E,
        ["shift+right"]
    ),
    key!(
        SelectUp,
        "select-up",
        "Extend selection up",
        E,
        ["shift+up"]
    ),
    key!(
        SelectDown,
        "select-down",
        "Extend selection down",
        E,
        ["shift+down"]
    ),
    key!(LineStart, "line-start", "Move to line start", NAV, ["home"]),
    key!(LineEnd, "line-end", "Move to line end", NAV, ["end"]),
    key!(
        SelectLineStart,
        "select-line-start",
        "Select to line start",
        E,
        ["shift+home"]
    ),
    key!(
        SelectLineEnd,
        "select-line-end",
        "Select to line end",
        E,
        ["shift+end"]
    ),
    key!(
        DocumentStart,
        "document-start",
        "Move to document start",
        E,
        ["ctrl+home"]
    ),
    key!(
        DocumentEnd,
        "document-end",
        "Move to document end",
        E,
        ["ctrl+end"]
    ),
    key!(
        SelectDocumentStart,
        "select-document-start",
        "Select to document start",
        E,
        ["ctrl+shift+home"]
    ),
    key!(
        SelectDocumentEnd,
        "select-document-end",
        "Select to document end",
        E,
        ["ctrl+shift+end"]
    ),
    key!(
        ViewportUp,
        "viewport-up",
        "Move one viewport up",
        NAV,
        ["pageup"]
    ),
    key!(
        ViewportDown,
        "viewport-down",
        "Move one viewport down",
        NAV,
        ["pagedown"]
    ),
    key!(
        SelectViewportUp,
        "select-viewport-up",
        "Select one viewport up",
        E,
        ["shift+pageup"]
    ),
    key!(
        SelectViewportDown,
        "select-viewport-down",
        "Select one viewport down",
        E,
        ["shift+pagedown"]
    ),
    key!(
        WordLeft,
        "word-left",
        "Move one word left",
        E,
        ["ctrl+left"]
    ),
    key!(
        WordRight,
        "word-right",
        "Move one word right",
        E,
        ["ctrl+right"]
    ),
    key!(
        SelectWordLeft,
        "select-word-left",
        "Select one word left",
        E,
        ["ctrl+shift+left", "alt+shift+left"]
    ),
    key!(
        SelectWordRight,
        "select-word-right",
        "Select one word right",
        E,
        ["ctrl+shift+right", "alt+shift+right"]
    ),
    key!(
        ParagraphPrevious,
        "paragraph-previous",
        "Move to previous paragraph",
        E,
        ["ctrl+up"]
    ),
    key!(
        ParagraphNext,
        "paragraph-next",
        "Move to next paragraph",
        E,
        ["ctrl+down"]
    ),
    key!(
        DeleteBackward,
        "delete-backward",
        "Delete previous grapheme",
        E,
        ["backspace"]
    ),
    key!(
        DeleteForward,
        "delete-forward",
        "Delete next grapheme",
        E,
        ["delete"]
    ),
    key!(
        DeleteWordBackward,
        "delete-word-backward",
        "Delete previous word",
        E,
        ["ctrl+backspace"]
    ),
    key!(
        DeleteWordForward,
        "delete-word-forward",
        "Delete next word",
        E,
        ["ctrl+delete"]
    ),
    key!(
        InsertNewline,
        "insert-newline",
        "Insert an indented newline",
        E,
        ["enter"]
    ),
    key!(Indent, "indent", "Indent or insert to tab stop", E, ["tab"]),
    key!(
        Unindent,
        "unindent",
        "Unindent current or selected lines",
        E,
        ["shift+tab"]
    ),
    key!(
        ToggleOverwrite,
        "toggle-overwrite",
        "Toggle session-wide insert/overwrite typing.",
        E,
        ["insert"]
    ),
    key!(
        SelectAll,
        "select-all",
        "Select active buffer or page",
        E,
        ["ctrl+a"]
    ),
    key!(Copy, "copy", "Copy selection", E, ["ctrl+c"]),
    key!(Cut, "cut", "Cut selection", E, ["ctrl+x"]),
    key!(
        CutLine,
        "cut-line",
        "Cut the current line as one undoable edit.",
        E,
        ["ctrl+k"]
    ),
    key!(Paste, "paste", "Paste internal clipboard", E, ["ctrl+v"]),
    key!(
        PreviousBuffer,
        "previous-buffer",
        "Switch without closing or saving the current buffer.",
        E,
        ["alt+pageup"]
    ),
    key!(
        NextBuffer,
        "next-buffer",
        "Switch without closing or saving the current buffer.",
        E,
        ["alt+pagedown"]
    ),
    key!(
        PreviousPage,
        "previous-page",
        "Open previous large-file page",
        E,
        ["ctrl+pageup"]
    ),
    key!(
        NextPage,
        "next-page",
        "Open next large-file page",
        E,
        ["ctrl+pagedown"]
    ),
    key!(
        ToggleExternalDiff,
        "toggle-external-diff",
        "Toggle the latest external-reload markers for every buffer.",
        EV,
        ["f5"]
    ),
    key!(
        MarkdownPreview,
        "markdown-preview",
        "Toggle the rendered read-only Markdown view for the current buffer.",
        EV,
        ["f6"]
    ),
    key!(
        LineNumbers,
        "line-numbers",
        "Toggle line numbers",
        EV,
        ["f7"]
    ),
    key!(
        Whitespace,
        "whitespace",
        "Toggle visible whitespace",
        EV,
        ["f8"]
    ),
    key!(SoftWrap, "soft-wrap", "Toggle soft wrapping", EV, ["f9"]),
    key!(
        PromptSubmit,
        "prompt-submit",
        "Submit active prompt",
        P,
        ["enter"]
    ),
    key!(
        PromptCancel,
        "prompt-cancel",
        "Cancel active prompt",
        P,
        ["esc"]
    ),
    key!(
        PromptDeleteBackward,
        "prompt-delete-backward",
        "Delete prompt character",
        PS,
        ["backspace"]
    ),
    key!(
        SearchNext,
        "search-next",
        "Move to next search match",
        S,
        ["enter", "down"]
    ),
    key!(
        SearchPrevious,
        "search-previous",
        "Move to previous search match",
        S,
        ["up"]
    ),
    key!(
        SearchCancel,
        "search-cancel",
        "Close search and clear highlight",
        S,
        ["esc"]
    ),
    key!(
        CompletionNext,
        "completion-next",
        "Select next completion",
        C,
        ["tab", "ctrl+space"]
    ),
    key!(
        CompletionPrevious,
        "completion-previous",
        "Select previous completion",
        C,
        ["shift+tab"]
    ),
    key!(
        CompletionAccept,
        "completion-accept",
        "Accept completion",
        C,
        ["enter"]
    ),
    key!(
        CompletionCancel,
        "completion-cancel",
        "Dismiss completion",
        C,
        ["esc"]
    ),
    key!(
        PreviewAccept,
        "preview-accept",
        "Accept or apply preview",
        V,
        ["enter"]
    ),
    key!(
        PreviewCancel,
        "preview-cancel",
        "Cancel or close preview",
        V,
        ["esc"]
    ),
    key!(HelpClose, "help-close", "Close shortcut help", H, ["esc"]),
    mouse!(
        MousePlaceCursor,
        "mouse-place-cursor",
        "Place cursor",
        ["mouse-left"]
    ),
    mouse!(
        MouseExtendSelection,
        "mouse-extend-selection",
        "Extend dragged selection",
        ["mouse-left-drag"]
    ),
    mouse!(
        MouseFinishSelection,
        "mouse-finish-selection",
        "Finish dragged selection",
        ["mouse-left-up"]
    ),
    mouse!(
        MouseSelectWord,
        "mouse-select-word",
        "Select double-clicked word",
        ["mouse-left-double"]
    ),
    wheel!(
        MouseScrollUp,
        "mouse-scroll-up",
        "Scroll viewport up",
        "mouse-wheel-up"
    ),
    wheel!(
        MouseScrollDown,
        "mouse-scroll-down",
        "Scroll viewport down",
        "mouse-wheel-down"
    ),
];
