/**
 * Semantic diff driver: identity-keyed schema delta between two deploy
 * surfaces.
 *
 * Where `diffBundles` (in `@pgpmjs/bundle`) compares change names and content
 * digests — which breaks the moment a dial regroups or renames changes — this
 * driver re-keys the comparison on object identity (`identityOf`), so the
 * same schema authored at different granularities or partitions diffs as
 * equal. Objects are compared at the AST level (normalized parse trees, so
 * formatting never matters); tables are compared column-by-column and
 * constraint-by-constraint so an added column emits `ALTER TABLE ADD COLUMN`,
 * not a table rebuild.
 *
 * The emitted delta is a set of pgpm changes: DROPs for removed objects
 * (reverse topological order), then CREATE/ALTER changes for added and
 * modified objects routed through the granularity pipeline
 * (`restructureChanges`), so names come from the naming spec and `requires`
 * from the statement graph — the same derivation every other projection uses.
 * Every emitted change carries a full deploy/revert/verify triple: inverses
 * and existence checks are composed at the AST level via `@pgsql/scripts`'
 * node-level API (`invertStatement`/`existenceCheck`) — never hand-templated
 * and never round-tripped through deparsed text — deparsing only once at the
 * end. Statements the node layer cannot derive fall back to the text layer
 * (`revertFor`/`verifyFor`) solely to surface its not-derivable comment and
 * warning.
 *
 * Requires `loadModule()` from `plpgsql-parser` before use.
 */
import { pathFor, PathStyle } from '@pgpmjs/naming-spec';
import { existenceCheck, invertStatement, revertFor, verifyFor } from '@pgsql/scripts';
import type { StatementFacts } from '@pgsql/semantics';
import { classifyStatements } from '@pgsql/semantics';
import type { ObjectIdentity } from '@pgsql/transform';
import {
  buildStatementGraph,
  cleanTree,
  Granularity,
  identityOf
} from '@pgsql/transform';
import { Deparser, parseSync } from 'plpgsql-parser';

import { ConstraintNode, defaultConstraintName } from './constraint-names';
import { ChangeGranularity, GranularityChange, restructureChanges } from './granularity-driver';

/** How one object differs between the two sides. */
export type ObjectDelta = 'added' | 'removed' | 'modified';

export interface SemanticObjectDiff {
  identity: ObjectIdentity;
  /** Canonical naming-spec path for the object. */
  path: string;
  delta: ObjectDelta;
  /** For modified tables: the column/constraint-level detail. */
  columnsAdded?: string[];
  columnsRemoved?: string[];
  columnsModified?: string[];
}

export interface SemanticDiffOptions {
  /** Granularity for the emitted CREATE/ALTER changes (default `object`). */
  granularity?: Granularity;
  /** Change-level distribution for emitted changes (default `object`). */
  changeGranularity?: ChangeGranularity;
  /** Naming-spec rendering style (default `directory`). */
  style?: PathStyle;
}

/** One emitted delta change: a full deploy/revert/verify triple. */
export interface SemanticDeltaChange extends GranularityChange {
  revert: string;
  verify: string;
}

export interface SemanticDiffResult {
  /** True when both sides describe the same objects with the same shapes. */
  identical: boolean;
  /** Per-object dispositions, in `to`-then-removed order. */
  objects: SemanticObjectDiff[];
  /**
   * The migration delta: DROP changes for removed objects first (reverse
   * topological order), then CREATE/ALTER changes named and ordered by the
   * granularity pipeline.
   */
  changes: SemanticDeltaChange[];
  warnings: string[];
}

const identityKey = (id: ObjectIdentity): string =>
  `${id.kind}\u0000${id.schema ?? ''}\u0000${id.table ?? ''}\u0000${id.name}`;

/** One side's statements for a single object. */
interface ObjectUnit {
  identity: ObjectIdentity;
  /** Statement indexes in source order. */
  statements: number[];
  texts: string[];
}

interface SideProgram {
  facts: StatementFacts[];
  units: Map<string, ObjectUnit>;
  /** identity key list in source order. */
  order: string[];
  graph: ReturnType<typeof buildStatementGraph>;
}

/**
 * Group one side's script into identity-keyed object units. Statements with
 * no identity (grants, comments) attach to the unit of the first object they
 * reference, falling back to the preceding statement's unit; truly homeless
 * statements are reported via `warnings`.
 */
function readSide(sql: string, warnings: string[], label: string): SideProgram {
  const facts = classifyStatements(sql);
  const graph = buildStatementGraph(facts);
  const units = new Map<string, ObjectUnit>();
  const order: string[] = [];
  const unitOf: (string | null)[] = new Array(facts.length).fill(null);
  const byObject = new Map<string, string>();

  facts.forEach((f, i) => {
    const text = sql.slice(f.span.start, f.span.start + f.span.len).trim();
    if (!text) return;

    let identity = groupingIdentity(f);
    if (identity && identity.kind === 'other') {
      const asTable = identityKey({ kind: 'table', schema: identity.schema, name: identity.name });
      if (units.has(asTable)) identity = units.get(asTable)!.identity;
    }
    let key: string | null = null;
    if (identity) {
      key = identityKey(identity);
      if (!units.has(key)) {
        units.set(key, { identity, statements: [], texts: [] });
        order.push(key);
      }
      if (!identity.table) {
        byObject.set(`${identity.schema ?? ''}.${identity.name}`, key);
      }
    } else {
      for (const r of f.references) {
        const host = byObject.get(`${r.schema ?? ''}.${r.name}`);
        if (host) { key = host; break; }
      }
      if (!key && i > 0) key = unitOf[i - 1];
    }

    if (!key) {
      warnings.push(`${label}: statement ${i} (${f.kind}) belongs to no object; ignored in the diff`);
      return;
    }
    unitOf[i] = key;
    const unit = units.get(key)!;
    unit.statements.push(i);
    unit.texts.push(text.endsWith(';') ? text : `${text};`);
  });

  return { facts, units, order, graph };
}

/**
 * The identity a statement groups under. Table-shaping statements — ALTER
 * TABLE column/constraint additions, RLS enablement — fold into their table's
 * unit so that atomic and consolidated authorships of the same table land in
 * the same unit and compare shape-to-shape. Generic ALTERs (`kind: 'other'`)
 * fold in `readSide` when a table unit for the same object already exists.
 */
function groupingIdentity(f: StatementFacts): ObjectIdentity | null {
  const identity = identityOf(f);
  if (!identity) return null;
  if (
    (f.kind === 'table' || f.kind === 'constraint' || f.kind === 'fk_constraint' || f.kind === 'rls_enable') &&
    identity.kind !== 'table'
  ) {
    return { kind: 'table', schema: identity.schema, name: identity.table ?? identity.name };
  }
  return identity;
}

/** Normalized-AST fingerprint of one statement (formatting/position-proof). */
function fingerprint(text: string): string {
  const parsed = parseSync(text);
  return JSON.stringify(cleanTree(parsed.sql.stmts.map(s => s.stmt)));
}

/** Multiset fingerprint of a whole unit. */
const unitFingerprint = (unit: ObjectUnit): string =>
  unit.texts.map(fingerprint).sort().join('\n');

interface TableShape {
  relation: unknown;
  /** column name → normalized ColumnDef. */
  columns: Map<string, { def: unknown; print: string }>;
  /** normalized table-level constraints/extras, keyed by their print. */
  extras: Map<string, unknown>;
}

/** JSON with recursively sorted object keys — an insertion-order-proof fingerprint. */
function stablePrint(node: unknown): string {
  if (Array.isArray(node)) return `[${node.map(stablePrint).join(',')}]`;
  if (node && typeof node === 'object') {
    const entries = Object.entries(node as Record<string, unknown>)
      .filter(([, v]) => v !== undefined)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([k, v]) => `${JSON.stringify(k)}:${stablePrint(v)}`);
    return `{${entries.join(',')}}`;
  }
  return JSON.stringify(node);
}

/** Constraint kinds that can move between column, table-elt, and ALTER form. */
const RELOCATABLE = new Set(['CONSTR_PRIMARY', 'CONSTR_UNIQUE', 'CONSTR_FOREIGN', 'CONSTR_CHECK']);

/**
 * Fold a table unit's statements (CREATE TABLE plus any ALTER TABLE
 * ADD COLUMN / ADD CONSTRAINT) into an effective shape, so atomic and
 * consolidated authorships of the same table compare equal.
 *
 * Constraint placement is representation, not semantics: `id bigint PRIMARY
 * KEY`, a `PRIMARY KEY (id)` table elt, and `ALTER TABLE .. ADD CONSTRAINT
 * t_pkey PRIMARY KEY (id)` all catalog identically. Relocatable constraints
 * (PK/UNIQUE/FK/CHECK) are therefore lifted out of columns and ALTER
 * commands into one canonical table-level set — keyed with the Postgres
 * default name when unnamed, columns filled in from the owning column when
 * column-attached — and PK columns gain the NOT NULL the catalog implies.
 */
function tableShape(unit: ObjectUnit): TableShape {
  const shape: TableShape = { relation: null, columns: new Map(), extras: new Map() };
  const table = unit.identity.name;
  const rawColumns: { colname: string; def: Record<string, unknown> }[] = [];
  const constraints: { node: ConstraintNode & Record<string, unknown>; column?: string }[] = [];
  const pkColumns = new Set<string>();

  const addColumn = (node: Record<string, unknown>): void => {
    const colname = (node as { colname?: string }).colname ?? '';
    const attached = (node.constraints as { Constraint?: Record<string, unknown> }[] | undefined) ?? [];
    const residual: unknown[] = [];
    for (const item of attached) {
      const c = item.Constraint as (ConstraintNode & Record<string, unknown>) | undefined;
      if (c && RELOCATABLE.has(c.contype ?? '')) {
        constraints.push({ node: c, column: colname });
      } else {
        residual.push(item);
      }
    }
    rawColumns.push({ colname, def: { ...node, constraints: residual } });
  };
  const addConstraint = (node: Record<string, unknown>, column?: string): void => {
    constraints.push({ node: node as ConstraintNode & Record<string, unknown>, column });
  };
  const addExtra = (node: unknown): void => {
    const clean = cleanTree(node);
    shape.extras.set(stablePrint(clean), clean);
  };

  for (const text of unit.texts) {
    for (const raw of parseSync(text).sql.stmts) {
      const stmt = raw.stmt as unknown as Record<string, Record<string, unknown>>;
      if (stmt.CreateStmt) {
        shape.relation = stmt.CreateStmt.relation;
        const elts = (stmt.CreateStmt.tableElts as Record<string, unknown>[] | undefined) ?? [];
        for (const elt of elts) {
          if (elt.ColumnDef) addColumn(elt.ColumnDef as Record<string, unknown>);
          else if (elt.Constraint && RELOCATABLE.has((elt.Constraint as ConstraintNode).contype ?? '')) {
            addConstraint(elt.Constraint as Record<string, unknown>);
          } else addExtra(elt);
        }
      } else if (stmt.AlterTableStmt) {
        shape.relation ??= stmt.AlterTableStmt.relation;
        const cmds = (stmt.AlterTableStmt.cmds as { AlterTableCmd?: Record<string, unknown> }[] | undefined) ?? [];
        for (const cmd of cmds) {
          const at = cmd.AlterTableCmd;
          if (!at) continue;
          const def = at.def as Record<string, unknown> | undefined;
          if (at.subtype === 'AT_AddColumn' && def?.ColumnDef) {
            addColumn(def.ColumnDef as Record<string, unknown>);
          } else if (
            at.subtype === 'AT_AddConstraint' &&
            def?.Constraint &&
            RELOCATABLE.has((def.Constraint as ConstraintNode).contype ?? '')
          ) {
            addConstraint(def.Constraint as Record<string, unknown>);
          } else {
            addExtra({ AlterTableCmd: at });
          }
        }
      } else {
        addExtra(stmt);
      }
    }
  }

  for (const { node, column } of constraints) {
    const canonical: Record<string, unknown> = { ...node };
    canonical.conname = node.conname ?? defaultConstraintName(table, node, column) ?? undefined;
    if (column && (node.keys ?? []).length === 0 && node.contype !== 'CONSTR_FOREIGN' && node.contype !== 'CONSTR_CHECK') {
      canonical.keys = [{ String: { sval: column } }];
    }
    if (column && node.contype === 'CONSTR_FOREIGN' && (node.fk_attrs ?? []).length === 0) {
      canonical.fk_attrs = [{ String: { sval: column } }];
    }
    if (node.contype === 'CONSTR_PRIMARY') {
      const keyed = (canonical.keys as { String?: { sval?: string } }[] | undefined) ?? [];
      for (const k of keyed) if (k.String?.sval) pkColumns.add(k.String.sval);
    }
    addExtra({ Constraint: canonical });
  }

  for (const { colname, def } of rawColumns) {
    const residual = ((def.constraints as unknown[] | undefined) ?? []).map(c => {
      const constraint = (c as { Constraint?: ConstraintNode & { conname?: string } }).Constraint;
      // NOT NULL parses with parser-version-dependent extras (is_enforced,
      // initially_valid); reduce to its semantic core so an authored NOT NULL
      // equals the one a primary key implies.
      if (constraint?.contype === 'CONSTR_NOTNULL') {
        return { Constraint: { contype: 'CONSTR_NOTNULL', conname: constraint.conname } };
      }
      return c;
    });
    const hasNotNull = residual.some(
      c => (c as { Constraint?: ConstraintNode }).Constraint?.contype === 'CONSTR_NOTNULL'
    );
    if (pkColumns.has(colname) && !hasNotNull) {
      residual.push({ Constraint: { contype: 'CONSTR_NOTNULL' } });
    }
    const sorted = residual
      .map(c => cleanTree(c))
      .sort((x, y) => stablePrint(x).localeCompare(stablePrint(y)));
    const clean = cleanTree({ ...def, constraints: sorted });
    shape.columns.set(colname, { def: clean, print: stablePrint(clean) });
  }
  return shape;
}

const deparseStmt = (node: Record<string, unknown>): string =>
  `${Deparser.deparse(node, { pretty: false })};`;

/** Column-level ALTERs between two table shapes. */
function diffTable(
  from: TableShape,
  to: TableShape,
  diff: SemanticObjectDiff,
  warnings: string[]
): string[] {
  const stmts: string[] = [];
  const relation = to.relation ?? from.relation;
  const alter = (cmd: Record<string, unknown>): string =>
    deparseStmt({
      AlterTableStmt: {
        relation,
        cmds: [{ AlterTableCmd: { behavior: 'DROP_RESTRICT', ...cmd } }],
        objtype: 'OBJECT_TABLE'
      }
    });

  diff.columnsAdded = [];
  diff.columnsRemoved = [];
  diff.columnsModified = [];

  for (const [name, col] of to.columns) {
    const prior = from.columns.get(name);
    if (!prior) {
      diff.columnsAdded.push(name);
      stmts.push(alter({ subtype: 'AT_AddColumn', def: { ColumnDef: col.def } }));
    } else if (prior.print !== col.print) {
      diff.columnsModified.push(name);
      const fromDef = prior.def as { typeName?: unknown; constraints?: unknown };
      const toDef = col.def as { typeName?: unknown; constraints?: unknown };
      const typeChanged = JSON.stringify(fromDef.typeName) !== JSON.stringify(toDef.typeName);
      const restChanged =
        JSON.stringify({ ...(fromDef as object), typeName: null }) !==
        JSON.stringify({ ...(toDef as object), typeName: null });
      if (typeChanged) {
        stmts.push(alter({
          subtype: 'AT_AlterColumnType',
          name,
          def: { ColumnDef: { typeName: toDef.typeName } }
        }));
      }
      if (restChanged) {
        warnings.push(
          `${diff.path}: column "${name}" changed beyond its type (constraints/defaults); emit a manual ALTER`
        );
      }
    }
  }
  for (const name of from.columns.keys()) {
    if (!to.columns.has(name)) {
      diff.columnsRemoved.push(name);
      stmts.push(alter({ subtype: 'AT_DropColumn', name }));
    }
  }

  // Self-inverse ALTER TABLE subtypes: a removed extra with one of these
  // undoes with the paired subtype rather than a DROP CONSTRAINT.
  const INVERSE_SUBTYPE: Record<string, string> = {
    AT_EnableRowSecurity: 'AT_DisableRowSecurity',
    AT_DisableRowSecurity: 'AT_EnableRowSecurity',
    AT_ForceRowSecurity: 'AT_NoForceRowSecurity',
    AT_NoForceRowSecurity: 'AT_ForceRowSecurity'
  };

  // Removed extras drop before added ones: a changed constraint that keeps
  // its name must DROP CONSTRAINT before the replacement ADD CONSTRAINT.
  for (const [print, extra] of from.extras) {
    if (to.extras.has(print)) continue;
    const conname = (extra as { Constraint?: { conname?: string } }).Constraint?.conname
      ?? (extra as { AlterTableCmd?: { def?: { Constraint?: { conname?: string } } } })
        .AlterTableCmd?.def?.Constraint?.conname;
    const subtype = (extra as { AlterTableCmd?: { subtype?: string } }).AlterTableCmd?.subtype;
    if (conname) {
      stmts.push(alter({ subtype: 'AT_DropConstraint', name: conname }));
    } else if (subtype && INVERSE_SUBTYPE[subtype]) {
      stmts.push(alter({ subtype: INVERSE_SUBTYPE[subtype] }));
    } else {
      warnings.push(`${diff.path}: removed table element has no name to drop; emit a manual ALTER`);
    }
  }
  for (const [print, extra] of to.extras) {
    if (!from.extras.has(print)) {
      const at = (extra as Record<string, Record<string, unknown>>).AlterTableCmd;
      if (at) stmts.push(alter(at));
      else if ((extra as Record<string, unknown>).Constraint) {
        stmts.push(alter({ subtype: 'AT_AddConstraint', def: extra }));
      } else {
        warnings.push(`${diff.path}: unrecognized added table element; emit a manual ALTER`);
      }
    }
  }
  return stmts;
}

/**
 * Diff two deploy surfaces by object identity and emit the migration delta.
 *
 * `from`/`to` are whole deploy scripts (flatten changes in plan order to
 * diff bundles/modules). The result's `changes` deploy `to`'s shape on top
 * of `from`: reverse-topological DROPs, then CREATE/ALTERs named and
 * ordered by `restructureChanges`.
 */
export function diffSchemas(
  from: string,
  to: string,
  options: SemanticDiffOptions = {}
): SemanticDiffResult {
  const style = options.style ?? 'directory';
  const warnings: string[] = [];
  const a = readSide(from, warnings, 'from');
  const b = readSide(to, warnings, 'to');

  const objects: SemanticObjectDiff[] = [];
  const forwardSql: string[] = [];
  const modifiedChanges: SemanticDeltaChange[] = [];
  const dropUnits: ObjectUnit[] = [];

  /**
   * `@pgsql/scripts` inverse of a deploy script (drops in reverse topo
   * order), composed at the AST level via `invertStatement` and deparsed
   * once. Underivable statements fall back to `revertFor` on the single
   * statement to surface its not-derivable comment and warning.
   */
  const inverseOf = (deploy: string, context: string): string => {
    const facts = classifyStatements(deploy);
    const graph = buildStatementGraph(facts);
    const pieces: string[] = [];
    for (const i of [...graph.order].reverse()) {
      const nodes = invertStatement(facts[i]);
      if (nodes === null) {
        const { sql, warnings: w } = revertFor([facts[i]]);
        warnings.push(...w.map(x => `${context}: ${x}`));
        if (sql.trim()) pieces.push(sql);
        continue;
      }
      pieces.push(...nodes.map(n => deparseStmt(n as Record<string, unknown>)));
    }
    return pieces.join('\n');
  };
  /**
   * `@pgsql/scripts` existence checks for a deploy script, composed from
   * `existenceCheck`'s SelectStmt nodes and deparsed once. Underivable
   * statements fall back to `verifyFor` to surface the warning.
   */
  const verifyOf = (deploy: string, context: string): string => {
    const pieces: string[] = [];
    for (const fact of classifyStatements(deploy)) {
      const nodes = existenceCheck(fact);
      if (nodes === null) {
        const { warnings: w } = verifyFor([fact]);
        warnings.push(...w.map(x => `${context}: ${x}`));
        continue;
      }
      pieces.push(...nodes.map(n => deparseStmt(n as Record<string, unknown>)));
    }
    return pieces.join('\n\n');
  };

  for (const key of b.order) {
    const unit = b.units.get(key)!;
    const prior = a.units.get(key);
    const path = pathFor(unit.identity, { style });
    if (!prior) {
      objects.push({ identity: unit.identity, path, delta: 'added' });
      forwardSql.push(...unit.texts);
      continue;
    }
    if (unit.identity.kind === 'table') {
      const shapeFrom = tableShape(prior);
      const shapeTo = tableShape(unit);
      const diff: SemanticObjectDiff = { identity: unit.identity, path, delta: 'modified' };
      const stmts = diffTable(shapeFrom, shapeTo, diff, warnings);
      const columnsTouched =
        diff.columnsAdded!.length + diff.columnsRemoved!.length + diff.columnsModified!.length > 0;
      if (stmts.length > 0 || columnsTouched) {
        objects.push(diff);
        if (stmts.length > 0) {
          // The inverse alteration is the same diff with the sides swapped.
          const scratch: SemanticObjectDiff = { identity: unit.identity, path, delta: 'modified' };
          const deploy = stmts.join('\n');
          modifiedChanges.push({
            name: `${path}/alter`,
            dependencies: [],
            deploy,
            revert: diffTable(shapeTo, shapeFrom, scratch, []).join('\n'),
            verify: verifyOf(deploy, path)
          });
        }
      }
      continue;
    }
    if (unitFingerprint(prior) !== unitFingerprint(unit)) {
      objects.push({ identity: unit.identity, path, delta: 'modified' });
      const priorDeploy = prior.texts.join('\n');
      const newDeploy = unit.texts.join('\n');
      modifiedChanges.push({
        name: path,
        dependencies: [],
        deploy: [inverseOf(priorDeploy, path), newDeploy].filter(Boolean).join('\n'),
        revert: [inverseOf(newDeploy, path), priorDeploy].filter(Boolean).join('\n'),
        verify: verifyOf(newDeploy, path)
      });
    }
  }

  for (const key of a.order) {
    if (b.units.has(key)) continue;
    const unit = a.units.get(key)!;
    objects.push({ identity: unit.identity, path: pathFor(unit.identity, { style }), delta: 'removed' });
    dropUnits.push(unit);
  }

  // Removed objects drop in reverse topological order of the `from` graph
  // (dependents before dependencies), one change per object.
  const position = new Map(dropUnits.map(u => [u, Math.min(...u.statements.map(s => a.graph.order.indexOf(s)))]));
  dropUnits.sort((x, y) => position.get(y)! - position.get(x)!);
  const dropChanges: SemanticDeltaChange[] = [];
  for (const unit of dropUnits) {
    const path = pathFor(unit.identity, { style });
    const recreate = unit.texts.join('\n');
    const drop = inverseOf(recreate, path);
    if (!drop.trim() || drop.trim().startsWith('--')) {
      warnings.push(`${path}: no DROP derivable for kind "${unit.identity.kind}"; drop manually`);
      continue;
    }
    dropChanges.push({
      name: `${path}/drop`,
      dependencies: dropChanges.length > 0 ? [dropChanges[dropChanges.length - 1].name] : [],
      deploy: drop,
      revert: recreate,
      verify: ''
    });
  }

  let forwardChanges: SemanticDeltaChange[] = [];
  if (forwardSql.length > 0) {
    const { changes, warnings: w } = restructureChanges(
      [{ name: 'delta', dependencies: [], deploy: forwardSql.join('\n\n') }],
      {
        granularity: options.granularity ?? 'object',
        changeGranularity: options.changeGranularity,
        subObjectName: identity => pathFor(identity, { style })
      }
    );
    forwardChanges = changes.map(c => ({
      ...c,
      revert: inverseOf(c.deploy, c.name),
      verify: verifyOf(c.deploy, c.name)
    }));
    warnings.push(...w);
  }

  return {
    identical: objects.length === 0,
    objects,
    changes: [...dropChanges, ...forwardChanges, ...modifiedChanges],
    warnings
  };
}

/** A change's deploy surface (same seam as the other drivers). */
export interface DiffInputChange {
  name: string;
  dependencies: string[];
  deploy: string;
}

/**
 * Identity-keyed diff over pgpm changes: flattens each side's deploy scripts
 * in plan order and delegates to {@link diffSchemas}. Change names never
 * enter the comparison — regrouping, renaming, or repartitioning the same
 * schema yields an identical diff.
 */
export function diffChangeSets(
  from: DiffInputChange[],
  to: DiffInputChange[],
  options: SemanticDiffOptions = {}
): SemanticDiffResult {
  const flatten = (changes: DiffInputChange[]): string =>
    changes.map(c => c.deploy.trim()).filter(Boolean).join('\n\n');
  return diffSchemas(flatten(from), flatten(to), options);
}

/** How one object a change touches relates to the diff's delta. */
export type ChangeObjectDelta = ObjectDelta | 'unchanged';

/**
 * Whether a `to`-side change is already satisfied by the `from` side:
 * - `satisfied`: every object it touches is unchanged in the diff
 * - `unsatisfied`: every object it touches is added/modified in the diff
 * - `partial`: a mix of unchanged and delta objects
 * - `inert`: no identifiable objects (seed data, grants-only, dynamic SQL)
 */
export type ChangeSatisfaction = 'satisfied' | 'unsatisfied' | 'partial' | 'inert';

export interface ChangeObjectCoverage {
  /** Canonical naming-spec path for the object. */
  path: string;
  delta: ChangeObjectDelta;
}

export interface ChangeCoverage {
  /** The input change's name (as given, e.g. `pkg:change`). */
  name: string;
  status: ChangeSatisfaction;
  objects: ChangeObjectCoverage[];
}

/**
 * Cover each `to`-side change against a semantic diff's per-object delta:
 * which of the objects the change touches are already present and identical
 * on the `from` side. A `satisfied` change deploys nothing new — its ledger
 * entry can be backfilled instead of executing it; an `unsatisfied` change is
 * the genuine delta. Identity keying is shared with the diff itself, so
 * regrouped/renamed/reordered authorship of the same objects covers the same.
 *
 * `diff` must come from diffing the same `from` side against these changes
 * (`diffChangeSets(fromChanges, toChanges)`).
 */
export function coverChanges(
  changes: DiffInputChange[],
  diff: SemanticDiffResult,
  options: { style?: PathStyle } = {}
): ChangeCoverage[] {
  const style = options.style ?? 'directory';
  const deltaByKey = new Map<string, ObjectDelta>();
  for (const obj of diff.objects) {
    deltaByKey.set(identityKey(obj.identity), obj.delta);
  }
  return changes.map(change => {
    const sideWarnings: string[] = [];
    const side = readSide(change.deploy, sideWarnings, change.name);
    const objects: ChangeObjectCoverage[] = side.order.map(key => {
      const unit = side.units.get(key)!;
      return {
        path: pathFor(unit.identity, { style }),
        delta: deltaByKey.get(key) ?? 'unchanged'
      };
    });
    const touched = objects.filter(o => o.delta !== 'unchanged').length;
    const status: ChangeSatisfaction =
      objects.length === 0 ? 'inert'
        : touched === 0 ? 'satisfied'
          : touched === objects.length ? 'unsatisfied'
            : 'partial';
    return { name: change.name, status, objects };
  });
}
