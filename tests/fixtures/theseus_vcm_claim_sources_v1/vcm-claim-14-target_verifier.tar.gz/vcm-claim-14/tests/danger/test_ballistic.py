"""Tests for ballistic danger detection."""

# ruff: noqa: S101

from custom_components.aerial_danger.danger import DangerDetector, DangerType

from .common import LOCALITY_PATTERNS, REGION_PATTERNS

ZIRCON_CASES: list[str] = [
    "🔴Пуск ракети «Циркон»!",
    "🔴 Пуск ракети «Циркон»!",
    "🔴Пуск Циркону!",
    "🔴 Пуск Циркону!",
    "ЦИРКОН",
    "ЦИРКОН Є",
    "ЩЕ ЦИРКОН",
    "І ЩЕ ЦИРКОН",
    "2 ЦИРКОНИ!",
    "Вихід Циркона Курщина!",
    "Циркон з Криму! У наш бік!",
    "🔴Циркон з Криму.",
    "🔴 Циркон з Криму.",
    "Циркони заходять в область!",
    "🔴Циркон Київ!",
    "❗️ 1х Циркон на Київ з Курська",
    "❗️ 2х Циркони у напрямку Києва",
    "Загальна ситуація:\nКР Циркон у напрямку Києва.",
    "❗️ Київ 1х Циркон на місто",
    "Циркони над Києвом!!",
    "🚀 Вихід Циркону у бік Києва!",
    "❗️З Курська тоже Циркони до нас!",
    "🚀 Також є циркон. Сумарно до 4 ракет на Київ!",
    "2-3 Циркона на Київ.",
    "Циркони з Криму на Київ!",
    "Бляяяя, Циркон на Київ!!!",
    "❗️ 1х Циркон повз Ніжин на Київ",
    "❗️ Вихід йм. КР Циркон у напрямку Київщини.",
    "Циркон з півдня попередньо.",
    "Циркон з півночі попередньо.",
    "Ще з Курська Циркон!",
    "Ще з Курщини на Циркон!",
    "Циркон над Херсоном попередньо!",
    "Троя, два Циркона!",
    "БЦ увага по Цирконам.",
    "БРОВАРИ ЦИРКОН!",
    "Бровари увага Циркон.",
    "Циркон на Сумщині!",
]

COMET_BALLISTIC_CASES: list[str] = [
    "☄Київ Балістика!",
    "☄ Київ!",
    "☄️ Київ!",
    "☄ Повторні на Київ",
    "☄️ Повторні на Київ",
]

BALLISTIC_CASES: list[str] = [
    "Київ швидкісна!",
    "Київ спуск! Одна за другою!",
    "❗️ Балістика у напрямку Києва",
    "❗️Повторний вихід з Брянська у напрямку Києва",
    "❗️Повторний вихід з Курська у напрямку Києва",
    "🔴🚀 «Кинджал» Київ!",
    *COMET_BALLISTIC_CASES,
    "КИЇВ ШВИДКІСНА",
    "🚀Швидкісна ціль на Київ!",
    "Ще балістика на Київ!",
    "‼️ Київ — спуск балістики!",
    "🚀 Київ! Балістика!",
    "🚀 Київ! Ще балістика!",
    "🚀 Київ, балістика!",
    "❗️ Кинджал вектор Київ/агломерація",
    "🚀 Київ! Кинджал!",
    "КИЇВ КИНДЖАЛ",
    "🚀 Швидкісна у бік Києва!",
    "‼️Київ — спуск Кинджалу!",
    "Кинджал у бік Києва/Житомира.",
    "🚀 Повторні запуски балістики у бік Києва!",
    "Балістика ➡️ на Київ!",
    "🔴❗️ Ще балістика на Київ!",
    "Швидкісна ціль ➡️ на Київ!",
    "🔴❗️ Ще 2х балістики на Київ!",
    "☄ Виходи на Київ БР",
    "☄ Вихід на Київ",
    "‼️Київ — спуск балістики!",
    "‼️Київ — спуск балістики! Друга",
    "🚀 Дві балістики на Київ!",
    "Спуск на Київ.",
    "Спуск балістики на Київ!",
    "🚀4 балістичні ракети на Київ!",
    "Ще 2 балістики підлітають до Києва.",
    "Балістика з Брянська на Київ.",
    "🔴❗️ 3х балістики на Київ!",
    "🔴❗️ + ще 1х балістика на Київ!",
    "‼️ Київ— спуск балістики!",
    "☄ Вихід БР на Київ",
    "🚀Балістичні ракети через Чернігівщину у напрямку Києва",
    "🚀 Швидкісна ціль на Київщині у напрямку Кагарлика",
    "🚀 Балістика з Брянська!",
    "🟡 3х швидкісні повітряні цілі на Чорноморськ!",
    "🔴🚛Ракета Київ!",
]


def test_ballistic_only() -> None:
    """Ballistic-specific helper should flag ballistic samples."""
    detector = DangerDetector(REGION_PATTERNS, LOCALITY_PATTERNS)
    for text in BALLISTIC_CASES:
        detection = detector.ballistic_danger(text)
        assert detection.danger is True, text
        assert detection.type == DangerType.BALLISTIC, text
        assert detector.danger(text).type == DangerType.BALLISTIC, text


def test_comet_messages_do_not_match_generic() -> None:
    """Comet-marked messages should be reserved for ballistic danger."""
    detector = DangerDetector(REGION_PATTERNS, LOCALITY_PATTERNS)
    for text in COMET_BALLISTIC_CASES:
        detection = detector.generic_danger(text)

        assert detection.danger is False, text
        assert detection.type is None, text


def test_zircon_is_ballistic() -> None:
    """Shared Zircon keywords should match ballistic detection."""
    detector = DangerDetector([r".*"], [])
    for text in ZIRCON_CASES:
        ballistic = detector.ballistic_danger(text)
        assert ballistic.danger is True, text
        assert ballistic.type == DangerType.BALLISTIC, text
        assert detector.danger(text).type == DangerType.BALLISTIC, text
