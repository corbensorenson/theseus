"""Platform-independent scanning, copying, and configuration logic."""

from __future__ import annotations

import hashlib
import json
import locale
import logging
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Iterable, Optional
from uuid import uuid4

from series_collector.trash import move_to_trash


VIDEO_EXTENSIONS = {".avi", ".mkv", ".mp4"}
SUBTITLE_EXTENSIONS = {".srt", ".ass", ".ssa", ".vtt", ".sub"}
SUPPORTED_EXTENSIONS = VIDEO_EXTENSIONS | SUBTITLE_EXTENSIONS
OPERATIONS = {"copy", "move"}
MANIFEST_NAME = ".serien-sammler-manifest.json"
MANIFEST_VERSION = 2
CONFIG_PATH = Path.home() / ".serien-sammler-config.json"
FINGERPRINT_SAMPLE_SIZE = 1024 * 1024
logger = logging.getLogger("series_collector")


class CollectorError(Exception):
    def __init__(self, code: str, **details: str) -> None:
        super().__init__(code)
        self.code = code
        self.details = details


@dataclass(frozen=True)
class FileFingerprint:
    size: int
    sample_sha256: str

    @property
    def key(self) -> str:
        return f"{self.size}:{self.sample_sha256}"


@dataclass(frozen=True)
class ScanItem:
    source: Path
    kind: str
    existing_destination: Optional[Path]
    fingerprint: FileFingerprint
    match_quality: str
    planned_destination: Path
    season: Optional[int]
    selected: bool = True
    duplicate_in_scan: bool = False

    @property
    def is_existing(self) -> bool:
        return self.existing_destination is not None

    @property
    def is_duplicate(self) -> bool:
        return self.is_existing or self.duplicate_in_scan

    @property
    def needs_move(self) -> bool:
        return bool(
            self.season is not None
            and self.existing_destination
            and self.existing_destination.parent != self.planned_destination.parent
        )

    @property
    def requires_change(self) -> bool:
        return self.needs_move or not self.is_duplicate

    @property
    def season_label(self) -> str:
        return f"S{self.season:02d}" if self.season is not None else "—"

    @property
    def destination_action(self) -> str:
        if self.needs_move:
            return "action_move"
        if self.is_duplicate:
            return "action_duplicate"
        return "action_rename" if self.planned_destination.name != self.source.name else "action_copy"


@dataclass(frozen=True)
class ScanResult:
    series_name: str
    source: Path
    destination: Path
    target: Path
    items: tuple[ScanItem, ...]
    operation: str = "copy"

    @property
    def video_count(self) -> int:
        return sum(item.kind == "video" for item in self.items)

    @property
    def subtitle_count(self) -> int:
        return sum(item.kind == "subtitle" for item in self.items)

    @property
    def new_count(self) -> int:
        return sum(not item.is_duplicate for item in self.items)

    @property
    def selected_new_count(self) -> int:
        return sum(item.selected and not item.is_duplicate for item in self.items)

    @property
    def move_count(self) -> int:
        return sum(item.needs_move for item in self.items)

    @property
    def existing_count(self) -> int:
        return sum(item.is_duplicate and not item.needs_move for item in self.items)

    @property
    def ambiguous_count(self) -> int:
        return sum(item.match_quality == "ambiguous" for item in self.items)

    def with_selection(self, selected_sources: Iterable[Path]) -> "ScanResult":
        selected = {str(path) for path in selected_sources}
        return replace(
            self,
            items=tuple(
                replace(
                    item,
                    selected=str(item.source) in selected
                    and (item.requires_change or self.operation == "move"),
                )
                for item in self.items
            ),
        )


@dataclass(frozen=True)
class CopyProgress:
    processed: int
    total: int
    current_file: str
    action: str
    copied: int
    moved: int
    source_removed: int
    source_folders_removed: int
    skipped: int
    failed: int
    error: str = ""


@dataclass(frozen=True)
class CopySummary:
    target: Path
    total: int
    processed: int
    copied: int
    moved: int
    source_removed: int
    source_folders_removed: int
    skipped: int
    failed: int
    cancelled: bool
    errors: tuple[str, ...]


def folder_name(name: str) -> str:
    return re.sub(r"[/:\\\x00]", " ", name).strip(" .")


def normalise_for_search(text: str) -> str:
    return "".join(character for character in text.casefold() if character.isalnum())


def detect_season(filename: str) -> Optional[int]:
    """Return a season number from common German and international episode names."""
    stem = Path(filename).stem
    patterns = (
        r"(?i)s0*(\d{1,3})(?=e\d|[^0-9]|$)",
        r"(?i)staffel[\s._-]*0*(\d{1,3})(?=[^0-9]|$)",
        r"(?i)season[\s._-]*0*(\d{1,3})(?=[^0-9]|$)",
        r"(?i)(?:^|[^0-9])(\d{1,3})x\d{1,4}(?=[^0-9]|$)",
    )
    for pattern in patterns:
        match = re.search(pattern, stem)
        if match:
            return int(match.group(1))
    return None


def default_language() -> str:
    language = locale.getlocale()[0] or ""
    return "de" if language.casefold().startswith("de") else "en"


def normalise_language(language: Optional[str]) -> str:
    return language if language in {"de", "en"} else default_language()


def free_name(folder: Path, name: str, reserved: Optional[set[str]] = None) -> Path:
    reserved = reserved or set()
    candidate = folder / name
    if not candidate.exists() and candidate.name.casefold() not in reserved:
        return candidate

    stem, suffix = candidate.stem, candidate.suffix
    number = 2
    while True:
        candidate = folder / f"{stem} ({number}){suffix}"
        if not candidate.exists() and candidate.name.casefold() not in reserved:
            return candidate
        number += 1


def fast_fingerprint(file: Path, sample_size: int = FINGERPRINT_SAMPLE_SIZE) -> FileFingerprint:
    """Hash a small file fully, or the beginning/middle/end of a large file."""
    size = file.stat().st_size
    digest = hashlib.sha256()
    digest.update(size.to_bytes(16, "big"))
    with file.open("rb") as stream:
        if size <= sample_size * 3:
            while chunk := stream.read(1024 * 1024):
                digest.update(chunk)
        else:
            positions = (0, max((size - sample_size) // 2, 0), max(size - sample_size, 0))
            for position in positions:
                stream.seek(position)
                digest.update(position.to_bytes(16, "big"))
                digest.update(stream.read(sample_size))
    return FileFingerprint(size=size, sample_sha256=digest.hexdigest())


def fingerprint_key(file: Path, fingerprint: FileFingerprint) -> str:
    """Keep byte-identical files with different media formats distinct."""
    return f"{file.suffix.casefold()}:{fingerprint.key}"


def source_signature(file: Path) -> dict[str, int | str]:
    """Legacy-compatible source metadata used in manifest source history."""
    stats = file.stat()
    return {"source": str(file.resolve()), "size": stats.st_size, "modified": stats.st_mtime_ns}


def _empty_manifest() -> dict[str, object]:
    return {"schema_version": MANIFEST_VERSION, "files": {}}


def load_manifest(folder: Path) -> dict[str, object]:
    manifest_path = folder / MANIFEST_NAME
    try:
        with manifest_path.open(encoding="utf-8") as manifest_file:
            data = json.load(manifest_file)
    except FileNotFoundError:
        return _empty_manifest()
    except (OSError, json.JSONDecodeError) as error:
        logger.warning("Could not read manifest %s: %s", manifest_path, error)
        return {**_empty_manifest(), "_corrupt": True}

    files = data.get("files", {}) if isinstance(data, dict) else {}
    if not isinstance(files, dict):
        files = {}
    if data.get("schema_version") == MANIFEST_VERSION:
        return {"schema_version": MANIFEST_VERSION, "files": files}
    return {"schema_version": 1, "legacy_files": files, "files": {}}


def _backup_corrupt_manifest(folder: Path, manifest: dict[str, object]) -> None:
    if not manifest.get("_corrupt"):
        return
    manifest_path = folder / MANIFEST_NAME
    if not manifest_path.exists():
        return
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = folder / f"{MANIFEST_NAME}.corrupt-{timestamp}"
    try:
        manifest_path.replace(backup)
        logger.warning("Backed up corrupt manifest to %s", backup)
    except OSError as error:
        logger.warning("Could not back up corrupt manifest %s: %s", manifest_path, error)


def save_manifest(folder: Path, manifest: dict[str, object]) -> None:
    folder.mkdir(parents=True, exist_ok=True)
    manifest_path = folder / MANIFEST_NAME
    temporary_path = folder / f"{MANIFEST_NAME}.tmp"
    payload = {"schema_version": MANIFEST_VERSION, "files": manifest.get("files", {})}
    with temporary_path.open("w", encoding="utf-8") as manifest_file:
        json.dump(payload, manifest_file, ensure_ascii=False, indent=2)
    temporary_path.replace(manifest_path)


def load_config(config_path: Path = CONFIG_PATH) -> dict[str, object]:
    try:
        with config_path.open(encoding="utf-8") as config_file:
            data = json.load(config_file)
    except (OSError, json.JSONDecodeError):
        return {}

    config: dict[str, object] = {}
    for key in ("source", "destination", "last_update_check"):
        if isinstance(data.get(key), str):
            config[key] = data[key]
    if data.get("language") in {"de", "en"}:
        config["language"] = data["language"]
    if isinstance(data.get("check_updates"), bool):
        config["check_updates"] = data["check_updates"]
    return config


def save_config(
    source: Optional[Path] = None,
    destination: Optional[Path] = None,
    language: Optional[str] = None,
    check_updates: Optional[bool] = None,
    last_update_check: Optional[str] = None,
    config_path: Path = CONFIG_PATH,
) -> None:
    config = load_config(config_path)
    if source is not None:
        config["source"] = str(source.resolve())
    if destination is not None:
        config["destination"] = str(destination.resolve())
    if language in {"de", "en"}:
        config["language"] = language
    if check_updates is not None:
        config["check_updates"] = check_updates
    if last_update_check is not None:
        config["last_update_check"] = last_update_check

    config_path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = config_path.with_suffix(f"{config_path.suffix}.tmp")
    with temporary_path.open("w", encoding="utf-8") as config_file:
        json.dump(config, config_file, ensure_ascii=False, indent=2)
    temporary_path.replace(config_path)


def classify_match(filename: str, keyword: str) -> Optional[str]:
    candidate = Path(filename)
    search_text = candidate.stem if candidate.suffix.casefold() in SUPPORTED_EXTENSIONS else filename
    compact_name = normalise_for_search(search_text)
    compact_keyword = normalise_for_search(keyword)
    if not compact_keyword or compact_keyword not in compact_name:
        return None
    start = compact_name.find(compact_keyword)
    remainder = compact_name[start + len(compact_keyword) :]
    if not remainder:
        return "exact"
    if re.match(r"^(?:s\d{1,3}(?:e\d{1,4})?|e\d{1,4}|season\d|staffel\d|\d{3,4}p|\d{4}(?:\D|$))", remainder):
        return "exact"

    separated_name = re.sub(r"[^\w]+", " ", search_text.casefold(), flags=re.UNICODE).strip()
    separated_keyword = re.sub(r"[^\w]+", " ", keyword.casefold(), flags=re.UNICODE).strip()
    if separated_keyword and re.search(rf"(?<!\w){re.escape(separated_keyword)}(?!\w)", separated_name):
        return "likely"
    return "ambiguous"


def classify_path_match(path: Path, keyword: str, source: Path) -> Optional[str]:
    """Classify a file using both its filename and its folders below the source."""
    candidates = [path.name]
    try:
        candidates.extend(reversed(path.parent.relative_to(source).parts))
    except ValueError:
        pass

    qualities = {
        quality
        for candidate in candidates
        if (quality := classify_match(candidate, keyword)) is not None
    }
    for quality in ("exact", "likely", "ambiguous"):
        if quality in qualities:
            return quality
    return None


def matching_files(source: Path, keyword: str) -> list[Path]:
    return sorted(
        path
        for path in source.rglob("*")
        if path.is_file()
        and not path.name.startswith("._")
        and "sample" not in path.name.casefold()
        and path.suffix.casefold() in SUPPORTED_EXTENSIONS
        and classify_path_match(path, keyword, source) is not None
    )


def target_is_inside_source(source: Path, target: Path) -> bool:
    try:
        target.resolve().relative_to(source.resolve())
        return True
    except ValueError:
        return False


def _target_index(target: Path) -> dict[str, Path]:
    index: dict[str, Path] = {}
    if not target.is_dir():
        return index
    for path in sorted(target.rglob("*")):
        if not path.is_file() or path.name.startswith(".") or path.suffix.casefold() not in SUPPORTED_EXTENSIONS:
            continue
        try:
            fingerprint = fast_fingerprint(path)
            index.setdefault(fingerprint_key(path, fingerprint), path)
        except OSError as error:
            logger.warning("Could not fingerprint destination %s: %s", path, error)
    return index


def scan_series(
    name_input: str, source: Path, destination: Path, operation: str = "copy"
) -> ScanResult:
    if operation not in OPERATIONS:
        raise CollectorError("invalid_operation", operation=operation)
    series_name = folder_name(name_input)
    if not series_name:
        raise CollectorError("series_required")
    if not source.is_dir():
        raise CollectorError("source_missing", path=str(source))

    target = destination / series_name
    if target_is_inside_source(source, target):
        raise CollectorError("destination_inside_source")
    if target_is_inside_source(target, source):
        raise CollectorError("source_inside_destination")

    target_index = _target_index(target)
    planned_fingerprints: dict[str, Path] = {}
    reserved_by_folder: dict[Path, set[str]] = {}

    def reserved_names(folder: Path) -> set[str]:
        if folder not in reserved_by_folder:
            reserved_by_folder[folder] = (
                {path.name.casefold() for path in folder.iterdir()} if folder.is_dir() else set()
            )
        return reserved_by_folder[folder]

    items: list[ScanItem] = []
    for file in matching_files(source, series_name):
        season = detect_season(file.name)
        season_folder = target / f"S{season:02d}" if season is not None else target
        reserved = reserved_names(season_folder)
        fingerprint = fast_fingerprint(file)
        content_key = fingerprint_key(file, fingerprint)
        existing = target_index.get(content_key)
        duplicate_in_scan = existing is None and content_key in planned_fingerprints
        if existing and season is not None and existing.parent != season_folder:
            planned = free_name(season_folder, existing.name, reserved)
        else:
            planned = existing or planned_fingerprints.get(content_key) or free_name(
                season_folder, file.name, reserved
            )
        if (not existing and not duplicate_in_scan) or (existing and planned != existing):
            reserved.add(planned.name.casefold())
        if not existing and not duplicate_in_scan:
            planned_fingerprints[content_key] = planned
        quality = classify_path_match(file, series_name, source) or "ambiguous"
        kind = "video" if file.suffix.casefold() in VIDEO_EXTENSIONS else "subtitle"
        items.append(
            ScanItem(
                source=file,
                kind=kind,
                existing_destination=existing,
                fingerprint=fingerprint,
                match_quality=quality,
                planned_destination=planned,
                season=season,
                selected=quality != "ambiguous"
                and (
                    operation == "move"
                    or (
                        not duplicate_in_scan
                        and (existing is None or existing.parent != planned.parent)
                    )
                ),
                duplicate_in_scan=duplicate_in_scan,
            )
        )

    return ScanResult(
        series_name=series_name,
        source=source,
        destination=destination,
        target=target,
        items=tuple(items),
        operation=operation,
    )


def _record_manifest_file(
    manifest: dict[str, object], fingerprint: FileFingerprint, destination: Path, source: Path, target: Path
) -> None:
    files = manifest.setdefault("files", {})
    assert isinstance(files, dict)
    content_key = fingerprint_key(source, fingerprint)
    try:
        destination_value = destination.relative_to(target).as_posix()
    except ValueError:
        destination_value = destination.name
    record = files.setdefault(
        content_key,
        {
            "size": fingerprint.size,
            "sample_sha256": fingerprint.sample_sha256,
            "destination": destination_value,
            "sources": {},
        },
    )
    if not isinstance(record, dict):
        record = {}
        files[content_key] = record
    record.update(
        {
            "size": fingerprint.size,
            "sample_sha256": fingerprint.sample_sha256,
            "destination": destination_value,
        }
    )
    sources = record.setdefault("sources", {})
    if isinstance(sources, dict):
        signature = source_signature(source)
        sources[str(signature["source"])] = {"modified": signature["modified"]}


def _source_container(scan: ScanResult, item: ScanItem) -> Optional[Path]:
    """Return the top-level release folder for an item, never the source root."""
    try:
        source_root = scan.source.resolve()
        relative_path = item.source.resolve().relative_to(source_root)
    except (OSError, ValueError):
        return None
    if len(relative_path.parts) < 2:
        return None
    return source_root / relative_path.parts[0]


def _completed_source_folder(
    scan: ScanResult, item: ScanItem, completed_sources: set[Path]
) -> Optional[tuple[Path, tuple[ScanItem, ...]]]:
    """Return one release folder only after every recognised nested item is complete."""
    folder = _source_container(scan, item)
    if folder is None:
        return None

    members = tuple(candidate for candidate in scan.items if _source_container(scan, candidate) == folder)
    if not members or not all(candidate.selected and candidate.source in completed_sources for candidate in members):
        return None
    return folder, members


def copy_series(
    scan: ScanResult,
    progress_callback: Optional[Callable[[CopyProgress], None]] = None,
    cancel_requested: Optional[Callable[[], bool]] = None,
    trash_handler: Optional[Callable[[Path], None]] = None,
) -> CopySummary:
    scan.target.mkdir(parents=True, exist_ok=True)
    manifest = load_manifest(scan.target)
    _backup_corrupt_manifest(scan.target, manifest)
    manifest["schema_version"] = MANIFEST_VERSION
    target_index = _target_index(scan.target)
    selected_items = tuple(item for item in scan.items if item.selected)
    copied = moved = source_removed = source_folders_removed = skipped = failed = processed = 0
    cancelled = False
    errors: list[str] = []
    completed_sources: set[Path] = set()
    trash = trash_handler or move_to_trash

    for item in selected_items:
        if cancel_requested and cancel_requested():
            cancelled = True
            break

        action = "copied"
        error_text = ""
        temporary_path: Optional[Path] = None
        try:
            current_fingerprint = fast_fingerprint(item.source)
            if current_fingerprint != item.fingerprint:
                raise OSError("source file changed after the preview")

            content_key = fingerprint_key(item.source, current_fingerprint)
            output_path = target_index.get(content_key)
            if output_path and output_path.is_file():
                desired_parent = item.planned_destination.parent
                if item.season is not None and output_path.parent != desired_parent:
                    desired_parent.mkdir(parents=True, exist_ok=True)
                    moved_path = item.planned_destination
                    if moved_path.exists() and moved_path != output_path:
                        moved_path = free_name(desired_parent, output_path.name)
                    logger.info("Moving collected file %s to %s", output_path, moved_path)
                    shutil.move(str(output_path), str(moved_path))
                    output_path = moved_path
                    target_index[content_key] = output_path
                    moved += 1
                    action = "moved"
                else:
                    if scan.operation == "copy":
                        skipped += 1
                        action = "skipped"
            else:
                output_path = item.planned_destination
                if output_path.exists():
                    output_path = free_name(output_path.parent, item.source.name)
                output_path.parent.mkdir(parents=True, exist_ok=True)
                temporary_path = output_path.parent / f".{output_path.name}.{uuid4().hex}.partial"
                logger.info("Copying %s to %s", item.source, output_path)
                shutil.copy2(item.source, temporary_path)
                if fast_fingerprint(temporary_path) != current_fingerprint:
                    raise OSError("copied file failed fingerprint verification")
                temporary_path.replace(output_path)
                temporary_path = None
                target_index[content_key] = output_path
                copied += 1

            _record_manifest_file(manifest, current_fingerprint, output_path, item.source, scan.target)
            save_manifest(scan.target, manifest)
            if scan.operation == "move":
                completed_sources.add(item.source)
                completed_folder = _completed_source_folder(scan, item, completed_sources)
                if completed_folder:
                    folder, members = completed_folder
                    logger.info("Moving completed source folder to Trash: %s", folder)
                    trash(folder)
                    source_removed += len(members)
                    source_folders_removed += 1
                    action = "source_folder_removed"
                elif _source_container(scan, item) is None or any(
                    _source_container(scan, candidate) == _source_container(scan, item) and not candidate.selected
                    for candidate in scan.items
                ):
                    logger.info("Moving verified source file to Trash: %s", item.source)
                    trash(item.source)
                    source_removed += 1
                    action = "source_removed"
        except OSError as error:
            failed += 1
            action = "failed"
            error_text = f"{item.source.name}: {error}"
            errors.append(error_text)
            logger.exception("Could not process %s", item.source)
            if temporary_path and temporary_path.exists():
                try:
                    temporary_path.unlink()
                except OSError:
                    logger.warning("Could not remove partial file %s", temporary_path)

        processed += 1
        if progress_callback:
            progress_callback(
                CopyProgress(
                    processed=processed,
                    total=len(selected_items),
                    current_file=item.source.name,
                    action=action,
                    copied=copied,
                    moved=moved,
                    source_removed=source_removed,
                    source_folders_removed=source_folders_removed,
                    skipped=skipped,
                    failed=failed,
                    error=error_text,
                )
            )

    return CopySummary(
        target=scan.target,
        total=len(selected_items),
        processed=processed,
        copied=copied,
        moved=moved,
        source_removed=source_removed,
        source_folders_removed=source_folders_removed,
        skipped=skipped,
        failed=failed,
        cancelled=cancelled,
        errors=tuple(errors),
    )


def open_folder(folder: Path) -> None:
    try:
        if sys.platform == "darwin":
            subprocess.run(["open", str(folder)], check=False)
        elif os.name == "nt":
            os.startfile(str(folder))
        elif shutil.which("xdg-open"):
            subprocess.run(["xdg-open", str(folder)], check=False)
    except OSError:
        pass
