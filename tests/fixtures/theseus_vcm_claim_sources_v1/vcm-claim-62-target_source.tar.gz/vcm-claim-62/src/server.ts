import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import {
  SubstackClient,
  MAX_PAGE_SIZE,
  ANALYTICS_SCAN_DEPTH,
} from "./api/client.js";
import { buildAnnotations } from "./annotations.js";
import { markdownToProseMirror, markdownToProseMirrorContent } from "./utils/markdown-to-prosemirror.js";
import { fileToDataUri } from "./utils/image.js";

export function createServer(client: SubstackClient): McpServer {
  const server = new McpServer({
    name: "substack-mcp",
    version: "0.6.1",
  });

  // Every tool is registered with MCP annotations derived from its declared
  // side-effect class (see annotations.ts) so clients can render accurate
  // consent UI. Reads are readOnlyHint:true; draft/upload writes are
  // additive; the Note tools publish public content immediately.

  // --- Read tools ---

  server.registerTool(
    "get_subscriber_count",
    {
      description:
        "Get the current subscriber count for your Substack publication. Returns `precision`: " +
        "'exact' when the API reports a true count, 'approximate' when only Substack's rounded " +
        "value is available (the real number is that or higher — render it hedged, e.g. '1,000+'), " +
        "or 'unavailable' with count -1. Never treat an approximate value as exact.",
      inputSchema: {},
      annotations: buildAnnotations("get_subscriber_count"),
    },
    async () => {
      const result = await client.getSubscriberCount();
      return {
        content: [
          { type: "text", text: JSON.stringify(result, null, 2) },
        ],
      };
    },
  );

  server.registerTool(
    "list_published_posts",
    {
      description: "List published posts with pagination. Returns title, date, slug, and URL for each post.",
      inputSchema: {
        offset: z.number().optional().default(0).describe("Number of posts to skip"),
        limit: z
          .number()
          .optional()
          .default(25)
          .describe(
            `Max posts to return (1-${MAX_PAGE_SIZE}; Substack rejects anything higher, so larger values are clamped)`,
          ),
      },
      annotations: buildAnnotations("list_published_posts"),
    },
    async ({ offset, limit }) => {
      const { posts, total } = await client.getPublishedPosts(offset, Math.min(limit, MAX_PAGE_SIZE));
      const summary = posts.map((p) => ({
        id: p.id,
        title: p.title,
        subtitle: p.subtitle,
        slug: p.slug,
        post_date: p.post_date,
        audience: p.audience,
        word_count: p.word_count,
        url: p.canonical_url,
      }));
      return {
        content: [{ type: "text", text: JSON.stringify({ total, posts: summary }, null, 2) }],
      };
    },
  );

  server.registerTool(
    "list_drafts",
    {
      description: "List draft posts. Returns title, creation date, and audience for each draft.",
      inputSchema: {
        offset: z.number().optional().default(0).describe("Number of drafts to skip"),
        limit: z
          .number()
          .optional()
          .default(25)
          .describe(
            `Max drafts to return (1-${MAX_PAGE_SIZE}; Substack rejects anything higher, so larger values are clamped)`,
          ),
      },
      annotations: buildAnnotations("list_drafts"),
    },
    async ({ offset, limit }) => {
      const drafts = await client.getDrafts(offset, Math.min(limit, MAX_PAGE_SIZE));
      const summary = drafts.map((d) => ({
        id: d.id,
        title: d.draft_title,
        subtitle: d.draft_subtitle,
        audience: d.audience,
        word_count: d.word_count,
        created_at: d.draft_created_at,
        updated_at: d.draft_updated_at,
      }));
      return {
        content: [{ type: "text", text: JSON.stringify(summary, null, 2) }],
      };
    },
  );

  server.registerTool(
    "get_post",
    {
      description: "Get the full content of a published post by ID. Returns title, body HTML, metadata.",
      inputSchema: {
        post_id: z.number().describe("The post ID to retrieve"),
      },
      annotations: buildAnnotations("get_post"),
    },
    async ({ post_id }) => {
      const post = await client.getPost(post_id);
      return {
        content: [
          {
            type: "text",
            text: JSON.stringify(
              {
                id: post.id,
                title: post.title,
                subtitle: post.subtitle,
                slug: post.slug,
                post_date: post.post_date,
                audience: post.audience,
                word_count: post.word_count,
                body_html: post.body_html,
                url: post.canonical_url,
              },
              null,
              2,
            ),
          },
        ],
      };
    },
  );

  server.registerTool(
    "get_draft",
    {
      description: "Get the full content of a draft post by ID. Returns title, body, metadata.",
      inputSchema: {
        draft_id: z.number().describe("The draft ID to retrieve"),
      },
      annotations: buildAnnotations("get_draft"),
    },
    async ({ draft_id }) => {
      const draft = await client.getDraft(draft_id);
      return {
        content: [
          {
            type: "text",
            text: JSON.stringify(
              {
                id: draft.id,
                title: draft.draft_title,
                subtitle: draft.draft_subtitle,
                body: draft.draft_body,
                audience: draft.audience,
                word_count: draft.word_count,
                created_at: draft.draft_created_at,
                updated_at: draft.draft_updated_at,
              },
              null,
              2,
            ),
          },
        ],
      };
    },
  );

  server.registerTool(
    "get_post_comments",
    {
      description: "Get comments on a published post. Returns commenter name, comment body, date, and reaction counts.",
      inputSchema: {
        post_id: z.number().describe("The post ID to get comments for"),
        limit: z.number().optional().default(20).describe("Max comments to return (default 20)"),
      },
      annotations: buildAnnotations("get_post_comments"),
    },
    async ({ post_id, limit }) => {
      const comments = await client.getPostComments(post_id, limit);
      const summary = comments.map((c) => ({
        id: c.id,
        name: c.name,
        body: c.body,
        date: c.date,
        reactions: c.reactions,
        replies: c.children_count,
      }));
      return {
        content: [{ type: "text", text: JSON.stringify(summary, null, 2) }],
      };
    },
  );

  server.registerTool(
    "get_sections",
    {
      description:
        "List your publication's sections (categories). Returns each section's id and name. Use a section id as `section_id` when creating or updating a draft to file it under that section.",
      inputSchema: {},
      annotations: buildAnnotations("get_sections"),
    },
    async () => {
      const sections = await client.getSections();
      const summary = sections.map((s) => ({ id: s.id, name: s.name }));
      return {
        content: [{ type: "text", text: JSON.stringify(summary, null, 2) }],
      };
    },
  );

  server.registerTool(
    "get_post_analytics",
    {
      description:
        "Get performance stats (views, emails sent/delivered/opened, signups, subscribes, estimated value, comments, reactions) for a published post by ID. " +
        `Substack has no per-post stats endpoint, so this searches your ${ANALYTICS_SCAN_DEPTH} most recent published posts for the ID; returns a not-found note if it isn't among them.`,
      inputSchema: {
        post_id: z.number().describe("The published post ID to get stats for"),
      },
      annotations: buildAnnotations("get_post_analytics"),
    },
    async ({ post_id }) => {
      const post = await client.getPostAnalytics(post_id);
      if (!post) {
        return {
          content: [
            {
              type: "text",
              text: JSON.stringify(
                {
                  found: false,
                  post_id,
                  note: `Post not found among the ${ANALYTICS_SCAN_DEPTH} most recent published posts. Check the ID with list_published_posts.`,
                },
                null,
                2,
              ),
            },
          ],
        };
      }
      const stats = post.stats ?? {};
      return {
        content: [
          {
            type: "text",
            text: JSON.stringify(
              {
                found: true,
                id: post.id,
                title: post.title,
                post_date: post.post_date,
                views: stats.views ?? null,
                sent: stats.sent ?? null,
                delivered: stats.delivered ?? null,
                opened: stats.opened ?? null,
                signups: stats.signups ?? null,
                subscribes: stats.subscribes ?? null,
                estimated_value: stats.estimated_value ?? null,
                comment_count: post.comment_count ?? null,
                reaction_count: post.reaction_count ?? null,
              },
              null,
              2,
            ),
          },
        ],
      };
    },
  );

  server.registerTool(
    "list_scheduled_posts",
    {
      description:
        "List posts scheduled for future publication, soonest first. Read-only visibility into what's queued — scheduling itself is done in Substack's editor (this server does not schedule, publish, or delete long-form posts). Returns id, title, audience, and scheduled time (`trigger_at`).",
      inputSchema: {
        offset: z.number().optional().default(0).describe("Number of posts to skip"),
        limit: z
          .number()
          .optional()
          .default(25)
          .describe(
            `Max posts to return (1-${MAX_PAGE_SIZE}; Substack rejects anything higher, so larger values are clamped)`,
          ),
      },
      annotations: buildAnnotations("list_scheduled_posts"),
    },
    async ({ offset, limit }) => {
      const posts = await client.getScheduledPosts(offset, Math.min(limit, MAX_PAGE_SIZE));
      const summary = posts.map((p) => ({
        id: p.id,
        title: p.draft_title ?? p.title ?? null,
        audience: p.audience,
        scheduled_at: p.trigger_at,
      }));
      return {
        content: [{ type: "text", text: JSON.stringify(summary, null, 2) }],
      };
    },
  );

  // --- Write tools (additive: private drafts + a public-URL image upload) ---

  server.registerTool(
    "create_draft",
    {
      description: "Create a new draft post. Accepts markdown body which is converted to Substack's format. Does NOT publish — creates a draft only.",
      inputSchema: {
        title: z.string().describe("Post title"),
        body: z.string().optional().describe("Post body in markdown format"),
        subtitle: z.string().optional().describe("Post subtitle"),
        audience: z
          .enum(["everyone", "only_paid", "founding", "only_free"])
          .optional()
          .default("everyone")
          .describe("Who can see this post"),
      },
      annotations: buildAnnotations("create_draft"),
    },
    async ({ title, body, subtitle, audience }) => {
      const prosemirrorBody = body ? markdownToProseMirror(body) : undefined;
      const draft = await client.createDraft(
        title,
        prosemirrorBody,
        subtitle,
        audience,
      );
      return {
        content: [
          {
            type: "text",
            text: JSON.stringify(
              {
                id: draft.id,
                title: draft.draft_title,
                message: "Draft created successfully. Open Substack to review and publish.",
              },
              null,
              2,
            ),
          },
        ],
      };
    },
  );

  server.registerTool(
    "update_draft",
    {
      description: "Update an existing draft post. Only works on unpublished drafts. Accepts markdown body.",
      inputSchema: {
        draft_id: z.number().describe("The draft ID to update"),
        title: z.string().optional().describe("New title"),
        subtitle: z.string().optional().describe("New subtitle"),
        body: z.string().optional().describe("New body in markdown format"),
        audience: z
          .enum(["everyone", "only_paid", "founding", "only_free"])
          .optional()
          .describe("Who can see this post"),
      },
      annotations: buildAnnotations("update_draft"),
    },
    async ({ draft_id, title, subtitle, body, audience }) => {
      const updates: Record<string, unknown> = {};
      if (title !== undefined) updates.draft_title = title;
      if (subtitle !== undefined) updates.draft_subtitle = subtitle;
      if (body !== undefined) updates.draft_body = markdownToProseMirror(body);
      if (audience !== undefined) updates.audience = audience;

      const draft = await client.updateDraft(draft_id, updates);
      return {
        content: [
          {
            type: "text",
            text: JSON.stringify(
              {
                id: draft.id,
                title: draft.draft_title,
                message: "Draft updated successfully.",
              },
              null,
              2,
            ),
          },
        ],
      };
    },
  );

  server.registerTool(
    "upload_image",
    {
      description:
        "Upload an image to Substack's CDN. Provide exactly one of `image_base64` (a base64 data URI) or `image_path` (a local file path). Returns a hosted image URL that is publicly fetchable by anyone with the link (an unlisted asset — not attributed to you or added to your feed).",
      inputSchema: {
        image_base64: z
          .string()
          .optional()
          .describe(
            'Base64-encoded image with data URI prefix (e.g., "data:image/png;base64,..."). Mutually exclusive with image_path.',
          ),
        image_path: z
          .string()
          .optional()
          .describe(
            'Absolute path to a local image file (e.g., "/Users/me/pic.png"). Read and encoded automatically; MIME type inferred from the extension. Mutually exclusive with image_base64.',
          ),
      },
      annotations: buildAnnotations("upload_image"),
    },
    async ({ image_base64, image_path }) => {
      if (!image_base64 === !image_path) {
        throw new Error(
          "Provide exactly one of `image_base64` or `image_path`.",
        );
      }
      const dataUri = image_path
        ? await fileToDataUri(image_path)
        : (image_base64 as string);
      const result = await client.uploadImage(dataUri);
      return {
        content: [
          { type: "text", text: JSON.stringify({ image_url: result.url }) },
        ],
      };
    },
  );

  // --- Note tools (PUBLISH IMMEDIATELY — public the moment they run) ---

  server.registerTool(
    "create_note",
    {
      description: "Create a Substack Note (short-form content). Accepts markdown text. PUBLISHES IMMEDIATELY to your public Notes feed — Notes have no draft state on Substack, and this server has no delete tools, so there is no undo from here.",
      inputSchema: {
        body: z.string().describe("Note content in markdown format"),
      },
      annotations: buildAnnotations("create_note"),
    },
    async ({ body }) => {
      const bodyJson = {
        type: "doc" as const,
        attrs: { schemaVersion: "v1" as const },
        content: markdownToProseMirrorContent(body),
      };
      const note = await client.createNote(bodyJson);
      return {
        content: [
          {
            type: "text",
            text: JSON.stringify(
              {
                id: note.id,
                body: note.body,
                date: note.date,
                message: "Note published successfully.",
              },
              null,
              2,
            ),
          },
        ],
      };
    },
  );

  server.registerTool(
    "create_note_with_link",
    {
      description: "Create a Substack Note with a link attachment, displayed as a rich card below the note text. PUBLISHES IMMEDIATELY to your public Notes feed — same caveats as create_note: no draft state, no undo from this server.",
      inputSchema: {
        body: z.string().describe("Note content in markdown format"),
        url: z.string().url().describe("URL to attach as a link card"),
      },
      annotations: buildAnnotations("create_note_with_link"),
    },
    async ({ body, url }) => {
      const attachment = await client.createNoteAttachment(url);
      const bodyJson = {
        type: "doc" as const,
        attrs: { schemaVersion: "v1" as const },
        content: markdownToProseMirrorContent(body),
      };
      const note = await client.createNote(bodyJson, [attachment.id]);
      return {
        content: [
          {
            type: "text",
            text: JSON.stringify(
              {
                id: note.id,
                body: note.body,
                date: note.date,
                attachment_id: attachment.id,
                message: "Note with link published successfully.",
              },
              null,
              2,
            ),
          },
        ],
      };
    },
  );

  return server;
}
