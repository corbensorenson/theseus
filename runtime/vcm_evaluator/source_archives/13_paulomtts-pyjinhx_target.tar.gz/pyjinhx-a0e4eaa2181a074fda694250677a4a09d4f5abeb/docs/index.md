# PyJinHx

Build reusable, type-safe UI components for template-based web apps in Python.

PyJinHx combines **Pydantic models** with **Jinja2 templates** to give you template discovery, component composition, and asset bundling.

## Features

- **Automatic Template Discovery** - Place templates next to component files, no manual paths needed
- **Composability** - Nest components easily with single components, lists, and dictionaries
- **Asset Bundling** - Automatically collects and bundles `.js` and `.css` files from component directories
- **Type Safety** - Pydantic models provide validation and IDE support

## Choose your depth

PyJinHx layers optional features on top of a small core. You can stop at any tier:

| Tier | You get | Start here |
|------|---------|------------|
| **1 — Components** | `BaseComponent`, templates, assets | [Quick Start](getting-started/quickstart.md) |
| **2 — Web app** | Per-request `Registry.request_scope()` | [Registry guide](guide/registry.md) |
| **3 — Reactive** | HTMX OOB swaps, `@mutates`, `load()` | [Reactivity](reactivity.md) |
| **4 — Full wiring** | `PjxContext`, `ClientBackend`, cache, invalidation | [Build an App](getting-started/build-an-app.md) |

Details: [Usage tiers](guide/usage-tiers.md).

## Two Ways to Render

Within Tier 1, PyJinHx offers two complementary approaches:

=== "Python-side"

    Instantiate components in Python and call `.render()`:

    ```python
    from components.ui.button import Button

    button = Button(id="submit", text="Submit", variant="primary")
    html = button.render()
    ```

=== "Template-side"

    Use HTML-like syntax with the `Renderer`:

    ```python
    from pyjinhx import Renderer

    Renderer.set_default_environment("./components")
    renderer = Renderer.get_default_renderer()
    html = renderer.render('<Button text="Submit" variant="primary"/>')
    ```

## Next Steps

- [Installation](getting-started/installation.md) - Install PyJinHx
- [Build an App](getting-started/build-an-app.md) - Step-by-step tutorial with **Why?** panels (recommended for new users)
- [Quick Start](getting-started/quickstart.md) - Minimal first component
- [Guide](guide/components.md) - Feature reference
- [Components](components.md) - Optional `pyjinhx.builtins` package
- [Public API Index](reference/public-api.md) - Every symbol exported from `pyjinhx`
- [Migration guide](migration.md) — 0.8 → 0.9 breaking changes and upgrading from 0.4.x
