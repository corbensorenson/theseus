# Registry

Central registry for component classes and instances.

## Class

### Registry

Provides two registries:

- **Class registry**: Maps component class names to their types (process-wide)
- **Instance registry**: Maps composite keys (`ComponentName_id`) to instances (context-local, thread-safe)

Component classes are auto-registered when subclassing `BaseComponent`. Instances are registered upon instantiation using a composite key that combines the class name and instance ID. This allows different component types to share the same `id` without collision.

See the [Component Registry guide](../guide/registry.md) for conceptual documentation and usage patterns.

## Class Registry Methods

### register_class()

```python
@classmethod
def register_class(cls, component_class: type[BaseComponent]) -> None
```

Register a component class by its name. Called automatically when subclassing `BaseComponent`.

**Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `component_class` | `type[BaseComponent]` | The component class to register |

### get_classes()

```python
@classmethod
def get_classes(cls) -> dict[str, type[BaseComponent]]
```

Return a copy of all registered component classes.

**Returns:** Dictionary mapping class names to component class types.

### get_class()

```python
@classmethod
def get_class(cls, name: str) -> type[BaseComponent] | None
```

Return a registered component class by name without copying the registry, or `None` if not registered.

**Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | `str` | The component class name (e.g., `"Button"`) |

**Returns:** The component class, or `None`.

### has_class()

```python
@classmethod
def has_class(cls, name: str) -> bool
```

Return whether a component class is registered under `name`.

**Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | `str` | The component class name to check |

**Returns:** `True` if registered, otherwise `False`.

### clear_classes()

```python
@classmethod
def clear_classes(cls) -> None
```

Remove all registered component classes. Useful for testing.

## Instance Registry Methods

### make_key()

```python
@classmethod
def make_key(cls, class_name: str, instance_id: str) -> str
```

Generate a registry key from component class name and instance ID.

**Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `class_name` | `str` | The component class name (e.g., `"Button"`) |
| `instance_id` | `str` | The component instance ID (e.g., `"submit-btn"`) |

**Returns:** The composite key string (e.g., `"Button_submit-btn"`).

**Example:**

```python
from pyjinhx import Registry

key = Registry.make_key("Button", "submit-btn")
# Returns: "Button_submit-btn"

# Check if a component exists
if key in Registry.get_instances():
    button = Registry.get_instances()[key]
```

### register_instance()

```python
@classmethod
def register_instance(cls, component: BaseComponent) -> None
```

Register a component instance by its ID. Called automatically on instantiation.

**Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `component` | `BaseComponent` | The component instance to register |

### get_instances()

```python
@classmethod
def get_instances(cls) -> dict[str, BaseComponent]
```

Return all registered component instances in the current context.

**Returns:** Dictionary mapping composite keys (`ComponentName_id`) to component instances. Use `make_key()` to construct keys for lookup.

### clear_instances()

```python
@classmethod
def clear_instances(cls) -> None
```

Remove all registered component instances from the current context.

### request_scope()

```python
@classmethod
@contextmanager
def request_scope(cls, *, load_context: object | None = None, client_backend: object | None = None)
```

Context manager for request-scoped component instances, load cache, mutation tracking, optional load context, and optional client backend for HTTP headers.

On entry: clears pending mutations, initializes the request-scoped load cache, and optionally sets a `PjxContext` for reactive `load()` methods and a `ClientBackend` for `render()` header auto-resolution. On exit: warns about unconsumed mutations (when reactive dev is enabled), clears mutations, and resets the request cache.

**Usage:**

```python
from pyjinhx import Registry
from pyjinhx.integrations.fastapi import FastAPIClientBackend

with Registry.request_scope(
    load_context=AppLoadContext(db=session),
    client_backend=FastAPIClientBackend(request),
):
    # Components registered here are isolated to this scope
    button = Button(id="submit-btn", text="Submit")
    # ... render template
# Registry, cache, and mutations automatically restored
```

Scopes support nesting — each scope is independent. See the [Component Registry guide](../guide/registry.md) for conceptual documentation and the [FastAPI integration guide](../integrations/fastapi.md#middleware-recommended) for practical examples.
