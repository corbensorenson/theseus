"""The asset-delta leg of fan-out: which required assets the client is missing."""

import dataclasses
from pathlib import Path

import pytest

from pyjinhx.assets import AssetMode, asset_token
from pyjinhx.reactive.assets import missing_asset_oob, required_asset_paths
from pyjinhx.reactive.component import ReactiveComponent
from pyjinhx.reactive.fanout import FanoutCandidate
from pyjinhx.reactive.keys import MutationKey
from pyjinhx.session import RenderSession


class Keys(MutationKey):
    WIDGET = "widget"


class AssetWidget(ReactiveComponent, react=(Keys.WIDGET,)):
    """A reactive component whose descriptor is repointed at real asset files."""

    def load(self) -> int:
        return 0


@pytest.fixture
def asset_files(tmp_path: Path) -> tuple[Path, Path]:
    css = tmp_path / "widget.css"
    css.write_text(".widget{color:red}")
    js = tmp_path / "widget.js"
    js.write_text("window.widget=1;")
    AssetWidget.__pjx_descriptor__ = dataclasses.replace(
        AssetWidget.__pjx_descriptor__, css_paths=(css,), js_paths=(js,)
    )
    return css, js


def candidate(status: str = "dirty") -> FanoutCandidate:
    return FanoutCandidate(
        type_name="asset_widget",
        component_class=AssetWidget,
        instance_id="w1",
        load=None,
        status=status,
        entry={"id": "w1", "type": "asset_widget"},
    )


def test_required_asset_paths_reads_the_candidate_classes_descriptors(asset_files):
    css, js = asset_files
    assert required_asset_paths([candidate()]) == ({css}, {js})


def test_a_missing_candidate_requires_nothing(asset_files):
    assert required_asset_paths([candidate(status="missing")]) == (set(), set())


def test_missing_asset_oob_emits_only_the_tokens_the_client_lacks(asset_files):
    css, js = asset_files
    session = RenderSession()
    fragment = missing_asset_oob([candidate()], frozenset({asset_token(css)}), session)

    assert asset_token(css) not in fragment
    assert (
        f'<script data-pjx-asset="{asset_token(js)}" '
        'hx-swap-oob="beforeend:head">window.widget=1;</script>' in fragment
    )


def test_missing_asset_oob_emits_both_kinds_when_the_client_has_nothing(asset_files):
    css, js = asset_files
    fragment = missing_asset_oob([candidate()], frozenset(), RenderSession())

    assert f'<style data-pjx-asset="{asset_token(css)}"' in fragment
    assert f'<script data-pjx-asset="{asset_token(js)}"' in fragment
    # CSS before JS, so a script that measures layout sees the styled DOM.
    assert fragment.index("<style") < fragment.index("<script")


def test_missing_asset_oob_is_empty_when_the_client_has_everything(asset_files):
    css, js = asset_files
    loaded = frozenset({asset_token(css), asset_token(js)})

    assert missing_asset_oob([candidate()], loaded, RenderSession()) == ""


def test_garbage_tokens_are_treated_as_having_nothing(asset_files):
    css, _ = asset_files
    fragment = missing_asset_oob(
        [candidate()], frozenset({"not-a-real-token"}), RenderSession()
    )

    assert asset_token(css) in fragment


def test_a_class_with_no_assets_is_a_no_op_not_an_error():
    class Bare(ReactiveComponent, react=(Keys.WIDGET,)):
        def load(self) -> int:
            return 0

    bare = dataclasses.replace(candidate(), component_class=Bare)
    assert missing_asset_oob([bare], frozenset(), RenderSession()) == ""


def test_non_inline_modes_emit_nothing(asset_files):
    session = RenderSession()
    session.css_mode = AssetMode.NONE
    session.js_mode = AssetMode.LINK

    assert missing_asset_oob([candidate()], frozenset(), session) == ""


def test_reactive_response_appends_the_asset_fragment_after_the_swaps(
    asset_files, monkeypatch
):
    from pyjinhx.reactive import response as response_module

    css, _ = asset_files
    # status="clean": a "dirty" FanoutCandidate must carry a real RenderedLevel
    # or oob_swaps() asserts (walk_manifest's contract), and this test only
    # exercises the asset leg, not the swap markup.
    monkeypatch.setattr(
        response_module.ReactiveResponse,
        "candidates",
        lambda self: [candidate("clean")],
    )
    body = str(
        response_module.ReactiveResponse(
            primary="", mounted=None, assets='["nope"]'
        ).body
    )

    assert asset_token(css) in body


def test_reactive_response_omits_the_asset_fragment_when_the_client_has_it(
    asset_files, monkeypatch
):
    from pyjinhx.reactive import response as response_module

    css, js = asset_files
    monkeypatch.setattr(
        response_module.ReactiveResponse,
        "candidates",
        lambda self: [candidate("clean")],
    )
    loaded = [asset_token(css), asset_token(js)]
    body = str(
        response_module.ReactiveResponse(primary="", mounted=None, assets=loaded).body
    )

    assert "data-pjx-asset" not in body


def test_an_assets_only_body_still_says_do_not_swap(asset_files, monkeypatch):
    from pyjinhx.reactive import response as response_module

    monkeypatch.setattr(
        response_module.ReactiveResponse,
        "candidates",
        lambda self: [candidate("clean")],
    )
    reactive = response_module.ReactiveResponse(primary="", mounted=None, assets=None)

    assert "data-pjx-asset" in str(reactive.body)
    assert reactive.headers["HX-Reswap"] == "none"
