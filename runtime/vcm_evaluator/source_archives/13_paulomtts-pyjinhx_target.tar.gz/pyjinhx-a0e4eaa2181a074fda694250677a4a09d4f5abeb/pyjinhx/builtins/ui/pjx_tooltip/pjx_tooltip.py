from typing import Literal

from pyjinhx.component import AttrValue, BaseComponent, Slot


class PJXTooltip(BaseComponent):
    """The positioned root shell that anchors a trigger to its tip; the JS finds both through data-pjx-tooltip-placement (port of v0.x pyjinhx/builtins/ui/pjx_tooltip/pjx_tooltip.py)."""

    placement: Literal["top", "bottom", "start", "end"] = "top"
    class_name: AttrValue = ""
    content: Slot = ""
