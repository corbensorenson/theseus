# Dry-run validation (2026-06-07)

Orchestrator dry-run after reactive refactor. Used to calibrate severity and confirm skills are not noisy on clean scope.

## pyjinhx/reactive/

| P1 | P2 | P3 |
|----|----|----|
| 0  | 0  | 0–1 |

**Summary:** Post-refactor reactive package passes all lenses. No layer violations, no thin wrappers, ContextVars owned by hub classes (`LoadCache`, `MutationTracker`, `ClientBackend`) or `PjxContext` static API. Largest file `load_cache.py` (243 LOC) is cohesive single-class; below hard split threshold.

Optional P3 (not reported): `load_cache.py` slightly above 250 LOC soft ceiling — defer split until second concern appears.

## pyjinhx/core/

| P1 | P2 | P3 |
|----|----|----|
| 0  | 1  | 2 |

### P2 — `renderer.py` size (~858 LOC)

- **Status:** Remediated — split into `renderer.py` (~470 LOC orchestration), `render_assets.py`, `tag_expand.py`, `autodiscover.py`.

### P3 — `core/__init__.py` empty

- **Lens:** file-responsibility-audit
- **Issue:** No module-map docstring (reactive `__init__.py` has one).
- **Fix shape:** Add brief docstring map if core grows submodules.

### P3 — `registry.py` module-level `_registry_context`

- **Lens:** state-shape-audit
- **Issue:** ContextVar at module level vs `ClassVar` on `Registry` (matches `PjxContext` pattern).
- **Fix shape:** Optional consolidation onto `Registry` when editing; not inconsistent enough to prioritize.

## Cross-cutting (docs, not code scope)

`public-api-audit` on `docs/` should flag stale symbols (`mutation_scope`, `dirty_keys`, `get_load_context`, `fastapi_client_backend`, `dirtied=`/`mounted=` on `render()`) — **P1 doc drift** when auditing full package + docs. `docs/integrations/claude-code.md` may still lag after reactive simplification; reactive `pyjinhx/` scope stays clean.

## Rubric tuning applied

- Cohesive single-class files 240–260 LOC → no finding unless mixed concerns.
- Module-level ContextVar + class static methods (`PjxContext`, `Registry`) → OK, not P2.
- Expected baseline in orchestrator SKILL.md matches reactive dry-run.
- **dead-code-audit** runs last in full sweep; complements `public-api-audit` with code-path and orphan-test analysis.
