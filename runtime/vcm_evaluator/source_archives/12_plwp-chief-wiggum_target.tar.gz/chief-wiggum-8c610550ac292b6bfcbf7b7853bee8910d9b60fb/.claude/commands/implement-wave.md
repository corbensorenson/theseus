# Implement Wave - Parallel Epic Implementation

Takes an epic and implements all its tickets in dependency-ordered waves. Tickets within a wave have no interdependencies and run as parallel workers, each in its own worktree. After each wave lands, the next wave starts from an updated main.

This is the high-throughput alternative to running `/implement` sequentially per ticket. Use it when:
- The epic has 3+ tickets
- `/architect` has already run (contracts and invariants exist)
- You want maximum parallelism within dependency constraints

## Ownership

Same principles as `/implement`: you own the solution, not just the code. The validation loop is not negotiable. But here, validation happens at **two levels**:
- **Per-ticket**: Each parallel worker runs the full `/implement` loop (Steps 5-8)
- **Per-wave**: After merging a wave, the orchestrator runs integration checks before starting the next wave

## Usage
```
/implement-wave <owner/repo> --epic "<milestone name>" [--skip-browser-use] [--max-parallel <N>]
```

## Parameters
- `owner/repo`: GitHub repository in `owner/repo` format
- `--epic`: The milestone name (e.g., `"Epic: Order Lifecycle"`)
- `--skip-browser-use`: Skip browser-use validation on all tickets
- `--max-parallel`: Maximum concurrent implementations (default: 2). Limits API rate pressure. Each ticket spawns 3-4 AI consultations, so `--max-parallel 2` means up to 8 concurrent API calls. Users with high-tier API access can increase to 3 or more.

## Workflow

### Step 1: Resolve paths and load epic context

**Prevent sleep**: Wave implementation runs for hours. Start `caffeinate` to keep the machine awake:
```bash
caffeinate -ims &
CAFFEINATE_PID=$!
```
Kill it when the workflow completes (or fails): `kill $CAFFEINATE_PID 2>/dev/null`

```bash
CW_HOME="${CHIEF_WIGGUM_HOME:-$HOME/repos/chief-wiggum}"
CW_HOME=$(python3 "$CW_HOME/scripts/env.py" home)
# One tested call resolves CW_HOME, CW_TMP, TARGET_REPO, DEFAULT_BRANCH, EPIC_SLUG, EPIC_DIR.
# Capture first and check status so a resolver failure aborts cleanly.
CW_CTX=$(python3 "$CW_HOME/scripts/workflow_context.py" "$owner_repo" --epic "$epic_name" --shell) || {
  echo "workflow_context failed for $owner_repo" >&2; exit 1; }
eval "$CW_CTX"
```

Load epic artifacts from `$EPIC_DIR/`:
- `contracts.md` — REQUIRES/ENSURES
- `state-machines.md` — valid transitions
- `invariants.md` — cross-cutting rules
- `traceability.md` — AC to test mapping

**If epic artifacts don't exist, STOP.** Run `/architect` first. Wave implementation without contracts is unsafe — parallel tickets will diverge on design decisions.

**Build the artifact inventory** — one tested pass that discovers prose/model/design artifacts, sets `HAS_FORMAL_MODELS`/`HAS_UI_SPEC`/`HAS_TRANSITION_MAP`, validates model JSON, and runs the unresolved-marker scan:

```bash
python3 "$CW_HOME/scripts/epic_inventory.py" "$TARGET_REPO" --epic-slug "$EPIC_SLUG" \
  ${EPIC_DIR:+--epic-dir "$EPIC_DIR"} > "$CW_TMP/inventory.json"
# Tickets gated by unresolved markers, as a comma-separated list for the planner.
BLOCKED_TICKETS=$(jq -r '.blocked_tickets | join(",")' "$CW_TMP/inventory.json")
HAS_FORMAL_MODELS=$(jq -r '.flags.HAS_FORMAL_MODELS' "$CW_TMP/inventory.json")
```

If `.flags.HAS_EPIC` is false, **STOP** (no contracts) — every wave run is always inside a named epic (`--epic` is required), so here `HAS_EPIC: false` always means `epic_status: missing` (chief-wiggum#286), never the standalone-ticket case `/implement` also has to consider. Each unresolved finding carries the tickets it blocks (from `derived_from` provenance); tickets in `blocked_tickets` must NOT be implemented on a guess — they are passed to the planner in Step 2 and re-checked in Step 4.

### Step 2: Build the wave plan

Fetch **all** tickets in the epic milestone (both open and closed — closed tickets satisfy dependents and must be passed to the planner so it can mark them done rather than schedule them):

```bash
# Full epic issue list, and the closed subset.
EPIC_ISSUES=$(gh issue list --repo "$owner_repo" --milestone "$epic_name" --state all --limit 200 --json number -q 'map(.number) | join(",")')
CLOSED_ISSUES=$(gh issue list --repo "$owner_repo" --milestone "$epic_name" --state closed --limit 200 --json number -q 'map(.number) | join(",")')
# Tickets gated by Step 1's unresolved-marker scan (comma-separated issue numbers).
BLOCKED_TICKETS="${BLOCKED_TICKETS:-}"
```

Parse the dependency graph from the milestone description. `/plan-epic` writes a machine-readable `<!-- DEPENDENCIES -->` block:

```html
<!-- DEPENDENCIES
#42: []
#43: [#42]
#44: [#43]
#45: [#43]
#46: [#42]
-->
```

Parse the block into an adjacency list with the tested helper (no brittle inline parsing):

```bash
python3 "$CW_HOME/scripts/epic_metadata.py" deps "$owner_repo" --milestone "$epic_name"
```

This emits JSON like:
```json
{ "edges": { "42": [], "43": [42], "44": [43] }, "warnings": [], "has_block": true }
```
where `edges[N]` lists the issues `#N` depends on. Malformed lines and a missing
milestone surface in `warnings` rather than crashing.

**If `has_block` is false** (the DEPENDENCIES block is missing), fall back to parsing `depends on #N` annotations from the implementation order in the milestone description or issue bodies. Warn the user that this is less reliable and suggest re-running `/plan-epic` to add structured metadata.

Compute the wave plan with the tested planner instead of sorting by hand. Feed it the dependency edges, the full epic issue list, the already-closed issues, and the tickets gated by the Step 1 unresolved scan (`blocked_tickets`):

```bash
python3 "$CW_HOME/scripts/epic_metadata.py" deps "$owner_repo" --milestone "$epic_name" > "$CW_TMP/deps.json"
python3 "$CW_HOME/scripts/plan_waves.py" \
  --deps-json "$CW_TMP/deps.json" \
  --issues "$EPIC_ISSUES" \
  --closed "$CLOSED_ISSUES" \
  --gated "$BLOCKED_TICKETS" \
  --markdown
```

The planner emits dependency-ordered `waves` (each a batch of tickets with no unmet dependencies, safe to run in parallel), plus `gated` (held back), `skipped` (already closed), `integration_risks`, and per-ticket `gate_reasons`. It **exits non-zero on a dependency cycle** — stop and fix the graph before building anything. Transitive gating is built in: gating a ticket holds back everything that (transitively) depends on it.

The planner also surfaces **integration risks** — shared dependencies (diamonds / fan-out). Flag these for the merge step.

**Apply the unresolved-unknowns gate.** For each ticket in `blocked_tickets` (from Step 1's scan):
1. First try to **resolve the unknown now** — introspect the real schema, read the source repo, check the external service. Many "unknowns" are 10 minutes of research. If resolved: update the artifact (remove the marker, cite the source), commit, and un-gate the ticket.
2. If the unknown needs the user (credentials, a client answer, a business decision): mark the ticket **GATED** in the wave plan with a one-line "resolve X first" reason, and move it (plus its transitive dependents) to a later wave or out of the plan.
3. Never launch a GATED ticket on a guessed value. A placeholder that ships is a production incident with a delay timer.

Present the wave plan to the user:

```markdown
## Wave Plan: [Epic Name]

### Wave 1 (parallel)
- #42 - Define order data model (S)
- #45 - Order notifications (S)

### Wave 2 (parallel, after Wave 1 merges)
- #43 - Order API endpoints (M) — depends on #42
- #46 - Order customer portal (L) — depends on #42

### Wave 3 (parallel, after Wave 2 merges)
- #44 - Order admin UI (M) — depends on #43
  ⚠️ Integration risk: shares OrderList component with #46 (Wave 2)

### Gated (unresolved unknowns — not scheduled)
- #47 - Revenue rollup query — ⛔ GATED: contracts.json carries "TBD: confirm orders_daily column names against dbt model" — resolve before implementing

### Estimated timeline
- Waves: 3
- Max tickets per wave: 2
- Total tickets: 5
```

**CHECKPOINT**: Ask the user to confirm the wave plan. They may want to adjust (move a ticket between waves, split a wave, etc.).

### Step 3: Pre-flight checks

Before launching any implementation, verify all tools are working:

```bash
# Verify AI tool auth
echo "test" | codex exec --sandbox read-only - >/dev/null 2>&1 && echo "codex: OK" || echo "codex: FAIL"
echo "test" | gemini --yolo --output-format text -p "" >/dev/null 2>&1 && echo "gemini: OK" || echo "gemini: FAIL"

# Verify target repo is clean and on default branch
cd "$TARGET_REPO"
git checkout "$DEFAULT_BRANCH"
git pull --ff-only
# Guard: main must be on the default branch with a clean tree. Catches an isolation
# LEAK from a previous run — a worker that ran `git checkout` in the main checkout
# instead of its worktree leaves main on a feature branch, contaminating every base
# branched off it. Re-run this before each wave's worktree creation and before merging.
python3 "$CW_HOME/scripts/git_safety.py" assert-main-pristine --main "$TARGET_REPO" --default-branch "$DEFAULT_BRANCH"
```

**If any AI tool fails auth, fix it now.** Do not discover auth failures 20 minutes into a parallel wave. If the user needs to run an interactive login, tell them to run `! codex auth login` or similar.

**If `assert-main-pristine` fails, STOP** — main is on a feature branch or dirty (an isolation leak). Restore it (`git checkout "$DEFAULT_BRANCH"`, inspect/park any stray changes) before launching any wave, or every worktree will branch off a contaminated base.

**Load amnesia context** (resolve `QUALITY_DIR=$(python3 "$CW_HOME/scripts/artifacts.py" show "$TARGET_REPO" --format json | jq -r .quality_dir)`; if `$QUALITY_DIR/ratchet.json` exists): replay the recent ratchet journal so this session doesn't re-litigate decisions a previous wave already made (a parked ticket, an amended contract, a known-flaky suite):

```bash
python3 "$CW_HOME/scripts/ratchet.py" recent --repo "$TARGET_REPO" --n 5
```

### Step 4: Execute waves

For each wave, in order:

**Before launching a wave**, re-run the unresolved scan (`check_unresolved.py "$EPIC_DIR" --format json`) — artifacts may have changed since the plan was made. Any ticket in the wave that is still blocked by an unresolved marker is held back (resolve it or defer it; never implement on a guess).

Also check for failed dependencies. If any ticket in a previous wave failed, remove all downstream dependents from the current and future waves. Recompute the wave plan with the remaining tickets. Report to the user which tickets were dropped and why:

```markdown
⚠️ Skipping #44 (depends on #43 which failed in Wave 2)
⚠️ Skipping #47 (depends on #44, transitively blocked)
Revised Wave 3: #45, #46
```

#### 4a: Generate formal test artifacts (if formal models exist)

**Before any workers run**, the orchestrator generates mechanical test artifacts from the formal models. This is deterministic — no LLM involved — and provides test scaffolding that workers adapt rather than inventing tests from scratch.

```bash
if [ "$HAS_FORMAL_MODELS" = true ]; then
  # One idempotent call generates every model-derived test artifact (test paths,
  # test plan, contract assertions, Hypothesis skeleton, guard templates) plus a
  # manifest, for whichever models exist in $MODELS_DIR.
  python3 "$CW_HOME/scripts/generate_formal_test_artifacts.py" "$MODELS_DIR" \
    --output "$CW_TMP/formal-test-artifacts/"
fi
```

The shared `$CW_TMP/formal-test-artifacts/formal-artifacts-manifest.json` lists the generated files; every worker in the wave adapts the same artifacts to its ticket.

These artifacts are shared across all tickets in the wave — each worker receives the same test plan and adapts the relevant portions for its ticket.

#### 4b: Launch parallel implementations

For each ticket in the current wave (up to `--max-parallel`):

1. Create a **ticket-scoped temp directory**:
   ```bash
   TICKET_TMP="$CW_TMP/$ticket_number"
   mkdir -p "$TICKET_TMP"
   ```

2. Launch a background **implementation worker** (contract: `docs/worker-contracts.md#implementation-worker`) — it operates in its own isolated checkout, never the main checkout, and signals completion by writing its status/diff artifacts. *Claude Code adapter:* `subagent_type: "general-purpose"`, `model: "sonnet"`, `isolation: "worktree"`, `run_in_background: true`.

   The worker prompt must include:
   - The full ticket details (title, body, acceptance criteria)
   - The epic context (contracts, invariants, state machines, traceability)
   - **Formal test artifacts** (if they exist): the test plan (`$CW_TMP/formal-test-artifacts/test-plan.md`), test paths (`test-paths.json`), contract assertions (`contract-assertions.md`), guard templates, and Hypothesis skeleton. Instruct the worker: "Adapt the model-derived test cases to the target repo's test framework. Each test path becomes a test case. Each invalid transition becomes a negative test. Tag model-derived tests with `// DERIVED: model` for traceability."
   - The implementation plan approach: run the **full `/implement` Steps 4-9** internally:
     - Step 4: Consult 3 AIs on approach (Codex + Gemini as background processes, self as the third perspective), reconcile into plan
     - Step 5: Write failing tests (TDD) — **use model-derived test cases as the starting point**, supplement with LLM-written tests for edge cases
     - Step 6: Implement to make tests green
     - Step 7: Multi-AI code review (Codex + Gemini in parallel)
     - Step 8: Apply review fixes, run full test suite, run linting, verify acceptance criteria
     - Step 9: UX sanity + design-fidelity gate for frontend tickets — render the app, capture screenshots to `$TICKET_TMP/ux-screenshots/`, review against the ui-spec design contract. Save the screenshots; the orchestrator attaches them to the wave report.
     - Step 10: Browser-use/E2E validation (unless `--skip-browser-use` was passed)
   - **HARD RULES**:
     - Do NOT create or merge pull requests. Return the branch name and a summary.
     - You are in a git worktree. Assert isolation with `python3 "$CW_HOME/scripts/git_safety.py" assert-worktree --main "$TARGET_REPO"` (it aborts if you are in the main checkout). Never operate on the main checkout.
     - Write all temp files to `$TICKET_TMP/` (pass the path explicitly).
     - If you encounter a blocking error after 3 retries, report it and stop — do not silently skip steps.
     - Do NOT run `gh pr create`, `gh pr merge`, or `git push`. The orchestrator handles all of this.
   - The target repo path and default branch name
   - Instructions to report back: branch name, test results, review findings, any issues

3. If the wave has more tickets than `--max-parallel`, queue the excess. As each worker completes, launch the next queued ticket.

**Worker timeout**: If a worker has not completed after **3 hours**, consider it hung. Implementation workers run the full /implement loop internally (AI consultations, TDD, review, validation) which legitimately takes 60-120 minutes per ticket. Only after the 3-hour mark should you log a warning, note the ticket as failed for this wave, and proceed with collecting results from completed agents. The hung ticket can be retried in a later wave or handled manually with `/implement`.

**While workers run**, the orchestrator waits for each worker's completion signal — its output/status artifact appearing at the agreed path (see `docs/worker-contracts.md` → completion signalling). *Claude Code adapter:* a background Agent's task-notification fires when a worker finishes; treat it as the "artifact is ready" signal, not the contract itself.

#### 4c: Collect and verify results

As each worker in the wave completes, collect:
- **Branch name** and worktree path
- **Test results**: did the full suite pass?
- **Review findings**: what was flagged, what was fixed?
- **Issues**: any blockers or unresolved items?

If a worker reports failure:
- **Test failures**: Attempt to diagnose. If it's a real issue, flag it. If it's a flaky test or pre-existing failure, note it.
- **Blocking errors**: Log the error. The ticket may need to be moved to a later wave or handled manually.
- **Timeout**: The worker may still be running. Check its status before declaring failure.

Do not proceed to the merge step until ALL workers in the wave have completed (successfully or with documented failures).

**Rogue PR detection**: After all workers complete, check for unauthorized PRs:
```bash
gh pr list --repo "$owner_repo" --state open --limit 10 --json number,title,author,headRefName
```
If any PRs were created by a worker during this wave (matching ticket branch names), close them with a comment explaining the orchestrator handles PR creation. Warn the user.

**Orchestrator independent verification**: For each successfully completed ticket, the orchestrator must independently verify (not just trust the worker's report):
1. Check out the ticket's branch in its worktree
2. Run the full test suite
3. Run linting
4. Verify the branch has the expected commits
5. **Protected-path guard** (if `$QUALITY_DIR/ratchet.json` exists — `QUALITY_DIR` resolved via `python3 "$CW_HOME/scripts/artifacts.py" show "$TARGET_REPO" --format json | jq -r .quality_dir`; see `docs/ratchet.md`) — workers must not move their own goalposts. Check the worker's diff against the protected pathset (contracts, invariants, integration-test specs, formal models, ratchet state):
   ```bash
   python3 "$CW_HOME/scripts/ratchet.py" protected --repo "$worktree" --base "origin/$DEFAULT_BRANCH"
   ```
   If it exits non-zero, **park the ticket**: do NOT merge it this wave. Surface the touched files and the diff to the user — a worker editing a contract to make its implementation pass is exactly what this guard exists to catch. If the user approves the contract change, journal it with `ratchet.py record --amend/--retire` and re-admit the ticket next wave.
6. **For frontend tickets**: verify screenshots exist in `$TICKET_TMP/ux-screenshots/` and LOOK at them. A worker reporting "design review passed" without screenshots is a worker that skipped the gate. If the epic has a design contract and the screenshots show default-theme output, the ticket is not done.

This is the same principle as `/implement` Step 8 — the orchestrator is the quality gate, not the worker.

#### 4d: Merge wave to a staging branch

**Do NOT merge directly to the default branch.** Use a staging branch so the integration check (4d) runs before anything is pushed.

1. **Create a staging branch** from the current default branch:
   ```bash
   cd "$TARGET_REPO"
   git checkout "$DEFAULT_BRANCH"
   git pull --ff-only
   # Re-assert main is pristine before branching the staging base off it (a worker in
   # this wave may have leaked a checkout into main).
   python3 "$CW_HOME/scripts/git_safety.py" assert-main-pristine --main "$TARGET_REPO" --default-branch "$DEFAULT_BRANCH"
   git checkout -b "wave-$wave_number-staging"
   ```

2. **Merge each ticket branch** into the staging branch:
   ```bash
   git merge --no-ff "feat/$ticket_number-..." -m "feat: implement #$ticket_number — [title]"
   ```

3. **If merge conflicts occur** (expected when tickets in the same wave touch shared files):
   - Log which files conflict
   - Attempt automatic resolution for trivial conflicts (e.g., both sides added different imports)
   - For non-trivial conflicts: launch an **implementation worker** (contract: `docs/worker-contracts.md#implementation-worker`) to resolve the conflict, passing it both branches' changes and the epic contracts as constraints
   - After resolution, run the full test suite to verify the merge is clean

#### 4e: Wave integration check

Run the integration check **on the staging branch, before promoting to main**:

1. **Full test suite**: `go test ./...` / `npm test` / `pytest` — all must pass
2. **Linting**: `golangci-lint run ./...` / `npx eslint` — zero high-severity findings
3. **Build**: Verify the project compiles/builds cleanly
4. **Smoke test**: If services can be started, start them and verify health endpoints respond
5. **Ratchet check** (if `$QUALITY_DIR/ratchet.json` exists — `QUALITY_DIR` resolved via `python3 "$CW_HOME/scripts/artifacts.py" show "$TARGET_REPO" --format json | jq -r .quality_dir`; see `docs/ratchet.md`) — the merged wave may not shrink the high-water pass-set, weaken any contract definition, or rewrite a verifier-test body behind its still-green test ID:
   ```bash
   python3 "$CW_HOME/scripts/ratchet.py" score --repo "$TARGET_REPO"
   python3 "$CW_HOME/scripts/ratchet.py" check --repo "$TARGET_REPO" --gate-verifier-tests
   ```
   Pass `--gate-verifier-tests` only if `check_gate_validation.py ratchet --validation-dir "$CW_HOME/docs/quality/validation" --gate` passes (same record-gated posture as `/implement` Step 8 and `/close-epic` Step 2f, chief-wiggum#208); otherwise drop the flag and surface the printed `weakened_verifier_tests` findings in the wave log. A violation is a hard blocker exactly like a test failure: fix it on the staging branch (or drop the offending ticket's merge from the wave) before promoting. Never resolve a violation by editing the contract, a verifier test, or the journal — a deliberate revision is a journaled human act (`record --amend`/`--amend-verifier`). A `missing_tests` finding caused by a flaky/order-dependent case is fixed by `ratchet.py record --retire-case` with a reason and expiry (#278) — surface it to the user and get their approval; never self-approve it, and never `--force` past the gate instead.
6. **Single-writer / traceability quick check** (report-only, wave-scoped) — if the epic has `docs/epics/<slug>/`, scope both checkers to what THIS wave changed with `--changed-since "$DEFAULT_BRANCH"` (see `docs/single-writer.md`, `docs/traceability.md`):
   ```bash
   python3 "$CW_HOME/scripts/check_single_writer.py" "$EPIC_DIR" --source "$TARGET_REPO" \
     --changed-since "$DEFAULT_BRANCH" --format text
   python3 "$CW_HOME/scripts/check_traceability.py" "$EPIC_DIR" --source "$TARGET_REPO" \
     --changed-since "$DEFAULT_BRANCH" --format text
   ```
   Report-only: this is a fast wave-scoped signal, not the authoritative gate — `--changed-since` cannot see a stale writer/annotation outside this wave's diff. `/close-epic`'s coverage gate always scans the whole repo and is what actually blocks the epic. Surface findings for the fixer; don't hard-block the wave on them here.
7. **Prevention signals** (#216, report-only — NEVER blocking): `python3 "$CW_HOME/scripts/prevention_signals.py" --repo "$TARGET_REPO" --base "$DEFAULT_BRANCH"` over the merged staging diff — new duplication / dead code introduced / assertion-free tests added, appended to the wave report as reviewer information (same posture as `/implement` Step 7's 3b).

If the integration check fails:
- **Test failure caused by merge**: Fix it on the staging branch. Launch an implementation worker (contract: `docs/worker-contracts.md#implementation-worker`) to diagnose and fix.
- **Build failure**: This is a hard blocker. Fix before proceeding.
- Do NOT push until all checks pass.

#### 4f: Formal model conformance check (if formal models exist)

After the integration check passes but **before promoting to main**, run a conformance check against the formal models:

```bash
if [ "$HAS_FORMAL_MODELS" = true ]; then
  echo "=== Formal Model Conformance Check ==="

  # Check guard clause presence: for each REQUIRES in contracts.json,
  # grep the implementation for a corresponding guard/validation
  python3 "$CW_HOME/scripts/formal_models.py" validate "$MODELS_DIR/contracts.json"
  python3 "$CW_HOME/scripts/formal_models.py" validate "$MODELS_DIR/state-machines.json"

  # Verify invariants are covered by tests
  # For each invariant ID in the model, grep the test files
  for inv_id in $(python3 -c "
import json
sm = json.load(open('$MODELS_DIR/state-machines.json'))
for inv in sm.get('invariants', []):
    print(inv['id'])
"); do
    if grep -r "$inv_id" "$TARGET_REPO/lib/__tests__/" >/dev/null 2>&1; then
      echo "  $inv_id: COVERED"
    else
      echo "  $inv_id: NOT COVERED in tests"
    fi
  done

  # Single-write-path / sanctioned-caller invariants: whatever THIS epic
  # actually declared (controls_field + sanctioned_writers), not a
  # hardcoded pattern from one target repo. code_query.py wraps
  # check_single_writer.py's writer inventory as a per-invariant query, so a
  # future epic's INV-<whatever> is covered without editing this skill.
  for inv_id in $(python3 -c "
import json
sm = json.load(open('$MODELS_DIR/state-machines.json'))
for inv in sm.get('invariants', []):
    if inv.get('controls_field') and inv.get('sanctioned_writers'):
        print(inv['id'])
"); do
    result=$(python3 "$CW_HOME/scripts/code_query.py" --repo "$TARGET_REPO" --epic "$EPIC_SLUG" --format json writers "$inv_id")
    violations=$(echo "$result" | jq '[.facts[] | select(.sanctioned == false)] | length')
    if [ "$violations" -gt 0 ]; then
      echo "  $inv_id: WARN — $violations unsanctioned writer(s)"
      echo "$result" | jq -r '.facts[] | select(.sanctioned == false) | "    " + .handle + " (" + (.symbol // "?") + ")"'
    else
      echo "  $inv_id: PASS — no unsanctioned writer found"
    fi
  done

  # Duplicated inline-auth detection (INV-auth-009-style "use the shared auth
  # helper" invariants). NOTE this is a DIFFERENT check from the writer
  # inventory above: inline auth checks are READS (a route re-deriving the
  # session/ownership answer itself), so check_single_writer/code_query's
  # writer scan cannot see them. Until an epic models its shared-helper rule
  # as a queryable invariant, keep the explicit grep — patterns come from the
  # epic's invariants.md ("shared helper" / "inline auth" rules), with the
  # original Next.js pair shown as the example default. Superseded only when
  # the epic's own invariant models this (e.g. a future read-path analog of
  # controls_field).
  inline_count=$(grep -r "getServerSession\|board\.userId ===" "$TARGET_REPO/app/api/" --include="*.ts" -l 2>/dev/null | wc -l | tr -d ' ')
  if [ "$inline_count" -gt 0 ]; then
    echo "  inline-auth: WARN — $inline_count route files still have inline auth checks"
    grep -r "getServerSession\|board\.userId ===" "$TARGET_REPO/app/api/" --include="*.ts" -l 2>/dev/null
  else
    echo "  inline-auth: PASS — no inline auth checks found"
  fi
fi
```

This is a signal, not a gate in the current implementation. Log the conformance results in the wave report. If coverage is below 80% on any category, flag it for the `/close-epic` retrospective. (`/close-epic`'s own `check_single_writer.py --gate coverage` is the authoritative, whole-repo blocker — this is a fast per-wave early warning, same relationship as the ticket-scoped `--changed-since` check in `/implement` Step 8.)

#### 4g: Promote staging to main

Only after the integration check passes, fast-forward the default branch to the staging branch:

```bash
git checkout "$DEFAULT_BRANCH"
git merge --ff-only "wave-$wave_number-staging"
git push origin "$DEFAULT_BRANCH"
git branch -d "wave-$wave_number-staging"
```

If the fast-forward fails (someone pushed to main in the meantime), rebase the staging branch and re-run the integration check.

Only proceed to the next wave after the push succeeds.

#### 4h: Update traceability

After the wave merges, update the traceability matrix for all tickets in the wave:
- Mark acceptance criteria as `covered` where tests were written
- Note any gaps for the `/close-epic` retrospective

**Journal the ratchet** (if `$QUALITY_DIR/ratchet.json` exists — `QUALITY_DIR` resolved via `python3 "$CW_HOME/scripts/artifacts.py" show "$TARGET_REPO" --format json | jq -r .quality_dir`): record the merged wave so its passing tests advance the high-water mark, and give the next session amnesia context:

```bash
python3 "$CW_HOME/scripts/ratchet.py" record --repo "$TARGET_REPO" \
  --event wave --ref "wave-$wave_number" --merged \
  --notes "<tickets merged, anything parked and why>"
```

Commit the traceability and ratchet updates to main (embedded mode only — in sidecar mode the journal/state live outside the target, so there is nothing to commit in-tree).

### Step 5: Create PRs (optional)

By the time all waves complete, all code is already on main (merged directly). However, if the user prefers PRs for audit trail:

For each ticket implemented, create a **retroactive PR** (already merged) by commenting on the issue with:
- Summary of changes
- Test evidence
- Review findings
- Link to the merge commit

Alternatively, create a single **epic-level PR** from a branch that contains all the wave commits, for a consolidated review.

Ask the user which approach they prefer, or if direct-to-main is fine.

### Step 6: Final report

```markdown
## Wave Implementation Complete: [Epic Name]

### Waves executed: N
| Wave | Tickets | Status | Duration |
|------|---------|--------|----------|
| 1 | #42, #45 | merged | ~25 min |
| 2 | #43, #46 | merged | ~35 min |
| 3 | #44 | merged | ~20 min |

### Per-ticket summary
| Ticket | Branch | Tests | Review | Design fidelity | Merge | Issues |
|--------|--------|-------|--------|-----------------|-------|--------|
| #42 | feat/42-... | 12 pass | 2 fixes applied | n/a (backend) | clean | — |
| #43 | feat/43-... | 8 pass | 1 fix applied | n/a (backend) | clean | — |
| #44 | feat/44-... | 15 pass | 3 fixes applied | ✓ screenshots reviewed, tokens bound | conflict resolved | OrderList merge |

For frontend tickets, link the screenshot directories so the human can see what shipped.

### Merge conflicts resolved: N
- [Details of each conflict and how it was resolved]

### Integration check results
- All waves passed integration checks
- Pre-existing failures fixed: N

### Next steps
1. `/close-epic owner/repo --epic "Epic: [Name]"` — run integration tests, mutation testing, and full epic validation
```

### Step 7: Offer next steps

After all waves complete:
1. If all tickets in the epic are now closed: suggest `/close-epic`
2. If some tickets remain open: list them and ask if they should be implemented in another wave
3. Close implemented issues:
   ```bash
   gh issue close $ticket_number --repo "$owner_repo" --comment "Implemented in wave $wave_number. Merged to $DEFAULT_BRANCH."
   ```

## Key Principles

- **Waves respect the dependency graph.** A ticket never starts until all its dependencies have merged to main. This is a hard constraint, not an optimisation hint.
- **Each worker runs the full /implement loop.** No shortcuts — TDD, multi-AI review, linting, tests. The parallelism is in running multiple tickets simultaneously, not in cutting steps per ticket.
- **The orchestrator owns the merge.** Workers produce branches. The orchestrator merges, resolves conflicts, and runs integration checks. Workers never merge or create PRs.
- **Integration checks between waves catch seam bugs early.** A test that passes in isolation but fails after merge is exactly the kind of bug this workflow is designed to catch.
- **Max-parallel limits API pressure.** Two concurrent tickets means up to 8 simultaneous AI API calls (3-4 consultations per ticket). Respect rate limits. Increase only with high-tier API access.
- **Failed tickets don't block the wave.** If one ticket in a wave fails, the other tickets in that wave can still merge. The failed ticket is retried or deferred to a later wave.
- **Pre-flight catches auth failures early.** Discovering expired Codex auth 20 minutes into a 3-ticket wave wastes all 3 tickets' work. Check before launching.
- **Unknowns gate work; they don't ride along.** A `TBD:` in an artifact means "we don't actually know this yet". Implementing a dependent ticket anyway converts the unknown into silent wrong code. Resolve it or defer the ticket — those are the only two options.
