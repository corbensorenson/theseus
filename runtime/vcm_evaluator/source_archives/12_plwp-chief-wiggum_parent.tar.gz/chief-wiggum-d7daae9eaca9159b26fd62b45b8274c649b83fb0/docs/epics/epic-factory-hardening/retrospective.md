# Retrospective — Epic: Factory Hardening

Closed by `/close-epic` on 2026-07-20. All 6 tickets merged to `main`:
#83 → PR #191, #134 → PR #195, #174 → PR #193, #185 → PR #192, #187 → PR #194,
#184 → PR #196 (in that merge order; #184's gate-validation records were
authored last, per ADR-fh-06, after #174 froze `check_architecture`'s `CHECKS`
inventory).

No `ui-spec.json` — this epic touches no frontend surface (every deliverable is
a Python CLI, JSON schema, or prompt-assembly path), so cross-surface
consistency and the UX-flow audit (Steps 5/6) do not apply. No SaaS NFR gate
(Step 2h) or adversarial security review (Step 2i) either: chief-wiggum is
internal tooling with no new external/user-facing surface in this epic.

## Status: PASS (all hard gates) — one honest open item (#198)

`check_traceability.py --gate coverage` (Step 2d) initially **failed**: three
contracts (CTR-fh-043, CTR-fh-044, INV-fh-005) were uncovered/untested by the
mechanical `@cw-trace` annotation scan, despite being genuinely implemented
and tested — the tags were simply never added. Fixed on this same close
branch as **#197** (annotation-only, no behavior change): `guards` tags at
the covering code sites — `check_gate_validation.py`'s `passing` property
(CTR-fh-043), its `corpus_digest`, the fixture-pinning mechanism
(CTR-fh-044), and the five gates' `_scanner_version` functions (INV-fh-005) —
plus `verifies INV-fh-005` tags in the covering tests. The epic's own
machinery fired on the fix itself, twice: (1) adding a docstring tag to the
five gate scripts bumped their hash-derived `--scanner-version`, staling
their validation records exactly as designed — each was re-verified and
re-journaled (rec-00016..rec-00020) through the sanctioned path; (2) a first
attempt to tag the fixture server (`saas_gate_server.py`) was rejected by the
TIM schema — `guards` cannot originate from a test-kind file — forcing the
tag to a genuine code site. The coverage gate now **passes** and the
suspect-link sidecar (`docs/quality/trace-links.json`, 259 links) is
written.

The one remaining open item is IT-fh-06 / stale-while-blocking auto-demotion
(**#198**) — a disclosed product decision (implement or deliberately retire),
not a gate failure. All other gates (single-writer coverage, ratchet, full
test suite, 9/10 IT-fh-* integration tests) are green.

## What shipped, per ticket

- **#83 (PR #191)** — `TicketContext` gained a provenance lattice for comments:
  `comments` (observed, append-only) → `amendments` (promoted by a mechanical
  rule: author/maintainer + explicit `AC:` block) vs `discussion` (everything
  else). The rendered review prompt now carries two distinctly labeled regions;
  the raw thread is never rendered as a single authoritative block. Fixed the
  upstream `ticket.json` writer, which previously omitted `comments` entirely
  (the actual production bug — `from_dict` fixes alone would not have shipped
  a fix).
- **#134 (PR #195)** — `consult_ai.py` now captures real per-provider token
  usage (5 adapters: codex-cli, gemini-cli, vertex-sdk, claude-cli,
  claude-interactive) and threads it through `emit_consult`. Cost is derived
  only inside `emit_consult` via `factory_log.cost_for` — never fabricated,
  both-tokens-or-null honored, `usage_status` always names the true source.
  `claude-interactive`'s former `'result-file'` status was removed (it
  conflated transport with usage availability).
- **#174 (PR #193)** — New `docs/system/architecture.json` (C4-flavored
  declared model) + `check_architecture.py`: static consistency checks only
  (dangling edges, missing tiers, retired-node edges, tier inversion,
  label-propagation, authored crossing labels). Report-only by default,
  `--gate` opt-in, `--scanner-version` support (making it the fifth #184 gate).
  Prints the authority-boundary line verbatim every run: "proves the DECLARED
  model is internally consistent; does not prove the code matches the model."
- **#185 (PR #192)** — `code_query.py orient`'s inferred-binding matcher no
  longer over-matches on a single common entity word (the "provider" bug —
  dozens of unrelated operations shared that word). Fixed with IDF-style
  weighting over the epic's own operations/routes, stdlib-only, deterministic.
  `_rank_key` gained a leading relation-tier element (`direct=0, inferred=1,
  measured=2`) so tier ordering is mechanically enforced, not conventional.
- **#187 (PR #194)** — `hotspots.py` + `hotspot_discovery.py`: Tornhill-style
  change-risk hotspots (churn × complexity × coupling), explicitly derived,
  never gating, no stable IDs. Reuses the existing coupling engine
  (`process.py`) rather than building a second one (INV-fh-001) — this was a
  deliberate opus correction of the original ticket framing. `code_query`
  gained the `measured` relation tier, exact-membership only, sorting below
  `direct` and `inferred`.
- **#184 (PR #196)** — Added hash-derived `--scanner-version` to all five
  gates (`ratchet`, `saas_gate`, `ci_scaffold`, `quality_slop_gate`,
  `check_architecture`) and authored + live-verified a
  `docs/quality/validation/<gate>.json` record for each, activating the
  stale-record-detection machinery. Built fixture/recorded-target harnesses
  for `saas_gate` and `quality_slop_gate` so their records don't depend on a
  live URL or a non-deterministic AI band (CTR-fh-044, the explicit blocker
  AC for those two records).

## The protocol firing on itself

This epic is unusual in that its subject and its enforcement mechanism are the
same system — chief-wiggum hardening chief-wiggum. That produced several
literal instances of the epic's own gates catching the epic's own draft
mistakes before merge (visible in PR review threads and the ratchet journal):

- **`check_single_writer` caught a false positive it then had to be fixed
  around, not waived.** #187's first draft relayed `coupling.confidence`
  dict literals directly in `hotspots.py`/`code_query.py`; the scanner (correctly,
  field-agnostically) flagged those relay sites as unsanctioned writers. The
  fix moved the literal construction into `process.py` (the sanctioned file)
  and had downstream code spread/relay it — `check_single_writer` now reports
  0 violations for INV-fh-001. The gate forced a real design correction, not a
  suppression.
- **The ratchet held through post-merge scanner-hash edits, and recorded each
  one.** `docs/quality/ratchet-journal.jsonl` shows three re-validations
  (rec-00011 through rec-00014) after `--scanner-version` dependency lists
  were corrected during PR #196 review (`trace_links.py`,
  `quality/survival.py`, `quality/duplication.py`, `quality/churn.py`,
  `quality/complexity.py` were added as hash inputs for CTR-fh-041 dep
  completeness) — each edit was re-verified live and re-journaled rather than
  hand-waved as "still fine."
- **Opus corrected the ticket text, not just the code, on two tickets.** #187's
  issue as originally scoped implied a new coupling engine; the epic's own
  invariant (INV-fh-001, "one coupling engine") caught this at architecture
  time and the ticket was reframed as reuse-only before implementation. #134's
  contract was similarly narrowed (consult events only; CLAUDE_CODE/OTEL-cost
  records are out of scope) to keep INV-fh-002 honest rather than overclaiming.
- **Codex's adversarial-comment scenario (IT-fh-01) is a defense the epic
  needed against itself**: the review pipeline this epic hardens is the same
  pipeline that reviews chief-wiggum's own tickets, including this one's.

## What went wrong

- **The `check_traceability.py --gate coverage` gate genuinely failed** on
  three IDs (since fixed on this branch as #197 — see Status above; the
  original findings are kept here verbatim as the record of what the gate
  caught), discovered only by running the gate rather than trusting the
  epic's own `traceability.md` (which had already honestly marked the related
  IT-fh-06 row `pending`, but not the annotation gap):
  - **CTR-fh-043 / CTR-fh-044 uncovered** (no code `@cw-trace guards`/`ensures`
    anywhere in `scripts/`). The underlying behavior these contracts describe
    (author + live-verify a gate-validation record; pin a fixture/recorded
    target for `saas_gate`/`quality_slop_gate`) is real and is exercised by
    `tests/test_gate_validation_184.py` and `tests/test_gate_validation_retroactive.py`
    (both green) — but the mechanical link from contract → implementing code
    was never added. Multiple test-side `@cw-trace verifies CTR-fh-043` links
    exist, so these are untested-on-the-code-side, not untested outright.
  - **INV-fh-005 uncovered AND untested.** Hash-derived `--scanner-version` is
    genuinely implemented in all five gates (confirmed by direct code
    inspection: `ratchet.py`, `check_architecture.py`, `ci_scaffold.py`,
    `quality_slop_gate.py`, `saas_gate.py` each reference
    `chief_wiggum.hashing.scanner_version` and cite INV-fh-005 in a docstring
    comment) and tested (`tests/test_check_architecture.py:596` etc.) — but,
    again, no file carries the literal `@cw-trace guards/ensures INV-fh-005`
    or `@cw-trace verifies INV-fh-005` tag the checker requires.
  - **Disposition**: not waived — fixed as #197 on this close branch
    (annotation-only tags at the genuinely-covering sites, per the
    coordinator's direction), with the five stale validation records
    re-verified and re-journaled (rec-00016..rec-00020) because tagging the
    gate scripts bumped their hash-derived scanner versions — the epic's own
    staleness machinery working as designed. No
    `docs/epics/epic-factory-hardening/justifications/*.json` waiver was
    authored — these ACs are not "manual QA only," they were missing a tag on
    code that already exists. Coverage gate now passes; sidecar written.
- **IT-fh-06 (stale-record auto-demotion end-to-end) was never implemented.**
  The state-machines.json model specifies a `blocking → stale → demoted`
  (fail-to-report-only, via a generic `emit(DEMOTION, gate=gate,
  details='stale')` event, since `emit_demotion` requires a `seed_class` a
  staleness demotion doesn't have) distinct from `validated → stale →
  report_only`, tracked via a `previous_authority` field. None of this exists
  in `check_gate_validation.py` or `factory_log.py`: the only implemented
  mechanism is a `passing: bool` collapse (a stale scanner version makes
  `passing` false, which is correctly tested), plus the pre-existing,
  unrelated escape-driven `demotion_check(missed_by, seed_class)`. No test
  file anywhere carries an `IT-fh-06` marker. This traceability row was
  already honestly marked `pending` in the epic's own `traceability.md` before
  this close — the epic's authors flagged it and it stayed unresolved. This is
  the one row this close leaves as `missing` rather than `passing`/`covered`.
  Real, disclosed gap, not a surprise.
- **`scripts/verify_transitions.py` reports 0/15 transitions covered** for the
  Gate Blocking-Authority Lifecycle model. Investigated rather than taken at
  face value: this is mostly a model/tool shape mismatch, not proof of zero
  implementation — `check_gate_validation.py` computes the lifecycle as a
  derived boolean (`passing`) plus separate flags, never as a literal named
  `self.status = "blocking"`-style state field the transition-verifier's
  pattern matcher can find. Five of the six states (`unknown`, `report_only`,
  `validated`, `blocking` via workflow `--gate` wiring, `stale`) are
  genuinely realized through that boolean/derived logic and are tested. The
  sixth (`demoted`, reached only via the missing stale-auto-demote path
  above) is the one that's actually absent. Recommendation for the next epic
  that models a conceptual/computed lifecycle rather than a literal state
  field: either give `verify_transitions.py` a "derived-state" matching mode,
  or don't model it as a literal state machine in the first place — the
  current model reads as more implemented than it is until someone reads the
  code.
- **`scripts/traceability.py`'s `update`/`audit` commands only recognize the
  5-column `Ticket | AC | Unit Test | Integration Test | E2E Test | Status`
  table shape** (used only in the #83 section of this epic's own
  `traceability.md`). The other five ticket sections use a 4-column
  `Acceptance criterion | Contracts / invariants | Planned tests | Status`
  shape with no per-row ticket cell, which `parse_matrix`'s
  `_REQUIRED_COLUMNS = ("ticket", "ac", "status")` silently skips — `audit`
  reported "5/5 covered, 100%" against a file that actually has 35 rows across
  six tickets. This close updated all 35 rows by hand instead (see the file's
  own note) after confirming `traceability.py update --ticket <n>` matched 0
  rows on either table shape. Two tables in the SAME file speaking two
  different schemas, with the tooling only honoring one, is exactly the kind
  of drift the traceability system exists to prevent — it just wasn't
  pointed at itself before now.

## What to improve

- **Give `/architect` one canonical traceability-table schema and lint it.**
  The `Ticket | AC | Unit Test | Integration Test | E2E Test | Status` and
  `Acceptance criterion | Contracts / invariants | Planned tests | Status`
  shapes both look reasonable read by a human; only running the actual
  updater against a real epic (this one) revealed that only one is
  machine-actionable. A `check_traceability.py`-adjacent schema lint at
  `/architect` time would have caught this before six tickets landed on it.
- **A contract/invariant that's implemented in five call sites and tested in
  two test files, but never mechanically linked, is a distinct failure mode
  from "not built."** `check_traceability.py`'s uncovered/untested categories
  don't currently distinguish "nothing here" from "everything here except the
  three-word comment." Both block the coverage gate identically, which is
  correct (the whole point of `@cw-trace` is that prose claims don't count),
  but a future `/implement` review checklist item — "does every REQUIRES/
  ENSURES/invariant this ticket touches carry its `@cw-trace` tag, not just a
  docstring mention of the ID?" — would have caught CTR-fh-043/044 and
  INV-fh-005 at ticket-close time instead of at epic-close time.
  Recommend opening a follow-up ticket to add the three missing tags (trivial
  fix, not done here to keep code changes out of a closer's hands without
  review) and re-running the coverage gate.
- **When a formal model describes a conceptual/derived lifecycle rather than a
  literal state field, say so in the model itself** (or give
  `verify_transitions.py` a mode for it) so "0/15 covered" doesn't read as an
  alarming regression when five of six states are actually real.
- **IT-fh-06 needed a ticket of its own, not just a traceability row marked
  pending.** A `pending` row in a matrix that never gets revisited is exactly
  the kind of "no deferred decisions without a ticket" failure this
  project's own principles warn against. Filing a tracking issue for it is
  part of this close (see below), per that same principle.

## Follow-ons (ticketed, not left as prose)

1. **[#197](https://github.com/plwp/chief-wiggum/issues/197)** — **DONE (on
   this close branch)**: `@cw-trace guards` tags added for CTR-fh-043
   (`check_gate_validation.py` `passing` property), CTR-fh-044
   (`check_gate_validation.py` `corpus_digest` — the fixture-pinning
   mechanism; a first attempt to tag the fixture server was rejected by the
   TIM schema since `guards` cannot originate from a test-kind file) and
   INV-fh-005 (the five gates' `_scanner_version` functions), plus
   `verifies INV-fh-005` in `tests/test_check_architecture.py` and
   `tests/test_gate_validation_retroactive.py`. Coverage gate re-run: PASS;
   `--write-links` sidecar written (259 links); five stale records
   re-verified + re-journaled (rec-00016..rec-00020).
2. **[#198](https://github.com/plwp/chief-wiggum/issues/198)** — Implement
   IT-fh-06 (stale-while-blocking auto-demotion + `previous_authority`
   tracking + generic `emit(DEMOTION, details='stale')`) in
   `check_gate_validation.py`/`factory_log.py`, or explicitly retire the AC
   and the state-machines.json states/transitions it targets if the team
   decides the simpler `passing: bool` collapse is sufficient going forward
   (a deliberate decision, not a silent drop — would need a `ratchet.py
   record --amend/--retire`).
3. Normalize `docs/epics/*/traceability.md` to one table schema across all
   ticket sections, and extend `scripts/traceability.py`'s parser/updater to
   match it (or add a second recognized schema) so `/close-epic`'s Step 2
   audit reflects the true row count on the next epic. (Not yet ticketed —
   cross-cutting tooling change, recommend folding into whichever epic next
   touches `/architect`'s traceability-authoring step.)
4. Consider a `verify_transitions.py` mode (or model-authoring convention) for
   conceptual/derived lifecycles so a model like this one's Gate
   Blocking-Authority Lifecycle doesn't read as 0% covered when most of it is
   real. (Not yet ticketed — folds naturally into #198's investigation.)

## Metrics

- **Tickets**: 6 planned, 6 completed (0 required rework beyond normal PR
  review — see "protocol firing on itself" for the in-review corrections that
  *did* happen, all resolved pre-merge).
- **Traceability**: 35 acceptance criteria across 6 tickets; 33 `passing`,
  1 `covered` (workflow/manual-review item), 1 `missing` (IT-fh-06 stale-demotion,
  disclosed above → #198). `check_traceability.py --gate coverage`: **PASS**
  after #197 (initially FAIL — 3 uncovered contracts CTR-fh-043, CTR-fh-044,
  INV-fh-005, 1 also untested; fixed with annotation-only tags on this branch,
  see Status). Suspect-link sidecar written: `docs/quality/trace-links.json`,
  259 links. Dangling annotations in the whole-repo scan (63) are all
  pre-existing fixtures for other epics' gate tests (`CTR-order-*`, `BR-x-*`,
  `BUD-voice-*`, etc., used deliberately as undefined-ID fixtures) — none
  reference an `-fh-` ID and none are new from this epic.
- **Single-writer coverage**: `check_single_writer.py --gate coverage`:
  **PASS** — 4 single-write-path invariants, 24 writers found, 0 violations,
  0 malformed metadata. One informational warning (INV-fh-004's
  `DEFAULT_VALIDATION_DIR` sanctioned writer is a module-level constant, which
  the writer-scanner's assignment-pattern heuristic doesn't register as a
  "write" — a known tool limitation, not a gap; the import-not-redefinition
  fix was confirmed by direct code inspection at `scripts/check_gate_validation.py:73`).
- **Ratchet**: `ratchet.py check`: **OK**, pass-set and contract-definition
  hashes hold the high-water mark. Journal entries all `held`, including 3
  gate-validation re-verifications after post-merge `--scanner-version`
  dependency-list corrections during PR #196 review. Epic-close recorded as
  `rec-00015`; the #197 tag additions re-journaled all five gates'
  re-validations as `rec-00016`..`rec-00020` (their scanner versions changed
  when the tags were added — staleness machinery working as designed).
- **Full test suite**: 1549 passed, 10 skipped (all skips are `lizard`-not-installed,
  consistent with CI, not epic-specific), 0 failed — re-run green after the
  #197 tags + record re-validations.
- **Integration tests (IT-fh-01 .. IT-fh-10)**: 9/10 implemented and mapped to
  covering tests; all implemented ones pass; IT-fh-06 missing (→ #198). See
  table below.
- **Mutation testing**: not run — no mutation-testing tool
  (mutmut/cosmic-ray/stryker) available in this environment; flagged as a
  standing recommendation, unchanged from prior epics.
- **AI-slop signals (report-only)**: production duplication 2.8% (beats the
  pre-AI human baseline of 8.3%); code-survival skipped (`git-of-theseus` not
  installed).
- **CI**: present (`.github/workflows/ci.yml`, node + python stacks detected).
- **Tutorial coverage**: not applicable — chief-wiggum has no
  `docs/tutorials/`/tutorial-maintainer system (internal tooling repo, no
  end-user UI).

### IT-fh-* coverage map

| IT | Scenario | Covering test(s) | Result |
|----|----------|-------------------|--------|
| IT-fh-01 | Adversarial comment stays non-authoritative (#83) | `tests/test_review_pipeline.py` (two-labeled-region tests) | PASS |
| IT-fh-02 | `from_dict` round-trips comments (#83) | `tests/test_review_pipeline.py` (dict/legacy-string round-trip) | PASS |
| IT-fh-03 | Hotspot fact does not regress #185 (golden) | `tests/test_code_query_golden.py` (cases a–d) | PASS |
| IT-fh-04 | Table-driven #184 records for all five gates | `tests/test_gate_validation_184.py` | PASS |
| IT-fh-05 | Consult degradation matrix per adapter (#134) | `tests/test_consult_ai.py` | PASS |
| IT-fh-06 | Stale-record auto-demotion end-to-end (#184) | `tests/test_check_gate_validation.py`, `tests/test_ratchet.py` | PASS — implemented via #198 (see Addendum below) |
| IT-fh-07 | architecture ↔ system-contracts cross-ref resolution (#174) | `tests/test_check_architecture.py` | PASS |
| IT-fh-08 | Hotspot determinism (#187) | `tests/test_hotspots.py` | PASS (2 assertions skip without `lizard`, same as CI) |
| IT-fh-09 | Report-only vs `--gate` exit-mode semantics (#174, #184) | `tests/test_check_architecture.py`, `tests/test_check_gate_validation.py` | PASS |
| IT-fh-10 | `/implement` writer emits comments (golden) (#83) | `tests/test_review_pipeline.py` (golden) | PASS |

## Recommendation

**SHIP** — all hard gates pass. Follow-on #1 (#197, the three missing
`@cw-trace` tags) was completed on this same close branch: coverage gate
re-run **PASS**, `--write-links` sidecar written (259 links), five stale
validation records re-verified + re-journaled (rec-00016..rec-00020), full
suite re-run green. The one open item, #198 (IT-fh-06 / stale-demotion), is a
real product decision (implement it, or deliberately retire the AC via
`ratchet record --retire`) — it should be decided deliberately, not rushed to
close, and does not block the milestone if the team prefers to retire it.
Everything else (integration tests, single-writer, ratchet, full suite,
AI-slop signals, CI) is green.

## Addendum (2026-07-20, follow-up) — #198: IT-fh-06 implemented

The decision this retrospective flagged as open — implement the modeled
stale-while-blocking auto-demotion, or deliberately retire it — was made:
**implement**. The committed `state-machines.json` already declared the
`stale`/`demoted` states, the `previous_authority` context field, and the
`auto_demote`/`downgrade_nonblocking_stale`/`record_missing_or_invalid`
transitions; retiring them would have meant discarding a design the model
itself said was correct, with no new information arguing otherwise.

What shipped in #198 (final, journaled design — see "Design evolution" below
for why the first two attempts were rejected):

- **Blocking authority is a JOURNALED fact, not a file.** `scripts/ratchet.py`
  gained a `gate-authority` event type + path-based primitives
  (`append_authority_event`, `last_authority_action`, `verified_prefix`):
  `check_gate_validation.py --wire`/`--unwire` append a `wire`/`unwire` event
  to the ratchet hash chain, and "is this gate blocking?" is read back from
  those events over the verified chain prefix — tamper-evident, not
  hand-writable. There is NO `<gate>.authority.json` sidecar; a bare mutable
  file would itself be the forgeable trust record this epic exists to
  eliminate.
- `scripts/check_gate_validation.py` gained `failure_kind` (classifies a
  non-passing report as `"stale"` — scanner_version/journal-chain drift only —
  vs `"invalid"` — missing/schema-invalid/failed), `authority_status` (derives
  the verdict from the journaled wire fact + current `passing`), and
  `check_and_transition`. The current-blocking verdict is simply: the last
  authority event is `wire` AND `check()` reports `passing == true` now. A
  journaled-wired gate whose record is NOT currently passing is demoted
  (fail-to-report-only, ADR-fh-04). Reading "was wired" from the journal means
  the demotion fires even when the CURRENT record or chain is what broke — the
  case the earlier fail-closed sidecar masked.
- `scripts/factory_log.py` gained `emit_stale_demotion(gate, reason,
  previous_authority=...)` — the generic `DEMOTION` event
  (`details='stale'|'record_missing'`) the model called for, distinct from the
  escape-driven `emit_demotion` (which requires a `seed_class` a staleness
  demotion never has).
- `--wire` journals a wire ONLY when the record passes (non-passing `--wire`
  never reaches `blocking`, INV-fh-003); `--unwire` from a stale/missing-while-
  blocking record still surfaces + emits the demotion (read from the pre-unwire
  journal) rather than masking it; no plain/ad-hoc check or missing-gate op
  writes any trust-bearing state — only operator `--wire`/`--unwire` append.
  The `--gate` exit-1 guard (`report.passing`) remains the SOLE INV-fh-003
  enforcement, independent of any authority record.
- **Scope.** This is the *detection + emission* of stale-while-blocking
  auto-demotion — IT-fh-06's core assertion. The persistent lifecycle-
  management the model also sketches (an explicit `demoted` resting state, a
  two-step `demoted → validated → blocking` recovery handshake) is deferred:
  it needs a writable authority store, and every such store is either forgeable
  (a file) or would force trust-writes on plain checks. Recovery is simply
  "re-author the record, then `--wire` again"; because "was wired" is read from
  journaled events (not by matching the wire event's rid to the record's), a
  re-derived record with a brand-new `ratchet_record_id` recovers cleanly.
  → ticket the richer journaled lifecycle-management as its own follow-up.
- Editing `ratchet.py` bumped its hash-derived `--scanner-version`, staling its
  own `docs/quality/validation/ratchet.json` record — the epic's staleness
  machinery firing on itself (as in PR #197). The record's `scanner_version`
  was re-authored to the new live value (its seeded trials, re-executed by
  `tests/test_gate_validation_retroactive.py`, are unchanged — a non-behavioral
  source bump).

### Design evolution (two review rounds on PR #202)

The lesson: **one trust artifact cannot answer two incompatible questions.**
The first implementation used a persisted `<gate>.authority.json` sidecar for
both "was this gate blocking?" (which must survive staleness, since staleness
is exactly when you need it) and "may it assert blocking now?" (which must
fail closed on staleness). Codex review round 1 found the sidecar forgeable and
the `--wire`/`--unwire` state machine leaking blocking authority; round 2's
corroboration fix (anchoring the sidecar's trust in the journal) then created
new holes — chain-broken-while-blocking stopped demoting (the corroboration
fail-closed erased the "was blocking" fact), and real re-journal recovery (a
new rid) was rejected as contradictory. The fix was structural: drop the
sidecar as a trust source entirely and read "was wired" from journaled,
tamper-evident `gate-authority` events (mirroring how `ratchet-highwater.json`
is a derived display cache, never a trust source), keeping the strict
"may-assert-now" question answered live by `check().passing`. Findings 1–4 all
dissolve because there is no longer a forgeable file, and the was-wired read
tolerates a later chain break (verified prefix) instead of failing closed.

- Tests: `tests/test_check_gate_validation.py` covers both demotion variants
  (stale scanner/journal drift, record-missing/schema-invalid) while
  journaled-wired, the not-wired downgrade, `--wire`/`--unwire` semantics, and
  four explicit review-finding regressions — chain-broken-while-wired STILL
  demotes (finding 1), re-journaled-new-rid recovery reaches blocking not stuck
  (finding 2), a hand-written sidecar asserts nothing (finding 3), and no
  trust-write on plain/missing-gate checks (finding 4). `tests/test_ratchet.py`
  drives it end-to-end through the REAL `ratchet.py record` CLI (`--wire`
  appends a real `gate-authority` event to the real chain).
  `tests/test_factory_log.py` covers `emit_stale_demotion` directly.
- `docs/epics/epic-factory-hardening/traceability.md`'s stale-record row is
  now `passing`; `docs/epics/epic-factory-hardening/integration-tests.md`'s
  IT-fh-06 section carries a `Status: Covered` line.

No other epic ticket's contracts or invariants were touched. Full suite,
ratchet, and single-writer coverage re-verified green on this follow-up
branch (see PR #198's own description for exact counts).
