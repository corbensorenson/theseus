"""Delegated worker helpers."""
